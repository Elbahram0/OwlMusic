package com.elbahram.owlmusic

import android.app.Application
import com.elbahram.owlmusic.data.remote.OkHttpDownloader
import org.schabi.newpipe.extractor.NewPipe

class OwlApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            NewPipe.init(OkHttpDownloader())
        } catch (e: Exception) {
            e.printStackTrace()
        }

        YtDlpBootstrap.scheduleStartupInit(this)
    }
}
