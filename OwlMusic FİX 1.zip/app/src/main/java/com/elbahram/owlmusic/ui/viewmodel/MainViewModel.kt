package com.elbahram.owlmusic.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.elbahram.owlmusic.data.local.MusicDownloadManager
import com.elbahram.owlmusic.data.local.PlaylistRepository
import com.elbahram.owlmusic.data.remote.InnerTubeMusicExtractor
import com.elbahram.owlmusic.domain.model.CurrentPlayback
import com.elbahram.owlmusic.domain.model.DownloadProgress
import com.elbahram.owlmusic.domain.model.Playlist
import com.elbahram.owlmusic.domain.model.SongItem
import com.elbahram.owlmusic.player.OwlPlayerManager
import com.elbahram.owlmusic.ui.theme.ThemeMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.elbahram.owlmusic.MainActivity
import com.elbahram.owlmusic.R
import kotlinx.coroutines.isActive

data class HomeUiState(
    val searchQuery: String = "",
    val isSearching: Boolean = false,
    val searchResults: List<SongItem> = emptyList(),
    val downloadedSongs: List<SongItem> = emptyList(),
    val downloadedKeys: Set<String> = emptySet(),
    val playlists: List<Playlist> = emptyList(),
    val activeDownloads: Map<String, DownloadProgress> = emptyMap(),
    val playCounts: Map<String, Int> = emptyMap(),
    val currentTheme: ThemeMode = ThemeMode.SYSTEM_DEFAULT,
    val currentLanguage: com.elbahram.owlmusic.util.AppLanguage = com.elbahram.owlmusic.util.AppLanguage.TURKISH,
    val strings: com.elbahram.owlmusic.util.AppStrings = com.elbahram.owlmusic.util.TurkishStrings,
    val isPlayerSheetOpen: Boolean = false,
    val recentSearches: List<String> = emptyList(),
    val showRecentSearches: Boolean = true,
    val defaultStartTab: Int = 1,
    val topPlayedCachedSongs: List<SongItem> = emptyList(),
    val sleepTimerSecondsRemaining: Long? = null,
    val errorMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val extractor = InnerTubeMusicExtractor()
    private val downloadManager = MusicDownloadManager(application)
    private val playlistRepo = PlaylistRepository(application)
    val playerManager = OwlPlayerManager(application)

    private val searchPrefs = application.getSharedPreferences("owl_search_prefs", android.content.Context.MODE_PRIVATE)
    private val playCountPrefs = application.getSharedPreferences("owl_play_counts", android.content.Context.MODE_PRIVATE)
    private val settingsPrefs = application.getSharedPreferences("owl_app_settings", android.content.Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(
        run {
            val savedLangCode = settingsPrefs.getString("app_language", "tr") ?: "tr"
            val lang = com.elbahram.owlmusic.util.AppLanguage.fromCode(savedLangCode)
            val tab = settingsPrefs.getInt("default_start_tab", 1).coerceIn(0, 4)
            HomeUiState(
                currentLanguage = lang,
                strings = com.elbahram.owlmusic.util.getStringsForLanguage(lang),
                defaultStartTab = tab
            )
        }
    )
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    val playbackState: StateFlow<CurrentPlayback> = playerManager.playbackState

    private var activePlaylist: List<SongItem> = emptyList()
    private var activeSongIndex: Int = -1

    private var searchJob: Job? = null
    private var loadDownloadsJob: Job? = null
    private var playJob: Job? = null
    private val downloadScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    init {
        loadDownloadedSongs()
        loadPlaylists()
        loadSearchPreferences()
        loadPlayCounts()

        var streamResolverAttempt = 0
        playerManager.streamUrlResolver = { videoId ->
            streamResolverAttempt++
            extractor.getAudioStreamUrl(videoId, forceRefresh = true, bypassInnerTube = streamResolverAttempt > 1)
        }

        playerManager.onSongPlayedListener = { song ->
            incrementPlayCount(song)
        }

        playerManager.onSongEndedListener = {
            if (playbackState.value.isRepeat) {
                playbackState.value.song?.let { currentSong ->
                    playSong(currentSong, activePlaylist, forceRestart = true)
                }
            } else {
                playNextSong()
            }
        }

        playerManager.onNextRequested = {
            playNextSong()
        }
        playerManager.onPreviousRequested = {
            playPreviousSong()
        }
        playerManager.onStopRequested = {
            playerManager.stopPlayback()
        }
        playerManager.onFavoriteRequested = {
            toggleFavoriteCurrentSong()
        }

        com.elbahram.owlmusic.service.OwlPlaybackService.isFavoriteProvider = {
            playbackState.value.song?.let { isSongFavorite(it.id) } ?: false
        }

        viewModelScope.launch {
            playerManager.errorEvents.collect { message ->
                _uiState.value = _uiState.value.copy(errorMessage = message)
            }
        }
    }

    private fun loadSearchPreferences() {
        viewModelScope.launch(Dispatchers.IO) {
            val show = searchPrefs.getBoolean("show_recent_searches", true)
            val savedJson = searchPrefs.getString("recent_searches_list", null)
            val list = if (savedJson != null) {
                try {
                    val arr = org.json.JSONArray(savedJson)
                    (0 until arr.length()).map { arr.getString(it) }
                } catch (e: Exception) {
                    emptyList()
                }
            } else emptyList()

            _uiState.value = _uiState.value.copy(
                showRecentSearches = show,
                recentSearches = list
            )
        }
    }

    fun setShowRecentSearches(enabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            searchPrefs.edit().putBoolean("show_recent_searches", enabled).apply()
        }
        _uiState.value = _uiState.value.copy(showRecentSearches = enabled)
    }

    fun onSearchQueryChange(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
        if (query.trim().length >= 2) {
            searchJob?.cancel()
            searchJob = viewModelScope.launch {
                kotlinx.coroutines.delay(400)
                performSearch(query.trim())
            }
        } else if (query.isEmpty()) {
            _uiState.value = _uiState.value.copy(searchResults = emptyList(), isSearching = false)
        }
    }

    fun onSearchSubmit(query: String) {
        val trimmed = query.trim()
        if (trimmed.isNotEmpty()) {
            addRecentSearch(trimmed)
        }
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            performSearch(trimmed)
        }
    }

    fun addRecentSearch(query: String) {
        if (!_uiState.value.showRecentSearches) return
        val current = _uiState.value.recentSearches.toMutableList()
        current.remove(query)
        current.add(0, query)
        val updated = current.take(15)
        persistRecentSearches(updated)
        _uiState.value = _uiState.value.copy(recentSearches = updated)
    }

    fun removeRecentSearch(query: String) {
        val current = _uiState.value.recentSearches.filter { it != query }
        persistRecentSearches(current)
        _uiState.value = _uiState.value.copy(recentSearches = current)
    }

    fun clearRecentSearches() {
        persistRecentSearches(emptyList())
        _uiState.value = _uiState.value.copy(recentSearches = emptyList())
    }

    private fun persistRecentSearches(list: List<String>) {
        viewModelScope.launch(Dispatchers.IO) {
            val arr = org.json.JSONArray()
            list.forEach { arr.put(it) }
            searchPrefs.edit().putString("recent_searches_list", arr.toString()).apply()
        }
    }

    private suspend fun performSearch(query: String) {
        if (query.isEmpty()) return
        _uiState.value = _uiState.value.copy(isSearching = true)
        val results = extractor.searchSongs(query)
        _uiState.value = _uiState.value.copy(
            searchResults = results,
            isSearching = false
        )
    }

    fun playSong(song: SongItem, playlist: List<SongItem> = emptyList(), forceRestart: Boolean = false) {
        val current = playbackState.value

        if (!forceRestart && current.song?.id == song.id && playerManager.hasMediaItem()) {
            playerManager.togglePlayPause()
            return
        }

        if (playlist.isNotEmpty()) {
            activePlaylist = playlist
            val idx = playlist.indexOfFirst { it.id == song.id }
            activeSongIndex = if (idx != -1) idx else {
                val matchIdx = playlist.indexOfFirst {
                    (!it.localFilePath.isNullOrBlank() && it.localFilePath == song.localFilePath) ||
                    getSongDeduplicationKey(it) == getSongDeduplicationKey(song)
                }
                if (matchIdx != -1) matchIdx else 0
            }
        } else if (activePlaylist.none { it.id == song.id || getSongDeduplicationKey(it) == getSongDeduplicationKey(song) }) {
            activePlaylist = listOf(song)
            activeSongIndex = 0
        } else {
            val idx = activePlaylist.indexOfFirst { it.id == song.id }
            if (idx != -1) activeSongIndex = idx
        }

        playerManager.prepareSong(song)

        playJob?.cancel()
        playJob = viewModelScope.launch {
            val localMatch = if (!song.isLocal || song.localFilePath.isNullOrEmpty()) {
                val dedup = getSongDeduplicationKey(song)
                if (dedup.isNotBlank() && dedup != "_") {
                    _uiState.value.downloadedSongs.firstOrNull { downloaded ->
                        (song.id.isNotBlank() && downloaded.id == song.id) ||
                        getSongDeduplicationKey(downloaded) == dedup
                    }
                } else {
                    _uiState.value.downloadedSongs.firstOrNull { downloaded ->
                        song.id.isNotBlank() && downloaded.id == song.id
                    }
                }
            } else null

            val songToPlay = if (localMatch != null && !localMatch.localFilePath.isNullOrEmpty()) {
                song.copy(
                    isDownloaded = true,
                    localFilePath = localMatch.localFilePath,
                    thumbnailUrl = if (song.thumbnailUrl.isNotBlank()) song.thumbnailUrl else localMatch.thumbnailUrl
                )
            } else song

            val localPath = songToPlay.localFilePath
            val isLocalFileValid = if (!localPath.isNullOrEmpty()) {
                if (localPath.startsWith("content://")) {
                    true
                } else {
                    val f = java.io.File(localPath)
                    f.exists() && f.length() > 20_000L
                }
            } else false

            if (songToPlay.isLocal && isLocalFileValid && !localPath.isNullOrEmpty()) {
                playerManager.playSong(songToPlay, localPath)
            } else {
                val streamUrl = extractor.getAudioStreamUrl(songToPlay.id)
                if (!isActive) return@launch
                if (streamUrl != null) {
                    playerManager.playSong(songToPlay, streamUrl)
                } else {
                    if (playbackState.value.song?.id == song.id) {
                        playerManager.stopPlayback()
                        _uiState.value = _uiState.value.copy(errorMessage = _uiState.value.strings.errorStreamNotAvailable)
                    }
                }
            }
        }
    }

    fun playNextSong() {
        val list = activePlaylist
        if (list.isEmpty()) return
        val currentSong = playbackState.value.song
        var currentIndex = -1
        if (currentSong != null) {
            currentIndex = list.indexOfFirst { it.id == currentSong.id }
            if (currentIndex == -1 && !currentSong.localFilePath.isNullOrBlank()) {
                currentIndex = list.indexOfFirst { it.localFilePath == currentSong.localFilePath }
            }
            if (currentIndex == -1) {
                val currentDedup = getSongDeduplicationKey(currentSong)
                if (currentDedup.isNotBlank() && currentDedup != "_") {
                    currentIndex = list.indexOfFirst { getSongDeduplicationKey(it) == currentDedup }
                }
            }
        }
        if (currentIndex == -1) {
            currentIndex = activeSongIndex.coerceIn(0, list.size - 1)
        }
        val isShuffle = playbackState.value.isShuffle
        val nextIndex = if (isShuffle && list.size > 1) {
            val remainingIndices = (list.indices - currentIndex)
            if (remainingIndices.isNotEmpty()) remainingIndices.random() else 0
        } else {
            (currentIndex + 1) % list.size
        }
        activeSongIndex = nextIndex
        val nextSong = list.getOrNull(nextIndex) ?: return
        playSong(nextSong, list)
    }

    fun playPreviousSong() {
        val list = activePlaylist
        if (list.isEmpty()) return
        val currentMs = playbackState.value.currentPositionMs
        if (currentMs > 3000L) {
            playerManager.seekTo(0)
            return
        }
        val currentSong = playbackState.value.song
        var currentIndex = -1
        if (currentSong != null) {
            currentIndex = list.indexOfFirst { it.id == currentSong.id }
            if (currentIndex == -1 && !currentSong.localFilePath.isNullOrBlank()) {
                currentIndex = list.indexOfFirst { it.localFilePath == currentSong.localFilePath }
            }
            if (currentIndex == -1) {
                val currentDedup = getSongDeduplicationKey(currentSong)
                if (currentDedup.isNotBlank() && currentDedup != "_") {
                    currentIndex = list.indexOfFirst { getSongDeduplicationKey(it) == currentDedup }
                }
            }
        }
        if (currentIndex == -1) {
            currentIndex = activeSongIndex.coerceIn(0, list.size - 1)
        }
        val prevIndex = if (currentIndex > 0) currentIndex - 1 else list.size - 1
        activeSongIndex = prevIndex
        val prevSong = list.getOrNull(prevIndex) ?: return
        playSong(prevSong, list)
    }

    fun downloadSong(song: SongItem) {
        val normKey = "${song.artist.trim().lowercase()}_${song.title.trim().lowercase()}"
        val isAlreadyDownloaded = song.id in _uiState.value.downloadedKeys ||
            (!song.localFilePath.isNullOrBlank() && song.localFilePath in _uiState.value.downloadedKeys) ||
            (normKey != "_" && normKey in _uiState.value.downloadedKeys)

        if (isAlreadyDownloaded) {
            val msg = _uiState.value.strings.alreadyDownloaded.replace("%s", song.title)
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(
                    getApplication(),
                    msg,
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
            return
        }

        downloadScope.launch { downloadManager.unmarkSongDeleted(song) }

        val currentDownloads = _uiState.value.activeDownloads
        if (currentDownloads.containsKey(song.id)) return

        setDownloadProgress(song.id, DownloadProgress(songId = song.id, progressPercent = 0))

        downloadScope.launch {
            downloadManager.acquireWakeLock()
            try {
                val stream = try {
                    extractor.resolveAudioStream(song.id)
                } catch (e: Exception) {
                    null
                }

                downloadManager.downloadSong(song, stream).collect { progress ->
                    when {
                        progress.isCompleted -> {
                            clearDownload(song.id)
                            val cleanTitle = song.title.replace(Regex("[\\\\/:*?\"<>|]"), "").trim().trimEnd('_', ' ', '-')
                            val cleanArtist = song.artist.replace(Regex("[\\\\/:*?\"<>|]"), "").trim().trimEnd('_', ' ', '-')
                            val coverFile = java.io.File(downloadManager.getCoversDirectory(), "$cleanArtist - $cleanTitle.jpg")
                            val finalCover = if (coverFile.exists() && coverFile.length() > 0) coverFile.absolutePath else song.thumbnailUrl
                            val downloadedItem = song.copy(
                                isDownloaded = true,
                                localFilePath = progress.localFilePath ?: song.localFilePath,
                                thumbnailUrl = if (finalCover.isNotBlank()) finalCover else song.thumbnailUrl
                            )
                            val currentList = _uiState.value.downloadedSongs.toMutableList()
                            currentList.removeAll { it.id == song.id || getSongDeduplicationKey(it) == getSongDeduplicationKey(song) }
                            currentList.add(0, downloadedItem)
                            val updatedKeys = buildDownloadedKeys(currentList)
                            _uiState.value = _uiState.value.copy(
                                downloadedSongs = currentList,
                                downloadedKeys = updatedKeys
                            )
                            persistDownloadedSongsOrder(currentList)
                            loadDownloadedSongs()
                            val msg = _uiState.value.strings.songDownloadedSuccess.replace("%s", song.title)
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                android.widget.Toast.makeText(
                                    getApplication(),
                                    msg,
                                    android.widget.Toast.LENGTH_SHORT
                                ).show()
                            }
                        }

                        progress.error != null -> {
                            clearDownload(song.id)
                            val errMsg = _uiState.value.strings.downloadFailed.replace("%s", progress.error ?: "")
                            _uiState.value = _uiState.value.copy(
                                errorMessage = errMsg
                            )
                        }

                        else -> setDownloadProgress(song.id, progress)
                    }
                }
            } catch (e: Exception) {
                clearDownload(song.id)
                val errMsg = _uiState.value.strings.downloadErrorGeneral.replace("%s", e.message ?: "")
                _uiState.value = _uiState.value.copy(
                    errorMessage = errMsg
                )
            } finally {
                clearDownload(song.id)
                downloadManager.releaseWakeLockIfIdle(_uiState.value.activeDownloads.isEmpty())
            }
        }
    }

    private fun setDownloadProgress(songId: String, progress: DownloadProgress) {

        val existing = _uiState.value.activeDownloads[songId]
        if (existing != null &&
            existing.progressPercent == progress.progressPercent &&
            existing.error == progress.error &&
            !progress.isCompleted
        ) {
            return
        }
        val updated = _uiState.value.activeDownloads.toMutableMap()
        updated[songId] = progress
        _uiState.value = _uiState.value.copy(activeDownloads = updated)
    }

    private fun clearDownload(songId: String) {
        val updated = _uiState.value.activeDownloads.toMutableMap()
        updated.remove(songId)
        _uiState.value = _uiState.value.copy(activeDownloads = updated)
    }

    fun persistDownloadedSongsOrder(songs: List<SongItem>) {
        _uiState.value = _uiState.value.copy(downloadedSongs = songs)
        viewModelScope.launch(Dispatchers.IO) {
            val arr = org.json.JSONArray()
            songs.forEach { arr.put(it.id) }
            val jsonStr = arr.toString()
            songOrderPrefs.edit().putString("custom_order", jsonStr).apply()
            try {
                val backupFile = getSongOrderBackupFile()
                backupFile?.writeText(jsonStr, Charsets.UTF_8)
            } catch (_: Exception) {}
        }
    }

    private val songOrderPrefs = application.getSharedPreferences("owl_song_order", android.content.Context.MODE_PRIVATE)

    private fun getDataDirectory(): java.io.File {
        val pubDir = java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "OwlMusic")
        val dataDir = java.io.File(pubDir, "data")
        if (!dataDir.exists()) dataDir.mkdirs()
        val noMedia = java.io.File(dataDir, ".nomedia")
        if (!noMedia.exists()) {
            runCatching { noMedia.createNewFile() }
        }
        return dataDir
    }

    private fun getSongOrderBackupFile(): java.io.File? {
        return try {
            val pubDir = java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "OwlMusic")
            val candidates = listOf(
                java.io.File(pubDir, "data/song_order_backup.json"),
                java.io.File(pubDir, "veri/song_order_backup.json"),
                java.io.File(pubDir, "song_order_backup.json"),
                java.io.File(pubDir, ".owl_song_order_backup.json"),
                java.io.File(getApplication<Application>().filesDir, "data/song_order_backup.json")
            )
            val existing = candidates.firstOrNull { it.exists() && it.length() > 0 }
            if (existing != null) return existing
            val dataDir = getDataDirectory()
            java.io.File(dataDir, "song_order_backup.json")
        } catch (_: Exception) {
            null
        }
    }

    private fun buildDownloadedKeys(songs: List<SongItem>): Set<String> {
        val set = HashSet<String>(songs.size * 3)
        for (s in songs) {
            set.add(s.id)
            if (!s.localFilePath.isNullOrBlank()) {
                set.add(s.localFilePath)
            }
            val key = "${s.artist.trim().lowercase()}_${s.title.trim().lowercase()}"
            if (key != "_") set.add(key)
        }
        return set
    }

    fun loadDownloadedSongs() {

        loadDownloadsJob?.cancel()
        loadDownloadsJob = viewModelScope.launch(Dispatchers.IO) {
            val local = downloadManager.getLocalSongs()
            var savedOrderJson = songOrderPrefs.getString("custom_order", null)
            if (savedOrderJson.isNullOrBlank()) {
                val backupFile = getSongOrderBackupFile()
                if (backupFile != null && backupFile.exists() && backupFile.length() > 0) {
                    try {
                        savedOrderJson = backupFile.readText(Charsets.UTF_8)
                        if (!savedOrderJson.isNullOrBlank()) {
                            songOrderPrefs.edit().putString("custom_order", savedOrderJson).apply()
                        }
                    } catch (_: Exception) {}
                }
            }

            val orderedList = if (savedOrderJson != null) {
                try {
                    val arr = org.json.JSONArray(savedOrderJson)
                    val idList = (0 until arr.length()).map { arr.getString(it) }
                    val mapById = local.associateBy { it.id }
                    val mapByPath = local.filter { !it.localFilePath.isNullOrBlank() }.associateBy { it.localFilePath!! }

                    val newSongs = local.filter { song ->
                        !idList.contains(song.id) && !idList.contains(song.localFilePath)
                    }

                    val existingSorted = idList.mapNotNull { id ->
                        mapById[id] ?: mapByPath[id]
                    }

                    val sorted = (newSongs + existingSorted).toMutableList()
                    if (newSongs.isNotEmpty()) {
                        persistSongOrder(sorted)
                    }
                    sorted
                } catch (e: Exception) {
                    local
                }
            } else {
                local
            }
            val allWithThumbs = (_uiState.value.playlists.flatMap { it.songs } + _uiState.value.topPlayedCachedSongs + _uiState.value.searchResults)
                .filter { it.thumbnailUrl.isNotBlank() }
                .associateBy { getSongDeduplicationKey(it) }

            val enrichedList = orderedList.map { song ->
                var thumb = song.thumbnailUrl
                if (thumb.isBlank() && !song.localFilePath.isNullOrBlank()) {
                    thumb = downloadManager.resolveThumbnail(java.io.File(song.localFilePath))
                }
                if (thumb.isBlank()) {
                    val dedup = getSongDeduplicationKey(song)
                    allWithThumbs[dedup]?.let { matched ->
                        thumb = matched.thumbnailUrl
                    }
                }
                if (thumb != song.thumbnailUrl) song.copy(thumbnailUrl = thumb) else song
            }

            val keys = buildDownloadedKeys(enrichedList)
            _uiState.value = _uiState.value.copy(
                downloadedSongs = enrichedList,
                downloadedKeys = keys
            )
        }
    }

    fun deleteDownloadedSong(song: SongItem) {
        viewModelScope.launch {

            if (playbackState.value.song?.id == song.id) {
                playerManager.stopPlayback()
            }
            withContext(Dispatchers.IO) {
                val current = _uiState.value.downloadedSongs.filter { it.id != song.id && it.localFilePath != song.localFilePath }
                val keys = buildDownloadedKeys(current)
                _uiState.value = _uiState.value.copy(downloadedSongs = current, downloadedKeys = keys)
                persistSongOrder(current)
                downloadManager.deleteDownloadedSong(song)
            }
            loadDownloadedSongs()
        }
    }

    fun deleteMultipleDownloadedSongs(songs: List<SongItem>) {
        viewModelScope.launch {
            val toDeleteIds = songs.map { it.id }.toSet()

            if (playbackState.value.song?.id in toDeleteIds) {
                playerManager.stopPlayback()
            }
            withContext(Dispatchers.IO) {
                val current = _uiState.value.downloadedSongs.filter { it.id !in toDeleteIds }
                val keys = buildDownloadedKeys(current)
                _uiState.value = _uiState.value.copy(downloadedSongs = current, downloadedKeys = keys)
                persistSongOrder(current)
                for (song in songs) {
                    downloadManager.deleteDownloadedSong(song)
                }
            }
            loadDownloadedSongs()
        }
    }

    private fun persistSongOrder(songs: List<SongItem>) {
        viewModelScope.launch(Dispatchers.IO) {
            val arr = org.json.JSONArray()
            songs.forEach { arr.put(it.id) }
            val jsonStr = arr.toString()
            songOrderPrefs.edit().putString("custom_order", jsonStr).apply()
            try {
                val backupFile = getSongOrderBackupFile()
                if (backupFile != null) {
                    backupFile.writeText(jsonStr, Charsets.UTF_8)
                }
            } catch (_: Exception) {}
        }
    }

    fun moveDownloadedSong(fromIndex: Int, toIndex: Int) {
        val current = _uiState.value.downloadedSongs.toMutableList()
        if (fromIndex in current.indices && toIndex in current.indices) {
            val item = current.removeAt(fromIndex)
            current.add(toIndex, item)
            _uiState.value = _uiState.value.copy(downloadedSongs = current)
            persistSongOrder(current)
        }
    }

    fun moveDownloadedSongToTop(index: Int) {
        moveDownloadedSong(index, 0)
    }

    fun moveDownloadedSongToBottom(index: Int) {
        val current = _uiState.value.downloadedSongs
        if (current.isNotEmpty()) {
            moveDownloadedSong(index, current.lastIndex)
        }
    }

    fun loadPlaylists() {
        viewModelScope.launch {
            val lists = playlistRepo.getPlaylists()
            _uiState.value = _uiState.value.copy(playlists = lists)
        }
    }

    fun createPlaylist(name: String, initialSongs: List<SongItem> = emptyList()) {
        viewModelScope.launch {
            playlistRepo.createPlaylist(name, initialSongs)
            loadPlaylists()
        }
    }

    fun deletePlaylist(playlistId: String) {
        viewModelScope.launch {
            playlistRepo.deletePlaylist(playlistId)
            loadPlaylists()
        }
    }

    fun addSongsToPlaylist(playlistId: String, songs: List<SongItem>) {
        viewModelScope.launch {
            playlistRepo.addSongsToPlaylist(playlistId, songs)
            loadPlaylists()
        }
    }

    fun removeSongFromPlaylist(playlistId: String, songId: String) {
        viewModelScope.launch {
            playlistRepo.removeSongFromPlaylist(playlistId, songId)
            loadPlaylists()
        }
    }

    fun reorderPlaylistSongs(playlistId: String, newSongs: List<SongItem>) {
        viewModelScope.launch {
            playlistRepo.updatePlaylistSongs(playlistId, newSongs)
            loadPlaylists()
        }
    }

    fun setTheme(theme: ThemeMode) {
        _uiState.value = _uiState.value.copy(currentTheme = theme)
    }

    private fun loadLanguagePreferences() {
        val savedLangCode = settingsPrefs.getString("app_language", "tr") ?: "tr"
        val lang = com.elbahram.owlmusic.util.AppLanguage.fromCode(savedLangCode)
        _uiState.value = _uiState.value.copy(
            currentLanguage = lang,
            strings = com.elbahram.owlmusic.util.getStringsForLanguage(lang)
        )
    }

    fun setLanguage(language: com.elbahram.owlmusic.util.AppLanguage) {
        _uiState.value = _uiState.value.copy(
            currentLanguage = language,
            strings = com.elbahram.owlmusic.util.getStringsForLanguage(language)
        )
        viewModelScope.launch(Dispatchers.IO) {
            settingsPrefs.edit().putString("app_language", language.code).apply()
        }
    }

    private fun loadStartScreenPreference() {
        val tab = settingsPrefs.getInt("default_start_tab", 1).coerceIn(0, 3)
        _uiState.value = _uiState.value.copy(defaultStartTab = tab)
    }

    fun setDefaultStartTab(tab: Int) {
        val validTab = tab.coerceIn(0, 3)
        _uiState.value = _uiState.value.copy(defaultStartTab = validTab)
        viewModelScope.launch(Dispatchers.IO) {
            settingsPrefs.edit().putInt("default_start_tab", validTab).apply()
        }
    }

    fun setPlayerSheetVisible(visible: Boolean) {
        _uiState.value = _uiState.value.copy(isPlayerSheetOpen = visible)
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    private val favoritePrefs = getApplication<android.app.Application>()
        .getSharedPreferences("owl_favorites", android.content.Context.MODE_PRIVATE)

    fun isSongFavorite(songId: String): Boolean {
        return favoritePrefs.getBoolean(songId, false)
    }

    fun toggleFavoriteCurrentSong() {
        val currentSong = playbackState.value.song ?: return
        val currentFav = isSongFavorite(currentSong.id)
        val newFav = !currentFav

        viewModelScope.launch(Dispatchers.IO) {
            favoritePrefs.edit().putBoolean(currentSong.id, newFav).apply()
        }

        com.elbahram.owlmusic.service.OwlPlaybackService.updateCustomLayout()

        viewModelScope.launch {
            val allLists = playlistRepo.getPlaylists().toMutableList()
            var favPlaylist = allLists.find { it.name.equals("Favoriler", ignoreCase = true) }
            if (favPlaylist == null && newFav) {
                playlistRepo.createPlaylist("Favoriler", listOf(currentSong))
            } else if (favPlaylist != null) {
                if (newFav) {
                    if (favPlaylist.songs.none { it.id == currentSong.id }) {
                        playlistRepo.addSongsToPlaylist(favPlaylist.id, listOf(currentSong))
                    }
                } else {
                    playlistRepo.removeSongFromPlaylist(favPlaylist.id, currentSong.id)
                }
            }
            loadPlaylists()

            android.os.Handler(android.os.Looper.getMainLooper()).post {
                val template = if (newFav) _uiState.value.strings.addedToFavorites else _uiState.value.strings.removedFromFavorites
                val msg = template.replace("%s", currentSong.title)
                android.widget.Toast.makeText(getApplication(), msg, android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun getSongPlayCountKey(song: SongItem): String {
        return if (song.id.isNotBlank()) song.id else "${song.artist.trim().lowercase()}_${song.title.trim().lowercase()}"
    }

    fun getSongDeduplicationKey(song: SongItem): String {
        val a = song.artist.trim().lowercase().replace(Regex("[^a-z0-9ğüşıöç]"), "")
        val t = song.title.trim().lowercase().replace(Regex("[^a-z0-9ğüşıöç]"), "")
        return "${a}_${t}"
    }

    private fun normalizeForDeduplication(text: String): String {
        return text.trim().lowercase().replace(Regex("[^a-z0-9ğüşıöç]"), "")
    }

    private fun getPlayCountsCandidates(): List<java.io.File> {
        val list = mutableListOf<java.io.File>()
        val pubDir = java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "OwlMusic")
        list.add(java.io.File(pubDir, "data/play_counts.json"))
        list.add(java.io.File(pubDir, "data/top_played.json"))
        list.add(java.io.File(pubDir, "veri/play_counts.json"))
        list.add(java.io.File(pubDir, "veri/top_played.json"))
        list.add(java.io.File(pubDir, "play_counts.json"))
        list.add(java.io.File(pubDir, "top_played.json"))
        list.add(java.io.File(pubDir, ".owl_play_counts.json"))
        list.add(java.io.File(pubDir, ".owl_top_played.json"))
        list.add(java.io.File(getApplication<Application>().filesDir, "data/play_counts.json"))
        list.add(java.io.File(getApplication<Application>().filesDir, "play_counts.json"))
        getApplication<Application>().getExternalFilesDir("data")?.let { list.add(java.io.File(it, "play_counts.json")) }
        getApplication<Application>().getExternalFilesDir("veri")?.let { list.add(java.io.File(it, "play_counts.json")) }
        return list
    }

    private fun getPlayCountsWriteFiles(): List<java.io.File> {
        val list = mutableListOf<java.io.File>()
        try {
            val pubDir = java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "OwlMusic")
            val dataDir = java.io.File(pubDir, "data")
            if (!dataDir.exists()) dataDir.mkdirs()
            val veriDir = java.io.File(pubDir, "veri")
            if (!veriDir.exists()) veriDir.mkdirs()
            list.add(java.io.File(dataDir, "play_counts.json"))
            list.add(java.io.File(veriDir, "play_counts.json"))
            val intData = java.io.File(getApplication<Application>().filesDir, "data")
            if (!intData.exists()) intData.mkdirs()
            list.add(java.io.File(intData, "play_counts.json"))
        } catch (_: Exception) {}
        return list
    }

    fun loadPlayCounts() {
        viewModelScope.launch(Dispatchers.IO) {
            val counts = _uiState.value.playCounts.toMutableMap()
            val cachedMap = _uiState.value.topPlayedCachedSongs.associateBy {
                val d = getSongDeduplicationKey(it)
                if (d.isNotBlank()) d else it.id
            }.toMutableMap()

            val candidateFiles = getPlayCountsCandidates()
            for (file in candidateFiles) {
                if (!file.exists() || file.length() == 0L) continue
                try {
                    val content = file.readText(Charsets.UTF_8)
                    if (content.isBlank()) continue
                    val json = org.json.JSONObject(content)
                    if (json.has("counts")) {
                        val countsObj = json.getJSONObject("counts")
                        val keys = countsObj.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            val c = countsObj.getInt(k)
                            counts[k] = maxOf(counts[k] ?: 0, c)
                        }
                    }
                    if (json.has("top_played")) {
                        val arr = json.getJSONArray("top_played")
                        for (i in 0 until arr.length()) {
                            val item = arr.getJSONObject(i)
                            val title = item.optString("title", "")
                            val artist = item.optString("artist", "")
                            val pCount = item.optInt("play_count", 0)
                            val rawId = item.optString("id", "")
                            val sId = if (rawId.isNotBlank()) rawId else "${artist}_${title}".hashCode().toString()
                            if (title.isNotBlank()) {
                                val sItem = SongItem(
                                    id = sId,
                                    title = title,
                                    artist = artist,
                                    durationText = item.optString("durationText", ""),
                                    durationMs = item.optLong("durationMs", 0L),
                                    thumbnailUrl = item.optString("thumbnailUrl", ""),
                                    localFilePath = item.optString("localFilePath", "").ifEmpty { null },
                                    isDownloaded = item.optBoolean("isDownloaded", false)
                                )
                                val dedup = getSongDeduplicationKey(sItem)
                                val mKey = if (dedup.isNotBlank()) dedup else sId
                                val existing = cachedMap[mKey]
                                if (existing == null) {
                                    cachedMap[mKey] = sItem
                                } else {
                                    cachedMap[mKey] = existing.copy(
                                        thumbnailUrl = if (existing.thumbnailUrl.isBlank()) sItem.thumbnailUrl else existing.thumbnailUrl,
                                        localFilePath = existing.localFilePath ?: sItem.localFilePath,
                                        isDownloaded = existing.isDownloaded || sItem.isDownloaded
                                    )
                                }
                                val pKey = getSongPlayCountKey(sItem)
                                if (pCount > 0) {
                                    if ((counts[pKey] ?: 0) < pCount) counts[pKey] = pCount
                                    if (dedup.isNotBlank() && (counts[dedup] ?: 0) < pCount) counts[dedup] = pCount
                                    if (sId.isNotBlank() && (counts[sId] ?: 0) < pCount) counts[sId] = pCount
                                }
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            val all = playCountPrefs.all
            all.forEach { (key, value) ->
                val count = when (value) {
                    is Int -> value
                    is Number -> value.toInt()
                    else -> 0
                }
                if (count > (counts[key] ?: 0)) {
                    counts[key] = count
                }
            }

            val cachedList = cachedMap.values.toList()
            _uiState.value = _uiState.value.copy(
                playCounts = counts,
                topPlayedCachedSongs = cachedList
            )

            val editor = playCountPrefs.edit()
            counts.forEach { (k, v) -> editor.putInt(k, v) }
            editor.apply()

            if (counts.isNotEmpty()) {
                persistPlayCountsToFile(counts)
            }
        }
    }

    private fun persistPlayCountsToFile(counts: Map<String, Int>) {
        try {
            val root = org.json.JSONObject()
            val countsObj = org.json.JSONObject()
            counts.forEach { (k, v) -> countsObj.put(k, v) }
            root.put("counts", countsObj)

            val allKnown = (_uiState.value.topPlayedCachedSongs +
                    _uiState.value.downloadedSongs +
                    _uiState.value.playlists.flatMap { it.songs } +
                    _uiState.value.searchResults +
                    listOfNotNull(playbackState.value.song))

            val songIndex = mutableMapOf<String, SongItem>()
            allKnown.forEach { s ->
                if (s.id.isNotBlank()) songIndex[s.id] = s
                val pKey = getSongPlayCountKey(s)
                if (pKey.isNotBlank()) songIndex[pKey] = s
                val dedup = getSongDeduplicationKey(s)
                if (dedup.isNotBlank()) songIndex[dedup] = s
                val norm = "${normalizeForDeduplication(s.artist)}_${normalizeForDeduplication(s.title)}"
                if (norm.isNotBlank() && norm != "_") songIndex[norm] = s
            }

            val songsToSave = mutableMapOf<String, Pair<SongItem, Int>>()

            _uiState.value.topPlayedCachedSongs.forEach { cachedSong ->
                val dedup = getSongDeduplicationKey(cachedSong)
                val key = getSongPlayCountKey(cachedSong)
                val count = maxOf(
                    counts[key] ?: 0,
                    counts[dedup] ?: 0,
                    if (cachedSong.id.isNotBlank()) counts[cachedSong.id] ?: 0 else 0
                )
                val mKey = if (dedup.isNotBlank()) dedup else cachedSong.id
                songsToSave[mKey] = Pair(cachedSong, count.coerceAtLeast(1))
            }

            counts.forEach { (key, count) ->
                if (count > 0) {
                    val matchedSong = songIndex[key]
                    if (matchedSong != null) {
                        val dedup = getSongDeduplicationKey(matchedSong)
                        val mKey = if (dedup.isNotBlank()) dedup else matchedSong.id
                        if (!songsToSave.containsKey(mKey) || (songsToSave[mKey]?.second ?: 0) < count) {
                            songsToSave[mKey] = Pair(matchedSong, count)
                        }
                    }
                }
            }

            val songsArray = org.json.JSONArray()
            songsToSave.values.sortedByDescending { it.second }.forEach { (song, count) ->
                val obj = org.json.JSONObject()
                obj.put("id", song.id)
                obj.put("title", song.title)
                obj.put("artist", song.artist)
                obj.put("durationText", song.durationText)
                obj.put("durationMs", song.durationMs)
                obj.put("thumbnailUrl", song.thumbnailUrl)
                obj.put("localFilePath", song.localFilePath ?: "")
                obj.put("isDownloaded", song.isDownloaded)
                obj.put("play_count", count)
                songsArray.put(obj)
            }

            root.put("top_played", songsArray)
            val jsonStr = root.toString(2)

            val writeFiles = getPlayCountsWriteFiles()
            for (f in writeFiles) {
                runCatching {
                    f.parentFile?.mkdirs()
                    f.writeText(jsonStr, Charsets.UTF_8)
                }
            }
        } catch (_: Exception) {}
    }

    fun incrementPlayCount(song: SongItem) {
        val key = getSongPlayCountKey(song)
        val dedupKey = getSongDeduplicationKey(song)
        val currentCount = _uiState.value.playCounts[key] ?: _uiState.value.playCounts[dedupKey] ?: 0
        val newCount = currentCount + 1
        val updated = _uiState.value.playCounts.toMutableMap()
        updated[key] = newCount
        if (dedupKey.isNotBlank() && dedupKey != key) {
            updated[dedupKey] = newCount
        }
        val currentCached = _uiState.value.topPlayedCachedSongs.toMutableList()
        val existingIndex = currentCached.indexOfFirst {
            (song.id.isNotBlank() && it.id == song.id) ||
            (dedupKey.isNotBlank() && getSongDeduplicationKey(it) == dedupKey)
        }
        if (existingIndex >= 0) {
            val old = currentCached[existingIndex]
            currentCached[existingIndex] = old.copy(
                thumbnailUrl = if (old.thumbnailUrl.isBlank()) song.thumbnailUrl else old.thumbnailUrl,
                localFilePath = song.localFilePath ?: old.localFilePath,
                isDownloaded = song.isDownloaded || old.isDownloaded
            )
        } else {
            currentCached.add(song)
        }
        _uiState.value = _uiState.value.copy(playCounts = updated, topPlayedCachedSongs = currentCached)
        viewModelScope.launch(Dispatchers.IO) {
            val editor = playCountPrefs.edit().putInt(key, newCount)
            if (dedupKey.isNotBlank() && dedupKey != key) {
                editor.putInt(dedupKey, newCount)
            }
            editor.apply()
            persistPlayCountsToFile(updated)
        }
    }

    private var sleepTimerJob: Job? = null
    private var sleepTimerEndRealtimeMs: Long = 0L
    private val notificationManager = getApplication<Application>()
        .getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    companion object {
        private const val SLEEP_TIMER_CHANNEL_ID = "owl_sleep_timer_channel"
        private const val SLEEP_TIMER_NOTIFICATION_ID = 2002
        private const val SLEEP_TIMER_ALARM_REQUEST_CODE = 3003
        const val ACTION_CANCEL_SLEEP_TIMER = "com.elbahram.owlmusic.ACTION_CANCEL_SLEEP_TIMER"
    }

    init {
        createSleepTimerNotificationChannel()
        com.elbahram.owlmusic.receiver.SleepTimerReceiver.onCancelRequested = {
            viewModelScope.launch(Dispatchers.Main) {
                cancelSleepTimer(showMessage = true)
            }
        }
        com.elbahram.owlmusic.receiver.SleepTimerReceiver.onTimerExpired = {
            viewModelScope.launch(Dispatchers.Main) {
                onSleepTimerFired()
            }
        }
    }

    private fun createSleepTimerNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                SLEEP_TIMER_CHANNEL_ID,
                "Uyku Zamanlayıcısı",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Müzik duraklatma geri sayım sayacı"
                setShowBadge(false)
                enableVibration(false)
                setSound(null, null)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun startSleepTimer(minutes: Int) {
        if (minutes <= 0) return
        cancelSleepTimer(showMessage = false)

        val totalDurationMs = minutes * 60 * 1000L
        sleepTimerEndRealtimeMs = SystemClock.elapsedRealtime() + totalDurationMs
        val totalSeconds = minutes * 60L
        _uiState.value = _uiState.value.copy(sleepTimerSecondsRemaining = totalSeconds)

        val context = getApplication<Application>()
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        val alarmIntent = Intent(context, com.elbahram.owlmusic.receiver.SleepTimerReceiver::class.java).apply {
            action = com.elbahram.owlmusic.receiver.SleepTimerReceiver.ACTION_SLEEP_TIMER_EXPIRED
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            SLEEP_TIMER_ALARM_REQUEST_CODE,
            alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (alarmManager != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.ELAPSED_REALTIME_WAKEUP,
                        sleepTimerEndRealtimeMs,
                        pendingIntent
                    )
                } else {
                    alarmManager.setExact(
                        AlarmManager.ELAPSED_REALTIME_WAKEUP,
                        sleepTimerEndRealtimeMs,
                        pendingIntent
                    )
                }
            } catch (e: Exception) {
                try {
                    alarmManager.set(
                        AlarmManager.ELAPSED_REALTIME_WAKEUP,
                        sleepTimerEndRealtimeMs,
                        pendingIntent
                    )
                } catch (_: Exception) {}
            }
        }

        showSleepTimerChronometerNotification(System.currentTimeMillis() + totalDurationMs)

        android.os.Handler(android.os.Looper.getMainLooper()).post {
            android.widget.Toast.makeText(
                context,
                "Uyku zamanlayıcısı $minutes dakika olarak ayarlandı.",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }

        sleepTimerJob = viewModelScope.launch(Dispatchers.Main) {
            while (isActive) {
                val remainingMs = sleepTimerEndRealtimeMs - SystemClock.elapsedRealtime()
                val remainingSec = (remainingMs / 1000L).coerceAtLeast(0L)
                if (remainingMs <= 0L) {
                    onSleepTimerFired()
                    break
                }
                _uiState.value = _uiState.value.copy(sleepTimerSecondsRemaining = remainingSec)
                delay(1000L)
            }
        }
    }

    private fun onSleepTimerFired() {
        sleepTimerJob?.cancel()
        sleepTimerJob = null
        sleepTimerEndRealtimeMs = 0L
        clearSleepTimerNotification()
        _uiState.value = _uiState.value.copy(sleepTimerSecondsRemaining = null)

        playerManager.pausePlayback()
        com.elbahram.owlmusic.service.OwlPlaybackService.pausePlayback()

        android.os.Handler(android.os.Looper.getMainLooper()).post {
            android.widget.Toast.makeText(
                getApplication(),
                "Uyku zamanlayıcısı süresi doldu. Müzik duraklatıldı.",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }

    fun cancelSleepTimer(showMessage: Boolean = true) {
        sleepTimerJob?.cancel()
        sleepTimerJob = null
        sleepTimerEndRealtimeMs = 0L

        val context = getApplication<Application>()
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        val alarmIntent = Intent(context, com.elbahram.owlmusic.receiver.SleepTimerReceiver::class.java).apply {
            action = com.elbahram.owlmusic.receiver.SleepTimerReceiver.ACTION_SLEEP_TIMER_EXPIRED
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            SLEEP_TIMER_ALARM_REQUEST_CODE,
            alarmIntent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null && alarmManager != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }

        clearSleepTimerNotification()
        _uiState.value = _uiState.value.copy(sleepTimerSecondsRemaining = null)

        if (showMessage) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(
                    context,
                    "Uyku zamanlayıcısı iptal edildi.",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun showSleepTimerChronometerNotification(targetTimeMillis: Long) {
        val intent = Intent(getApplication(), MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            getApplication(),
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cancelIntent = Intent(getApplication(), com.elbahram.owlmusic.receiver.SleepTimerReceiver::class.java).apply {
            action = com.elbahram.owlmusic.receiver.SleepTimerReceiver.ACTION_CANCEL_SLEEP_TIMER
        }
        val cancelPendingIntent = PendingIntent.getBroadcast(
            getApplication(),
            1,
            cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val largeIconBitmap = try {
            android.graphics.BitmapFactory.decodeResource(getApplication<Application>().resources, R.mipmap.ic_launcher)
        } catch (_: Exception) {
            null
        }

        val notification = NotificationCompat.Builder(getApplication(), SLEEP_TIMER_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .apply {
                if (largeIconBitmap != null) setLargeIcon(largeIconBitmap)
            }
            .setContentTitle("Uyku Zamanlayıcısı")
            .setContentText("Geri sayım devrede")
            .setWhen(targetTimeMillis)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentPendingIntent)
            .addAction(0, "İptal Et", cancelPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        try {
            notificationManager.notify(SLEEP_TIMER_NOTIFICATION_ID, notification)
        } catch (_: Exception) {}
    }

    private fun clearSleepTimerNotification() {
        try {
            notificationManager.cancel(SLEEP_TIMER_NOTIFICATION_ID)
        } catch (_: Exception) {}
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
    }
}

