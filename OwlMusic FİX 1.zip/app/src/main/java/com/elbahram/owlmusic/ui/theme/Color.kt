package com.elbahram.owlmusic.ui.theme

import androidx.compose.ui.graphics.Color

val AmoledBlack = Color(0xFF000000)
val DarkSurface = Color(0xFF111111)
val DarkCard = Color(0xFF181818)
val DarkCardElevated = Color(0xFF222222)
val DarkBorder = Color(0xFF282828)

val DarkTextPrimary = Color(0xFFFFFFFF)
val DarkTextSecondary = Color(0xFF8E8E93)
val DarkTextMuted = Color(0xFF555555)
val DarkAccent = Color(0xFFFFFFFF)

val PitchWhite = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF7F7F8)
val LightCard = Color(0xFFEFEFF0)
val LightCardElevated = Color(0xFFE5E5EA)
val LightBorder = Color(0xFFD8D8DC)

val LightTextPrimary = Color(0xFF000000)
val LightTextSecondary = Color(0xFF6E6E73)
val LightTextMuted = Color(0xFFA0A0A5)
val LightAccent = Color(0xFF000000)

val TextPrimary = DarkTextPrimary
val TextSecondary = DarkTextSecondary
val TextMuted = DarkTextMuted
val SpotifyGreen = Color(0xFFFFFFFF)
