package com.elbahram.owlmusic.data.remote

import android.util.Log
import com.elbahram.owlmusic.YtDlpBootstrap
import com.elbahram.owlmusic.domain.model.ResolvedAudio
import com.elbahram.owlmusic.domain.model.SongItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.AudioStream
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit

class InnerTubeMusicExtractor {

    private val client = OkHttpClient.Builder()
        .dns(PreferIpv4Dns)
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val legacyClient = OkHttpClient.Builder()
        .dns(PreferIpv4Dns)
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private data class InnerTubeClient(
        val label: String,
        val clientName: String,
        val clientVersion: String,
        val userAgent: String,
        val host: String = "https://www.youtube.com",
        val deviceMake: String? = null,
        val deviceModel: String? = null,
        val osName: String? = null,
        val osVersion: String? = null,
        val androidSdkVersion: Int? = null,
        val useThirdPartyEmbed: Boolean = false
    )

    companion object {
        private const val TAG = "InnerTubeExtractor"

        private const val YT_DLP_LOCK_WAIT_MS = 15_000L
        private const val BROWSER_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"

        private val JSON_MEDIA_TYPE = "application/json".toMediaTypeOrNull()

        private const val YT_MUSIC_SONGS_PARAMS = "EgWKAQIIAWoKEAkQBRAKEAMQBA=="

        private val DURATION_REGEX = Regex("^\\d{1,2}:\\d{2}(:\\d{2})?$")

        private val TYPE_LABELS = setOf(
            "Şarkı", "Song", "Video", "Albüm", "Album", "Single", "EP",
            "Çalma Listesi", "Playlist", "Sanatçı", "Artist", "Kısa Video", "Short"
        )

        private val PLAYER_CLIENTS = listOf(
            InnerTubeClient(
                label = "IOS",
                clientName = "IOS",
                clientVersion = "20.10.4",
                userAgent = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_1 like Mac OS X)",
                deviceMake = "Apple",
                deviceModel = "iPhone16,2",
                osName = "iPhone",
                osVersion = "18.3.1.22D72"
            ),
            InnerTubeClient(
                label = "ANDROID_VR",
                clientName = "ANDROID_VR",
                clientVersion = "1.62.27",
                userAgent = "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12; GB) gzip",
                deviceMake = "Oculus",
                deviceModel = "Quest 3",
                osName = "Android",
                osVersion = "12",
                androidSdkVersion = 32
            ),
            InnerTubeClient(
                label = "TVHTML5_EMBED",
                clientName = "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
                clientVersion = "2.0",
                userAgent = "Mozilla/5.0 (PlayStation; PlayStation 4/12.00) AppleWebKit/605.1.15",
                useThirdPartyEmbed = true
            ),
            InnerTubeClient(
                label = "VISIONOS",
                clientName = "VISIONOS",
                clientVersion = "1.3.1",
                userAgent = "Mozilla/5.0 (VisionOS; Mobile; rv:1.3.1) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/21O5181b",
                deviceMake = "Apple",
                deviceModel = "RealityDevice14,1",
                osName = "VisionOS",
                osVersion = "1.3.1"
            )
        )

        private val YT_MUSIC_CLIENT = InnerTubeClient(
            label = "WEB_REMIX",
            clientName = "WEB_REMIX",
            clientVersion = "1.20260819.01.00",
            userAgent = BROWSER_UA,
            host = "https://music.youtube.com"
        )

        @Volatile
        private var cachedInvidiousInstances: List<String>? = null

        @Volatile
        private var cachedInvidiousAt: Long = 0L
    }

    suspend fun searchSongs(query: String): List<SongItem> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return@withContext emptyList()

        val songsOnly = searchViaYouTubeMusic(trimmed, songsOnly = true)
        if (songsOnly.isNotEmpty()) {
            Log.d(TAG, "Arama '$trimmed': ${songsOnly.size} şarkı (YT Music, filtreli)")
            return@withContext rankByRelevance(trimmed, songsOnly)
        }

        val musicAll = searchViaYouTubeMusic(trimmed, songsOnly = false)
        if (musicAll.isNotEmpty()) {
            Log.d(TAG, "Arama '$trimmed': ${musicAll.size} sonuç (YT Music, filtresiz)")
            return@withContext rankByRelevance(trimmed, musicAll)
        }

        val scraperResults = searchViaYouTubeWebScraper(trimmed)
        Log.d(TAG, "Arama '$trimmed': ${scraperResults.size} sonuç (web scraper yedeği)")
        return@withContext rankByRelevance(trimmed, scraperResults)
    }

    private fun rankByRelevance(query: String, songs: List<SongItem>): List<SongItem> {
        val normalizedQuery = normalizeForMatch(query)
        if (normalizedQuery.isEmpty()) return songs.distinctBy { it.id }

        val queryTokens = normalizedQuery.split(' ').filter { it.isNotEmpty() }
        return songs
            .distinctBy { it.id }
            .sortedByDescending { relevanceScore(it, normalizedQuery, queryTokens) }
    }

    private fun relevanceScore(song: SongItem, query: String, queryTokens: List<String>): Int {
        val title = normalizeForMatch(song.title)
        val artist = normalizeForMatch(song.artist)

        var score = when {
            title == query -> 1000
            title.startsWith(query) -> 800
            title.contains(query) -> 600
            queryTokens.isNotEmpty() && queryTokens.all { title.contains(it) } -> 400
            else -> 0
        }

        score += when {
            artist == query -> 300
            artist.contains(query) -> 200
            queryTokens.isNotEmpty() && queryTokens.all { artist.contains(it) } -> 100
            else -> 0
        }

        return score
    }

    private fun normalizeForMatch(input: String): String {
        val source = input.lowercase(Locale.ROOT)
        val out = StringBuilder(source.length)
        for (ch in source) {
            when (ch) {
                'ı', 'î', 'i' -> out.append('i')
                'ş' -> out.append('s')
                'ğ' -> out.append('g')
                'ü', 'û' -> out.append('u')
                'ö' -> out.append('o')
                'ç' -> out.append('c')
                'â' -> out.append('a')
                else -> out.append(if (ch.isLetterOrDigit()) ch else ' ')
            }
        }
        return out.toString().replace(Regex("\\s+"), " ").trim()
    }

    private fun searchViaYouTubeMusic(query: String, songsOnly: Boolean): List<SongItem> {
        val results = mutableListOf<SongItem>()
        try {
            val body = JSONObject().apply {
                put("context", clientContext(YT_MUSIC_CLIENT))
                put("query", query)
                if (songsOnly) put("params", YT_MUSIC_SONGS_PARAMS)
            }
            val json = postJson("${YT_MUSIC_CLIENT.host}/youtubei/v1/search", body, YT_MUSIC_CLIENT)
                ?: return results

            val renderers = mutableListOf<JSONObject>()
            collectByKey(json, "musicResponsiveListItemRenderer", renderers)

            for (item in renderers) {
                if (results.size >= 30) break

                val videoId = item.optJSONObject("playlistItemData")
                    ?.optString("videoId")
                    .orEmpty()
                    .ifEmpty { firstVideoId(item) }
                if (videoId.isEmpty()) continue

                val flexColumns = item.optJSONArray("flexColumns") ?: continue
                val title = firstRunText(flexColumns.optJSONObject(0))
                if (title.isEmpty()) continue

                val subtitleParts = allRunTexts(flexColumns.optJSONObject(1))
                    .filter { it.isNotBlank() && it.trim() != "•" }
                val durationText = subtitleParts.lastOrNull { DURATION_REGEX.matches(it.trim()) }?.trim().orEmpty()
                val artist = subtitleParts
                    .firstOrNull { it.trim() != durationText && it.trim() !in TYPE_LABELS }
                    ?.trim()
                    .orEmpty()
                    .ifEmpty { "YouTube Music" }

                results.add(
                    SongItem(
                        id = videoId,
                        title = title.trim(),
                        artist = artist,
                        durationText = durationText,
                        durationMs = parseDurationMs(durationText),
                        thumbnailUrl = thumbnailOf(item, videoId)
                    )
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "YT Music araması başarısız: ${e.message}")
        }
        return results
    }

    private fun searchViaYouTubeWebScraper(query: String): List<SongItem> {
        val list = mutableListOf<SongItem>()
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://www.youtube.com/results?search_query=$encoded"
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", BROWSER_UA)
                .header("Accept-Language", "tr,en;q=0.9")
                .build()

            client.newCall(req).execute().use { res ->
                val html = res.body?.string() ?: return emptyList()

                val marker = "var ytInitialData = "
                val startIndex = html.indexOf(marker)
                if (startIndex != -1) {
                    val jsonStart = startIndex + marker.length
                    val jsonEnd = html.indexOf(";</script>", jsonStart)
                    if (jsonEnd != -1) {
                        val jsonString = html.substring(jsonStart, jsonEnd)
                        val json = JSONObject(jsonString)
                        val sectionList = json.optJSONObject("contents")
                            ?.optJSONObject("twoColumnSearchResultsRenderer")
                            ?.optJSONObject("primaryContents")
                            ?.optJSONObject("sectionListRenderer")
                            ?.optJSONArray("contents")

                        if (sectionList != null) {
                            for (s in 0 until sectionList.length()) {
                                val itemSection = sectionList.optJSONObject(s)
                                    ?.optJSONObject("itemSectionRenderer")
                                    ?.optJSONArray("contents") ?: continue

                                for (i in 0 until itemSection.length()) {
                                    val videoRenderer = itemSection.optJSONObject(i)
                                        ?.optJSONObject("videoRenderer") ?: continue
                                    val videoId = videoRenderer.optString("videoId")
                                    val title = videoRenderer.optJSONObject("title")
                                        ?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: ""
                                    val artist = videoRenderer.optJSONObject("ownerText")
                                        ?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: ""
                                    val duration = videoRenderer.optJSONObject("lengthText")
                                        ?.optString("simpleText") ?: ""

                                    if (videoId.isNotEmpty() && title.isNotEmpty()) {
                                        list.add(
                                            SongItem(
                                                id = videoId,
                                                title = title,
                                                artist = artist.ifEmpty { "YouTube" },
                                                durationText = duration,
                                                durationMs = parseDurationMs(duration),
                                                thumbnailUrl = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Scraper error: ${e.message}")
        }
        return list
    }

    private val streamCache = android.util.LruCache<String, Pair<ResolvedAudio, Long>>(60)
    private val CACHE_TTL_MS = 2 * 60 * 60 * 1000L

    fun invalidateCache(videoId: String) {
        synchronized(streamCache) {
            streamCache.remove(videoId)
        }
    }

    suspend fun resolveAudioStream(
        videoId: String,
        forceRefresh: Boolean = false,
        bypassInnerTube: Boolean = false
    ): ResolvedAudio? = withContext(Dispatchers.IO) {
        if (videoId.isBlank()) return@withContext null

        if (forceRefresh) {
            invalidateCache(videoId)
        } else {
            synchronized(streamCache) {
                val cached = streamCache.get(videoId)
                if (cached != null && (System.currentTimeMillis() - cached.second) < CACHE_TTL_MS) {
                    Log.d(TAG, "Ses akışı önbellekten anında alındı ($videoId)")
                    return@withContext cached.first
                }
            }
        }

        if (!bypassInnerTube) {
            resolveViaInnerTube(videoId)?.let { resolved ->
                Log.d(TAG, "InnerTube ile ses akışı anında çözüldü ($videoId)")
                synchronized(streamCache) {
                    streamCache.put(videoId, Pair(resolved, System.currentTimeMillis()))
                }
                return@withContext resolved
            }
        }

        YtDlpBootstrap.ensureReady()

        val ytDlpResolved = YtDlpBootstrap.withLockOrNull(YT_DLP_LOCK_WAIT_MS) {
            resolveViaYoutubeDL(videoId)
        }
        ytDlpResolved?.let { resolved ->
            Log.d(TAG, "YoutubeDL ile ses akışı başarıyla çözüldü ($videoId)")
            synchronized(streamCache) {
                streamCache.put(videoId, Pair(resolved, System.currentTimeMillis()))
            }
            return@withContext resolved
        }

        resolveViaNewPipe(videoId)?.let { resolved ->
            Log.d(TAG, "NewPipeExtractor yedeği kullanıldı ($videoId)")
            synchronized(streamCache) {
                streamCache.put(videoId, Pair(resolved, System.currentTimeMillis()))
            }
            return@withContext resolved
        }

        Log.e(TAG, "Hiçbir kaynak $videoId için ses akışı veremedi")
        return@withContext null
    }

    fun resolveViaYoutubeDL(videoId: String): ResolvedAudio? {
        return try {
            val url = "https://www.youtube.com/watch?v=$videoId"
            val request = YoutubeDLRequest(url)
            request.addOption("-f", "bestaudio[ext=m4a]/bestaudio/best")
            request.addOption("--extractor-args", "youtube:player_client=ios,tv_embedded,web")
            val info = YoutubeDL.getInstance().getInfo(request)
            val formats = info.formats
            val bestAudio = formats
                ?.filter { !it.url.isNullOrEmpty() }
                ?.maxByOrNull { it.abr }
                ?: formats?.firstOrNull { !it.url.isNullOrEmpty() }

            val streamUrl = info.url ?: bestAudio?.url ?: return null
            val ext = bestAudio?.ext ?: info.ext ?: "m4a"
            val bitrate = (bestAudio?.abr ?: 128) * 1000

            ResolvedAudio(
                url = streamUrl,
                mimeType = if (ext == "m4a") "audio/mp4" else "audio/webm",
                bitrate = bitrate
            )
        } catch (e: Exception) {
            Log.w(TAG, "YoutubeDL stream çözme hatası ($videoId): ${e.message}")
            null
        }
    }

    suspend fun getAudioStreamUrl(
        videoId: String,
        forceRefresh: Boolean = false,
        bypassInnerTube: Boolean = false
    ): String? = resolveAudioStream(videoId, forceRefresh, bypassInnerTube)?.url

    private fun resolveViaInnerTube(videoId: String): ResolvedAudio? {
        for (c in PLAYER_CLIENTS) {
            try {
                val body = JSONObject().apply {
                    put("context", clientContext(c))
                    put("videoId", videoId)
                    put("contentCheckOk", true)
                    put("racyCheckOk", true)
                }
                if (c.useThirdPartyEmbed) {
                    body.getJSONObject("context").put(
                        "thirdParty",
                        JSONObject().put("embedUrl", "https://www.youtube.com")
                    )
                }

                val json = postJson("${c.host}/youtubei/v1/player", body, c) ?: continue

                val playability = json.optJSONObject("playabilityStatus")
                val status = playability?.optString("status").orEmpty()
                if (status.isNotEmpty() && status != "OK") {

                    Log.w(TAG, "InnerTube[${c.label}] $videoId oynatılamıyor: $status / ${playability?.optString("reason")}")
                    continue
                }

                val streamingData = json.optJSONObject("streamingData")

                val audioCandidates = collectAudioCandidates(streamingData?.optJSONArray("adaptiveFormats"))
                for (audio in audioCandidates) {
                    if (isStreamAccessible(audio.url)) {
                        Log.d(TAG, "InnerTube[${c.label}] akış hazır ve doğrulandı: ${audio.mimeType} ${audio.bitrate / 1000}kbps")
                        return audio
                    } else {
                        Log.w(TAG, "InnerTube[${c.label}] aday (${audio.mimeType}) 403 verdi, sıradaki adaya geçiliyor ($videoId)")
                    }
                }

                pickProgressive(streamingData?.optJSONArray("formats"))?.let { muxed ->
                    if (isStreamAccessible(muxed.url)) {
                        Log.w(TAG, "InnerTube[${c.label}] sadece muxed format var: ${muxed.mimeType}")
                        return muxed
                    }
                }

                Log.w(TAG, "InnerTube[${c.label}] streamingData boş veya erişilebilir format bulunamadı ($videoId)")
            } catch (e: Exception) {
                Log.w(TAG, "InnerTube[${c.label}] hata: ${e.message}")
            }
        }
        return null
    }

    private val preflightClient = client.newBuilder()
        .connectTimeout(2500, TimeUnit.MILLISECONDS)
        .readTimeout(2500, TimeUnit.MILLISECONDS)
        .build()

    private fun isStreamAccessible(url: String): Boolean {
        return try {
            val userAgent = when {
                url.contains("c=ANDROID_TESTSUITE") -> "Google-YouTube-TestSuite/1.9"
                url.contains("c=VISIONOS") -> "Mozilla/5.0 (VisionOS; Mobile; rv:1.3.1) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/21O5181b"
                url.contains("c=ANDROID_VR") -> "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12; GB) gzip"
                url.contains("c=ANDROID") -> "com.google.android.youtube/20.10.38 (Linux; U; Android 14) gzip"
                url.contains("c=IOS") -> "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_1 like Mac OS X)"
                url.contains("c=TVHTML5") -> "Mozilla/5.0 (PlayStation; PlayStation 4/12.00) AppleWebKit/605.1.15"
                url.contains("c=WEB_REMIX") -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
                else -> BROWSER_UA
            }
            val reqBuilder = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .header("Range", "bytes=0-1")
                .get()

            if (url.contains("c=WEB_REMIX")) {
                reqBuilder.header("Referer", "https://music.youtube.com/")
                reqBuilder.header("Origin", "https://music.youtube.com")
            } else if (url.contains("c=WEB") || url.contains("c=TVHTML5")) {
                reqBuilder.header("Referer", "https://www.youtube.com/")
                reqBuilder.header("Origin", "https://www.youtube.com")
            }

            preflightClient.newCall(reqBuilder.build()).execute().use { resp ->
                val ok = resp.code == 200 || resp.code == 206
                if (!ok) {
                    Log.w(TAG, "Ön kontrol başarısız: HTTP ${resp.code} (${url.take(80)}...)")
                }
                ok
            }
        } catch (e: Exception) {
            Log.w(TAG, "Ön kontrol bağlantı hatası: ${e.message}")
            false
        }
    }

    private fun collectAudioCandidates(formats: JSONArray?): List<ResolvedAudio> {
        if (formats == null) return emptyList()
        val mp4List = mutableListOf<ResolvedAudio>()
        val webmList = mutableListOf<ResolvedAudio>()

        for (i in 0 until formats.length()) {
            val format = formats.optJSONObject(i) ?: continue
            val mime = format.optString("mimeType", "")
            if (!mime.startsWith("audio")) continue

            val url = format.optString("url", "")
            if (url.isEmpty()) continue

            val candidate = ResolvedAudio(
                url = url,
                mimeType = mime.substringBefore(';').trim(),
                bitrate = format.optInt("bitrate", 0),
                contentLength = format.optLong("contentLength", 0L)
            )

            when {
                candidate.mimeType.contains("mp4", ignoreCase = true) -> mp4List.add(candidate)
                candidate.mimeType.contains("webm", ignoreCase = true) -> webmList.add(candidate)
            }
        }

        mp4List.sortByDescending { it.bitrate }
        webmList.sortByDescending { it.bitrate }

        val result = mutableListOf<ResolvedAudio>()
        result.addAll(mp4List)
        result.addAll(webmList)
        return result
    }

    private fun pickBestAudio(formats: JSONArray?): ResolvedAudio? {
        return collectAudioCandidates(formats).firstOrNull()
    }

    private fun pickProgressive(formats: JSONArray?): ResolvedAudio? {
        if (formats == null) return null
        var best: ResolvedAudio? = null
        for (i in 0 until formats.length()) {
            val format = formats.optJSONObject(i) ?: continue
            val mime = format.optString("mimeType", "")
            if (!mime.startsWith("video/mp4")) continue
            val url = format.optString("url", "")
            if (url.isEmpty()) continue
            val candidate = ResolvedAudio(
                url = url,
                mimeType = "video/mp4",
                bitrate = format.optInt("bitrate", 0),
                contentLength = format.optLong("contentLength", 0L)
            )
            if (best == null || candidate.bitrate > best.bitrate) best = candidate
        }
        return best
    }

    private fun resolveViaNewPipe(videoId: String): ResolvedAudio? {
        return try {
            val link = "https://www.youtube.com/watch?v=$videoId"
            val extractor = ServiceList.YouTube.getStreamExtractor(link)
            extractor.fetchPage()

            val audioStreams: List<AudioStream> = extractor.audioStreams
            if (audioStreams.isEmpty()) return null

            val best = audioStreams
                .filter { it.isUrl && it.content.isNotEmpty() }
                .maxByOrNull { it.averageBitrate } ?: return null

            ResolvedAudio(
                url = best.content,
                mimeType = best.format?.mimeType ?: "audio/mp4",
                bitrate = best.averageBitrate.takeIf { it > 0 } ?: 0
            )
        } catch (e: Exception) {
            Log.w(TAG, "NewPipeExtractor failed for $videoId: ${e.message}")
            null
        }
    }

    private fun resolveViaLegacyInstances(videoId: String): ResolvedAudio? {

        val pipedHosts = listOf(
            "https://api.piped.private.coffee",
            "https://pipedapi.adminforge.de",
            "https://pipedapi.kavin.rocks"
        )
        for (host in pipedHosts) {
            try {
                val req = Request.Builder()
                    .url("$host/streams/$videoId")
                    .header("User-Agent", BROWSER_UA)
                    .header("Accept", "application/json")
                    .build()
                legacyClient.newCall(req).execute().use { res ->
                    if (!res.isSuccessful) return@use
                    val text = res.body?.string() ?: return@use
                    val json = JSONObject(text)
                    val streams = json.optJSONArray("audioStreams") ?: return@use

                    var bestUrl = ""
                    var bestBitrate = 0
                    for (i in 0 until streams.length()) {
                        val s = streams.getJSONObject(i)
                        val mime = s.optString("mimeType", "")
                        if (!mime.contains("audio")) continue
                        val url = s.optString("proxyUrl").ifEmpty { s.optString("url") }
                        val bitrate = s.optInt("bitrate", 0)
                        if (url.isNotEmpty() && bitrate > bestBitrate) {
                            bestBitrate = bitrate
                            bestUrl = url
                        }
                    }
                    if (bestUrl.isNotEmpty()) {
                        Log.d(TAG, "Piped $host akış verdi")
                        return ResolvedAudio(
                            url = bestUrl,
                            mimeType = "audio/mp4",
                            bitrate = bestBitrate
                        )
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Piped $host failed: ${e.message}")
            }
        }

        for (host in invidiousInstances()) {
            try {
                val req = Request.Builder()
                    .url("$host/api/v1/videos/$videoId?fields=adaptiveFormats&local=true")
                    .header("User-Agent", BROWSER_UA)
                    .build()
                legacyClient.newCall(req).execute().use { res ->
                    if (!res.isSuccessful) return@use
                    val json = JSONObject(res.body?.string() ?: return@use)
                    val formats = json.optJSONArray("adaptiveFormats") ?: return@use

                    var bestUrl = ""
                    var bestBitrate = 0
                    var bestMime = "audio/mp4"
                    for (i in 0 until formats.length()) {
                        val f = formats.getJSONObject(i)
                        val type = f.optString("type", "")
                        if (!type.contains("audio")) continue
                        val url = f.optString("url", "")
                        val bitrate = f.optInt("bitrate", 0)
                        if (url.isNotEmpty() && bitrate > bestBitrate) {
                            bestBitrate = bitrate
                            bestMime = type.substringBefore(';').trim()
                            bestUrl = url
                        }
                    }
                    if (bestUrl.isNotEmpty()) {
                        Log.d(TAG, "Invidious $host akış verdi")
                        return ResolvedAudio(url = bestUrl, mimeType = bestMime, bitrate = bestBitrate)
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Invidious $host failed: ${e.message}")
            }
        }
        return null
    }

    private fun invidiousInstances(): List<String> {
        val cached = cachedInvidiousInstances
        if (cached != null && System.currentTimeMillis() - cachedInvidiousAt < 5 * 60 * 1000L) {
            return cached
        }

        var resolved: List<String> = emptyList()
        try {
            val req = Request.Builder()
                .url("https://api.invidious.io/instances.json?sort_by=type,users")
                .header("User-Agent", BROWSER_UA)
                .build()
            legacyClient.newCall(req).execute().use { res ->
                val text = res.body?.string().orEmpty()
                if (text.isNotEmpty() && res.isSuccessful) {
                    val array = JSONArray(text)
                    val hosts = mutableListOf<String>()
                    for (i in 0 until array.length()) {
                        if (hosts.size >= 3) break
                        val entry = array.optJSONArray(i) ?: continue
                        val info = entry.optJSONObject(1) ?: continue

                        if (!info.optBoolean("api", false)) continue
                        if (info.optString("type") != "https") continue
                        val uri = info.optString("uri")
                        if (uri.isNotEmpty()) hosts.add(uri)
                    }
                    resolved = hosts
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Invidious instance listesi alınamadı: ${e.message}")
        }

        if (resolved.isNotEmpty()) {
            cachedInvidiousInstances = resolved
            cachedInvidiousAt = System.currentTimeMillis()
        }
        return resolved
    }

    private fun clientContext(innerTubeClient: InnerTubeClient): JSONObject {
        val clientObject = JSONObject().apply {
            put("clientName", innerTubeClient.clientName)
            put("clientVersion", innerTubeClient.clientVersion)
            put("hl", "tr")
            put("gl", "TR")
            put("userAgent", innerTubeClient.userAgent)
            innerTubeClient.deviceMake?.let { put("deviceMake", it) }
            innerTubeClient.deviceModel?.let { put("deviceModel", it) }
            innerTubeClient.osName?.let { put("osName", it) }
            innerTubeClient.osVersion?.let { put("osVersion", it) }
            innerTubeClient.androidSdkVersion?.let { put("androidSdkVersion", it) }
        }
        return JSONObject().apply { put("client", clientObject) }
    }

    private fun postJson(url: String, body: JSONObject, innerTubeClient: InnerTubeClient): JSONObject? {
        val request = Request.Builder()
            .url(url)
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .header("Accept-Language", "tr,en;q=0.9")
            .header("User-Agent", innerTubeClient.userAgent)
            .header("Origin", innerTubeClient.host)
            .post(body.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                Log.w(TAG, "${innerTubeClient.label} HTTP ${response.code}: ${text.take(120)}")
                return null
            }
            if (text.isBlank() || text.startsWith("<")) return null
            return try {
                JSONObject(text)
            } catch (e: Exception) {
                Log.w(TAG, "${innerTubeClient.label} JSON değil: ${text.take(80)}")
                null
            }
        }
    }

    private fun collectByKey(node: Any?, key: String, out: MutableList<JSONObject>) {
        when (node) {
            is JSONObject -> {
                val keys = node.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val value = node.opt(k)
                    if (k == key) (value as? JSONObject)?.let { out.add(it) }
                    collectByKey(value, key, out)
                }
            }
            is JSONArray -> for (i in 0 until node.length()) collectByKey(node.opt(i), key, out)
        }
    }

    private fun firstVideoId(node: Any?): String {
        when (node) {
            is JSONObject -> {
                val keys = node.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    if (k == "videoId") {
                        val value = node.optString(k)
                        if (value.isNotEmpty()) return value
                    }
                    val nested = firstVideoId(node.opt(k))
                    if (nested.isNotEmpty()) return nested
                }
            }
            is JSONArray -> for (i in 0 until node.length()) {
                val nested = firstVideoId(node.opt(i))
                if (nested.isNotEmpty()) return nested
            }
        }
        return ""
    }

    private fun firstRunText(column: JSONObject?): String =
        column?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
            ?.optJSONObject("text")
            ?.optJSONArray("runs")
            ?.optJSONObject(0)
            ?.optString("text")
            .orEmpty()

    private fun allRunTexts(column: JSONObject?): List<String> {
        val runs = column?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
            ?.optJSONObject("text")
            ?.optJSONArray("runs") ?: return emptyList()
        return (0 until runs.length()).mapNotNull { runs.optJSONObject(it)?.optString("text") }
    }

    private fun thumbnailOf(item: JSONObject, videoId: String): String {
        val thumbnails = item.optJSONObject("thumbnail")
            ?.optJSONObject("musicThumbnailRenderer")
            ?.optJSONObject("thumbnail")
            ?.optJSONArray("thumbnails")
        if (thumbnails != null && thumbnails.length() > 0) {
            val rawUrl = thumbnails.optJSONObject(thumbnails.length() - 1)?.optString("url").orEmpty()
            if (rawUrl.isNotEmpty()) {
                val fullUrl = if (rawUrl.startsWith("//")) "https:$rawUrl" else rawUrl
                return fullUrl.replace(Regex("=w\\d+-h\\d+.*"), "=w512-h512-l90-rj")
                              .replace(Regex("=s\\d+.*"), "=s512")
            }
        }
        return if (videoId.isNotEmpty()) "https://i.ytimg.com/vi/$videoId/hqdefault.jpg" else ""
    }

    private fun parseDurationMs(text: String): Long {
        if (text.isBlank()) return 0L
        val parts = text.trim().split(":")
        return try {
            when (parts.size) {
                3 -> (parts[0].toLong() * 3600 + parts[1].toLong() * 60 + parts[2].toLong()) * 1000
                2 -> (parts[0].toLong() * 60 + parts[1].toLong()) * 1000
                else -> 0L
            }
        } catch (e: NumberFormatException) {
            0L
        }
    }
}
