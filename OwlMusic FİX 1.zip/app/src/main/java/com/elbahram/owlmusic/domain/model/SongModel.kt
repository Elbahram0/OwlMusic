package com.elbahram.owlmusic.domain.model

data class SongItem(
    val id: String,
    val title: String,
    val artist: String,
    val durationText: String = "",
    val durationMs: Long = 0L,
    val thumbnailUrl: String = "",
    val streamUrl: String? = null,
    val localFilePath: String? = null,
    val isDownloaded: Boolean = false
) {
    val isLocal: Boolean get() = !localFilePath.isNullOrEmpty()
}

data class ResolvedAudio(
    val url: String,
    val mimeType: String = "audio/mp4",
    val bitrate: Int = 0,
    val contentLength: Long = 0L
) {

    val isHls: Boolean get() = url.contains("/manifest/hls", ignoreCase = true) ||
        url.contains("hls_variant", ignoreCase = true)
}

enum class PlaybackStatus {
    IDLE,
    BUFFERING,
    PLAYING,
    PAUSED,
    ERROR
}

data class CurrentPlayback(
    val song: SongItem? = null,
    val status: PlaybackStatus = PlaybackStatus.IDLE,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isShuffle: Boolean = false,
    val isRepeat: Boolean = false
) {
    val progress: Float
        get() = if (durationMs > 0) (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
}

data class DownloadProgress(
    val songId: String,
    val progressPercent: Int = 0,
    val bytesDownloaded: Long = 0L,
    val totalBytes: Long = 0L,
    val isCompleted: Boolean = false,
    val localFilePath: String? = null,
    val error: String? = null
)

data class Playlist(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val songs: List<SongItem> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
)

