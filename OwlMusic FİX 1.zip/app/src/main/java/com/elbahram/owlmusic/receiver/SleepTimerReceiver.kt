package com.elbahram.owlmusic.receiver

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.elbahram.owlmusic.service.OwlPlaybackService

class SleepTimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        notificationManager?.cancel(2002)

        when (intent?.action) {
            ACTION_CANCEL_SLEEP_TIMER -> {
                onCancelRequested?.invoke()
            }
            ACTION_SLEEP_TIMER_EXPIRED -> {
                OwlPlaybackService.pausePlayback()
                onTimerExpired?.invoke()
            }
        }
    }

    companion object {
        const val ACTION_CANCEL_SLEEP_TIMER = "com.elbahram.owlmusic.ACTION_CANCEL_SLEEP_TIMER"
        const val ACTION_SLEEP_TIMER_EXPIRED = "com.elbahram.owlmusic.ACTION_SLEEP_TIMER_EXPIRED"

        var onCancelRequested: (() -> Unit)? = null
        var onTimerExpired: (() -> Unit)? = null
    }
}
