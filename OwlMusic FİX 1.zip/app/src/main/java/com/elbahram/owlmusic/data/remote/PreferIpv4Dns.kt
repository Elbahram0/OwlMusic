package com.elbahram.owlmusic.data.remote

import okhttp3.Dns
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress

object PreferIpv4Dns : Dns {

    override fun lookup(hostname: String): List<InetAddress> {
        val resolved = try {
            Dns.SYSTEM.lookup(hostname)
        } catch (e: Exception) {
            try {
                InetAddress.getAllByName(hostname).toList()
            } catch (e2: Exception) {
                throw e
            }
        }
        if (resolved.size <= 1) return resolved

        val ipv4 = resolved.filterIsInstance<Inet4Address>()
        val ipv6 = resolved.filterIsInstance<Inet6Address>()
        return when {
            ipv4.isEmpty() -> resolved
            ipv6.isEmpty() -> resolved
            else -> ipv4 + ipv6
        }
    }
}
