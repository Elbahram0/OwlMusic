package com.elbahram.owlmusic.player

import android.net.Uri
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSourceException
import androidx.media3.datasource.DataSpec
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okio.BufferedSource
import java.io.IOException

@UnstableApi
class OwlOkHttpDataSource private constructor(
    private val client: OkHttpClient,
    private val userAgent: String
) : BaseDataSource( true) {

    private companion object {
        const val TAG = "OwlDataSource"
    }

    private var currentUri: Uri? = null
    private var response: Response? = null
    private var source: BufferedSource? = null
    private var bytesRemaining: Long = C.LENGTH_UNSET.toLong()
    private var transferOpened = false

    override fun open(dataSpec: DataSpec): Long {
        currentUri = dataSpec.uri
        transferInitializing(dataSpec)

        val rangeHeader = if (dataSpec.length == C.LENGTH_UNSET.toLong()) {
            "bytes=${dataSpec.position}-"
        } else {
            "bytes=${dataSpec.position}-${dataSpec.position + dataSpec.length - 1}"
        }

        val uriStr = dataSpec.uri.toString()
        val effectiveUserAgent = when {
            uriStr.contains("c=IOS") -> "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_1 like Mac OS X)"
            uriStr.contains("c=ANDROID_VR") -> "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12; GB) gzip"
            uriStr.contains("c=TVHTML5") -> "Mozilla/5.0 (PlayStation; PlayStation 4/12.00) AppleWebKit/605.1.15"
            uriStr.contains("c=VISIONOS") -> "Mozilla/5.0 (VisionOS; Mobile; rv:1.3.1) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/21O5181b"
            uriStr.contains("c=ANDROID_TESTSUITE") -> "Google-YouTube-TestSuite/1.9"
            uriStr.contains("c=ANDROID") -> "com.google.android.youtube/19.29.37 (Linux; U; Android 14)"
            uriStr.contains("c=WEB_REMIX") -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
            uriStr.contains("c=WEB") -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
            else -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
        }

        val requestBuilder = Request.Builder()
            .url(uriStr)
            .header("Range", rangeHeader)
            .header("Accept-Encoding", "identity")
            .header("User-Agent", effectiveUserAgent)

        if (uriStr.contains("c=WEB_REMIX")) {
            requestBuilder.header("Referer", "https://music.youtube.com/")
            requestBuilder.header("Origin", "https://music.youtube.com")
        } else if (uriStr.contains("c=WEB") || uriStr.contains("c=TVHTML5")) {
            requestBuilder.header("Referer", "https://www.youtube.com/")
            requestBuilder.header("Origin", "https://www.youtube.com")
        }

        for ((name, value) in dataSpec.httpRequestHeaders) {
            requestBuilder.header(name, value)
        }

        val newResponse = try {
            client.newCall(requestBuilder.build()).execute()
        } catch (e: IOException) {
            throw DataSourceException(
                "OkHttp bağlantı hatası: ${e.message}",
                e,
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
            )
        }

        val code = newResponse.code
        if (!newResponse.isSuccessful) {
            val bodySnippet = try {
                newResponse.peekBody(1024).string()
            } catch (e: Exception) {
                ""
            }
            val finalUrl = newResponse.request.url.toString()
            Log.e(
                TAG,
                "HTTP $code (${newResponse.message}) url=$finalUrl range=$rangeHeader " +
                    "body=${bodySnippet.replace('\n', ' ').take(400)}"
            )
            newResponse.close()
            throw DataSourceException(
                "HTTP $code - ${bodySnippet.take(200)}",
                PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS
            )
        }

        val body = newResponse.body
        if (body == null) {
            newResponse.close()
            throw DataSourceException(
                "Yanıt gövdesi boş (HTTP $code)",
                PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS
            )
        }

        response = newResponse
        source = body.source()
        bytesRemaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) {
            dataSpec.length
        } else {
            body.contentLength().takeIf { it >= 0 } ?: C.LENGTH_UNSET.toLong()
        }

        Log.d(
            TAG,
            "Açıldı: HTTP $code $rangeHeader kalan=$bytesRemaining url=${dataSpec.uri}"
        )
        transferStarted(dataSpec)
        transferOpened = true
        return bytesRemaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (bytesRemaining == 0L) return C.RESULT_END_OF_INPUT

        val src = source ?: return C.RESULT_END_OF_INPUT
        val toRead = if (bytesRemaining == C.LENGTH_UNSET.toLong()) {
            length
        } else {
            minOf(length.toLong(), bytesRemaining).toInt()
        }

        val bytesRead = try {
            src.read(buffer, offset, toRead)
        } catch (e: IOException) {
            throw DataSourceException(
                e,
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
            )
        }

        if (bytesRead == -1) return C.RESULT_END_OF_INPUT
        if (bytesRemaining != C.LENGTH_UNSET.toLong()) {
            bytesRemaining -= bytesRead
        }
        bytesTransferred(bytesRead)
        return bytesRead
    }

    override fun getUri(): Uri? = currentUri

    override fun close() {
        try {
            source?.close()
        } catch (e: IOException) {
            throw DataSourceException(e, PlaybackException.ERROR_CODE_IO_UNSPECIFIED)
        } finally {
            source = null
            response = null
            currentUri = null
            bytesRemaining = C.LENGTH_UNSET.toLong()
            if (transferOpened) {
                transferOpened = false
                transferEnded()
            }
        }
    }

    @UnstableApi
    class Factory(
        private val client: OkHttpClient,
        private val userAgent: String
    ) : DataSource.Factory {
        override fun createDataSource(): DataSource = OwlOkHttpDataSource(client, userAgent)
    }
}
