package com.elbahram.owlmusic.player

import android.content.ComponentName
import android.content.Context
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.HttpDataSource
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.elbahram.owlmusic.domain.model.CurrentPlayback
import com.elbahram.owlmusic.domain.model.PlaybackStatus
import com.elbahram.owlmusic.domain.model.SongItem
import com.elbahram.owlmusic.service.OwlPlaybackService
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

@OptIn(UnstableApi::class)
class OwlPlayerManager(private val context: Context) {

    private companion object {
        const val TAG = "OwlPlayerManager"
        const val MAX_URL_REFRESH_RETRIES = 2
    }

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private val _playbackState = MutableStateFlow(CurrentPlayback())
    val playbackState: StateFlow<CurrentPlayback> = _playbackState.asStateFlow()

    private val _progressState = MutableStateFlow(Pair(0L, 0L))
    val progressState: StateFlow<Pair<Long, Long>> = _progressState.asStateFlow()

    private val _errorEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val errorEvents: SharedFlow<String> = _errorEvents.asSharedFlow()

    var streamUrlResolver: (suspend (String) -> String?)? = null
    var onSongEndedListener: (() -> Unit)? = null
    var onSongPlayedListener: ((SongItem) -> Unit)? = null
    var onNextRequested: (() -> Unit)? = null
    var onPreviousRequested: (() -> Unit)? = null
    var onStopRequested: (() -> Unit)? = null
    var onFavoriteRequested: (() -> Unit)? = null

    private var urlRefreshAttempts = 0
    private var isChangingSong = false
    private var isStoppingPlayback = false
    private var currentRequestId = 0L
    private var hasCountedCurrentPlay = false

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var progressTrackerJob: Job? = null

    init {
        initController()
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            updateState()
            if (state == Player.STATE_ENDED && !isChangingSong && !isStoppingPlayback) {
                val currentSong = _playbackState.value.song
                val hasMedia = controller?.currentMediaItem != null
                if (currentSong != null && hasMedia) {
                    if (!hasCountedCurrentPlay) {
                        hasCountedCurrentPlay = true
                        onSongPlayedListener?.invoke(currentSong)
                    }
                    onSongEndedListener?.invoke()
                }
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updateState()
            if (isPlaying) {
                startProgressTracker()
            } else {
                stopProgressTracker()
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            updateState()
        }

        override fun onPlayerError(error: PlaybackException) {
            val song = _playbackState.value.song
            val player = controller
            val activeMediaId = player?.currentMediaItem?.mediaId

            if (isChangingSong || (song != null && activeMediaId != null && activeMediaId != song.id)) {
                Log.d(TAG, "Eski veya iptal edilen şarkıya ait hata yoksayıldı: ${error.errorCodeName}")
                return
            }

            Log.e(TAG, "Oynatma hatası: ${error.errorCodeName} (${error.errorCode}) - ${error.message}", error)

            val isBadHttpStatus = error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS
            val isNetworkOrSourceError = isBadHttpStatus ||
                error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                error.errorCode == PlaybackException.ERROR_CODE_IO_UNSPECIFIED ||
                error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
                (error.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode == 403 ||
                error.message?.contains("403") == true ||
                error.cause?.message?.contains("403") == true

            if (isNetworkOrSourceError && song != null && urlRefreshAttempts < MAX_URL_REFRESH_RETRIES) {
                urlRefreshAttempts++
                val requestId = currentRequestId
                _playbackState.value = _playbackState.value.copy(status = PlaybackStatus.BUFFERING)
                scope.launch {
                    val fresh = try {
                        streamUrlResolver?.invoke(song.id)
                    } catch (e: Exception) {
                        Log.w(TAG, "Taze akış URL'si çözülemedi: ${e.message}")
                        null
                    }
                    if (currentRequestId != requestId) return@launch
                    if (!fresh.isNullOrEmpty()) {
                        playSong(song.copy(isDownloaded = false, localFilePath = null), fresh, isRetry = true)
                    } else {
                        reportPlaybackError(error, null, "Akış yenilenemedi")
                    }
                }
                return
            }

            reportPlaybackError(error, null, "")
        }
    }

    private fun startServiceExplicitly() {
        try {
            val intent = android.content.Intent(context, OwlPlaybackService::class.java)
            context.startService(intent)
        } catch (e: Exception) {
            Log.e(TAG, "startServiceExplicitly error: ${e.message}", e)
        }
    }

    private fun initController(onConnected: ((MediaController) -> Unit)? = null) {
        startServiceExplicitly()
        OwlPlaybackService.onNextTrackRequested = {
            scope.launch {
                onNextRequested?.invoke()
            }
        }
        OwlPlaybackService.onPreviousTrackRequested = {
            scope.launch {
                onPreviousRequested?.invoke()
            }
        }
        OwlPlaybackService.onStopRequested = {
            scope.launch {
                onStopRequested?.invoke() ?: stopPlayback()
            }
        }
        OwlPlaybackService.onFavoriteRequested = {
            scope.launch {
                onFavoriteRequested?.invoke()
            }
        }

        try {
            val sessionToken = SessionToken(context, ComponentName(context, OwlPlaybackService::class.java))
            controllerFuture?.let { MediaController.releaseFuture(it) }
            val future = MediaController.Builder(context, sessionToken).buildAsync()
            controllerFuture = future
            future.addListener({
                try {
                    val c = future.get()
                    controller = c
                    setupPlayerListener()
                    if (c != null && c.isConnected) {
                        onConnected?.invoke(c)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "MediaController bağlanırken hata oluştu: ${e.message}", e)
                }
            }, androidx.core.content.ContextCompat.getMainExecutor(context))
        } catch (e: Exception) {
            Log.e(TAG, "initController hatası: ${e.message}", e)
        }
    }

    private fun getOrConnectController(action: (MediaController) -> Unit) {
        val current = controller
        if (current != null && current.isConnected) {
            action(current)
        } else {
            initController { action(it) }
        }
    }

    private fun setupPlayerListener() {
        val player = controller ?: return
        player.removeListener(playerListener)
        player.addListener(playerListener)
    }

    private fun reportPlaybackError(
        error: PlaybackException,
        httpError: HttpDataSource.InvalidResponseCodeException?,
        body: String
    ) {
        val detail = if (httpError != null) {
            val serverReason = if (body.isNotEmpty()) " — sunucu: $body" else ""
            "HTTP ${httpError.responseCode}$serverReason"
        } else {
            error.message ?: error.errorCodeName
        }
        _errorEvents.tryEmit("Oynatma hatası: $detail")
        _playbackState.value = _playbackState.value.copy(status = PlaybackStatus.ERROR)
    }

    private fun updateState() {
        val player = controller ?: return
        val currentSong = _playbackState.value.song ?: return
        val isPlaying = player.isPlaying
        val state = when (player.playbackState) {
            Player.STATE_BUFFERING -> PlaybackStatus.BUFFERING
            Player.STATE_READY -> if (isPlaying) PlaybackStatus.PLAYING else PlaybackStatus.PAUSED
            Player.STATE_ENDED -> PlaybackStatus.PAUSED
            Player.STATE_IDLE -> {
                if (isChangingSong || (player.playWhenReady && _playbackState.value.status == PlaybackStatus.BUFFERING)) {
                    PlaybackStatus.BUFFERING
                } else {
                    PlaybackStatus.IDLE
                }
            }
            else -> if (isChangingSong) PlaybackStatus.BUFFERING else PlaybackStatus.IDLE
        }

        _playbackState.value = _playbackState.value.copy(
            song = currentSong,
            status = state,
            currentPositionMs = player.currentPosition.coerceAtLeast(0L),
            durationMs = player.duration.coerceAtLeast(0L),
            isShuffle = player.shuffleModeEnabled,
            isRepeat = player.repeatMode != Player.REPEAT_MODE_OFF
        )
    }

    private fun startProgressTracker() {
        progressTrackerJob?.cancel()

        progressTrackerJob = scope.launch(Dispatchers.Main.immediate) {
            while (isActive) {
                val player = controller
                if (player != null && player.isPlaying) {
                    val pos = player.currentPosition.coerceAtLeast(0L)
                    val dur = player.duration.coerceAtLeast(0L)

                    _progressState.value = Pair(pos, dur)

                    if (!hasCountedCurrentPlay && (pos >= 15_000L || (dur in 1L..30_000L && pos >= (dur / 2)))) {
                        hasCountedCurrentPlay = true
                        _playbackState.value.song?.let { playedSong ->
                            onSongPlayedListener?.invoke(playedSong)
                        }
                    }
                }
                delay(500)
            }
        }
    }

    private fun stopProgressTracker() {
        progressTrackerJob?.cancel()
        progressTrackerJob = null
    }

    fun prepareSong(song: SongItem) {
        _playbackState.value = CurrentPlayback(
            song = song,
            status = PlaybackStatus.BUFFERING
        )
        _progressState.value = Pair(0L, song.durationMs)
    }

    fun playSong(song: SongItem, directMediaUri: String, isRetry: Boolean = false) {
        if (!isRetry) urlRefreshAttempts = 0
        hasCountedCurrentPlay = false
        val requestId = ++currentRequestId
        startServiceExplicitly()

        _playbackState.value = CurrentPlayback(
            song = song.copy(streamUrl = directMediaUri),
            status = PlaybackStatus.BUFFERING
        )
        _progressState.value = Pair(0L, song.durationMs)

        getOrConnectController { player ->
            if (currentRequestId != requestId) return@getOrConnectController

            val artUri = if (song.thumbnailUrl.isNotBlank()) {
                val clean = song.thumbnailUrl.trim()
                try {
                    when {
                        clean.startsWith("http://") || clean.startsWith("https://") -> android.net.Uri.parse(clean)
                        clean.startsWith("content://") || clean.startsWith("file:") -> android.net.Uri.parse(clean)
                        else -> android.net.Uri.fromFile(java.io.File(clean))
                    }
                } catch (e: Exception) {
                    null
                }
            } else null

            val metadata = MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setDisplayTitle(song.title)
                .setSubtitle(song.artist)
                .setAlbumTitle(song.artist)
                .setArtworkUri(artUri)
                .build()

            val parsedMediaUri = try {
                when {
                    directMediaUri.startsWith("http://") || directMediaUri.startsWith("https://") -> android.net.Uri.parse(directMediaUri)
                    directMediaUri.startsWith("content://") || directMediaUri.startsWith("file:") -> android.net.Uri.parse(directMediaUri)
                    else -> android.net.Uri.fromFile(java.io.File(directMediaUri))
                }
            } catch (e: Exception) {
                android.net.Uri.parse(directMediaUri)
            }

            val mediaItem = MediaItem.Builder()
                .setUri(parsedMediaUri)
                .setMediaId(song.id)
                .setMediaMetadata(metadata)
                .build()

            isChangingSong = true
            try {
                player.setMediaItem(mediaItem, 0L)
                player.repeatMode = if (_playbackState.value.isRepeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                player.shuffleModeEnabled = _playbackState.value.isShuffle
                player.prepare()
                player.play()
                OwlPlaybackService.updateCustomLayout()
            } catch (e: Exception) {
                Log.e(TAG, "playSong player error: ${e.message}", e)
            } finally {
                scope.launch {
                    kotlinx.coroutines.delay(800)
                    if (currentRequestId == requestId) {
                        isChangingSong = false
                    }
                }
            }
        }
    }

    fun hasMediaItem(): Boolean {
        val player = controller ?: return false
        return player.isConnected && player.currentMediaItem != null && player.playbackState != Player.STATE_IDLE
    }

    fun pausePlayback() {
        controller?.pause()
    }

    fun togglePlayPause() {
        startServiceExplicitly()
        getOrConnectController { player ->
            if (player.isPlaying) {
                player.pause()
            } else {
                if (player.playbackState == Player.STATE_ENDED) {
                    player.seekTo(0)
                }
                if (player.playbackState == Player.STATE_IDLE) {
                    player.prepare()
                }
                player.play()
            }
        }
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
    }

    fun seekRatio(ratio: Float) {
        val duration = controller?.duration ?: 0L
        if (duration > 0) {
            val target = (duration * ratio).toLong()
            seekTo(target)
        }
    }

    fun toggleShuffle() {
        val player = controller
        if (player != null && player.isConnected) {
            val current = player.shuffleModeEnabled
            player.shuffleModeEnabled = !current
            _playbackState.value = _playbackState.value.copy(isShuffle = !current)
        } else {
            val current = _playbackState.value.isShuffle
            _playbackState.value = _playbackState.value.copy(isShuffle = !current)
        }
    }

    fun toggleRepeat() {
        val player = controller
        if (player != null && player.isConnected) {
            val newMode = if (player.repeatMode == Player.REPEAT_MODE_OFF) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            player.repeatMode = newMode
            _playbackState.value = _playbackState.value.copy(isRepeat = newMode != Player.REPEAT_MODE_OFF)
        } else {
            val current = _playbackState.value.isRepeat
            _playbackState.value = _playbackState.value.copy(isRepeat = !current)
        }
    }

    fun stopPlayback() {
        isStoppingPlayback = true
        stopProgressTracker()
        _playbackState.value = CurrentPlayback(song = null, status = PlaybackStatus.IDLE)
        _progressState.value = Pair(0L, 0L)
        val player = controller
        if (player != null && player.isConnected) {
            try {
                player.pause()
                player.stop()
                player.clearMediaItems()
            } catch (e: Exception) {
                Log.e(TAG, "stopPlayback error: ${e.message}", e)
            }
        }
        scope.launch {
            kotlinx.coroutines.delay(600)
            isStoppingPlayback = false
        }
    }

    fun release() {
        stopProgressTracker()
        scope.cancel()

        OwlPlaybackService.onNextTrackRequested = null
        OwlPlaybackService.onPreviousTrackRequested = null
        OwlPlaybackService.onStopRequested = null
        OwlPlaybackService.onFavoriteRequested = null
        OwlPlaybackService.isFavoriteProvider = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
    }
}
