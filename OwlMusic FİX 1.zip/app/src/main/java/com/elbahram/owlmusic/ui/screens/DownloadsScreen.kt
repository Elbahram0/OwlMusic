package com.elbahram.owlmusic.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListItemInfo
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.elbahram.owlmusic.domain.model.PlaybackStatus
import com.elbahram.owlmusic.domain.model.Playlist
import com.elbahram.owlmusic.domain.model.SongItem
import com.elbahram.owlmusic.ui.components.OwlSearchBar
import com.elbahram.owlmusic.ui.components.SongArtwork
import com.elbahram.owlmusic.ui.viewmodel.HomeUiState
import com.elbahram.owlmusic.ui.viewmodel.MainViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@Composable
fun DownloadsContent(
    viewModel: MainViewModel,
    uiState: HomeUiState,
    currentSongId: String?,
    isPlaying: Boolean,
    isBuffering: Boolean,
    listState: LazyListState
) {
    val s = uiState.strings
    var searchQuery by remember { mutableStateOf("") }

    var isMultiSelectMode by remember { mutableStateOf(false) }
    val selectedSongs = remember { mutableStateListOf<SongItem>() }

    var showTopMenu by remember { mutableStateOf(false) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var showAddToPlaylistDialog by remember { mutableStateOf(false) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var singleSongForAction by remember { mutableStateOf<SongItem?>(null) }

    val filteredSongs = remember(uiState.downloadedSongs, searchQuery) {
        if (searchQuery.isBlank()) {
            uiState.downloadedSongs
        } else {
            uiState.downloadedSongs.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.artist.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    if (showCreatePlaylistDialog) {
        var playlistName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreatePlaylistDialog = false },
            title = { Text(s.newPlaylistDialogTitle, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        text = if (selectedSongs.isNotEmpty()) {
                            s.songsWillBeAddedCount.replace("%d", "${selectedSongs.size}")
                        } else {
                            s.allDownloadsWillBeAdded
                        },
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = playlistName,
                        onValueChange = { playlistName = it },
                        label = { Text(s.playlistNameLabel) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = playlistName.isNotBlank(),
                    onClick = {
                        val songsToAdd = if (selectedSongs.isNotEmpty()) selectedSongs.toList() else uiState.downloadedSongs
                        viewModel.createPlaylist(playlistName.trim(), songsToAdd)
                        showCreatePlaylistDialog = false
                        isMultiSelectMode = false
                        selectedSongs.clear()
                    }
                ) {
                    Text(s.create, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreatePlaylistDialog = false }) {
                    Text(s.cancel)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    if (showAddToPlaylistDialog) {
        val songsToAdd = if (singleSongForAction != null) listOf(singleSongForAction!!) else selectedSongs.toList()
        AlertDialog(
            onDismissRequest = {
                showAddToPlaylistDialog = false
                singleSongForAction = null
            },
            title = { Text(s.addToPlaylistDialogTitle, fontWeight = FontWeight.Bold) },
            text = {
                if (uiState.playlists.isEmpty()) {
                    Text(s.noPlaylistsCreatedYet, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        itemsIndexed(uiState.playlists) { _, playlist ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.addSongsToPlaylist(playlist.id, songsToAdd)
                                        showAddToPlaylistDialog = false
                                        singleSongForAction = null
                                        isMultiSelectMode = false
                                        selectedSongs.clear()
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.QueueMusic, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(playlist.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                    Spacer(modifier = Modifier.weight(1f))
                                    Text(s.songsCountInList.replace("%d", "${playlist.songs.size}"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showAddToPlaylistDialog = false
                    singleSongForAction = null
                }) {
                    Text(s.close)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    if (showSleepTimerDialog) {
        var customMinutesText by remember { mutableStateOf("") }
        val isTimerActive = uiState.sleepTimerSecondsRemaining != null && uiState.sleepTimerSecondsRemaining > 0
        val remainingFormatted = if (isTimerActive) {
            val rem = uiState.sleepTimerSecondsRemaining ?: 0L
            val m = rem / 60
            val sSec = rem % 60
            String.format(java.util.Locale.US, "%02d:%02d", m, sSec)
        } else null

        AlertDialog(
            onDismissRequest = { showSleepTimerDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(s.sleepTimerTitle, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (isTimerActive && remainingFormatted != null) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = s.sleepTimerActive,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    Text(
                                        text = "${s.sleepTimerRemaining.replace("%s", remainingFormatted)}",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Button(
                                    onClick = {
                                        viewModel.cancelSleepTimer()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(s.cancel, fontSize = 12.sp, color = MaterialTheme.colorScheme.onError)
                                }
                            }
                        }
                    }

                    val presets = listOf(
                        15 to "15 ${s.minutesUnit}",
                        30 to "30 ${s.minutesUnit}",
                        45 to "45 ${s.minutesUnit}",
                        60 to "60 ${s.minutesUnit}"
                    )

                    presets.forEach { (mins, label) ->
                        OutlinedButton(
                            onClick = {
                                viewModel.startSleepTimer(mins)
                                showSleepTimerDialog = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(label, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    Text(
                        text = "${s.sleepTimerTitle} (${s.minutesUnit}):",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = customMinutesText,
                            onValueChange = { input ->
                                if (input.all { it.isDigit() } && input.length <= 4) {
                                    customMinutesText = input
                                }
                            },
                            placeholder = { Text(s.exampleMinutes) },
                            singleLine = true,
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                            ),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Button(
                            onClick = {
                                val mins = customMinutesText.toIntOrNull() ?: 0
                                if (mins > 0) {
                                    viewModel.startSleepTimer(mins)
                                    showSleepTimerDialog = false
                                }
                            },
                            enabled = (customMinutesText.toIntOrNull() ?: 0) > 0,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(s.start)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSleepTimerDialog = false }) {
                    Text(s.close)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isMultiSelectMode) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = {
                        isMultiSelectMode = false
                        selectedSongs.clear()
                    }) {
                        Icon(Icons.Default.Close, contentDescription = s.cancel)
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = s.selectedCountText.replace("%d", "${selectedSongs.size}"),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        if (selectedSongs.size == filteredSongs.size) {
                            selectedSongs.clear()
                        } else {
                            selectedSongs.clear()
                            selectedSongs.addAll(filteredSongs)
                        }
                    }) {
                        Text(
                            text = if (selectedSongs.size == filteredSongs.size) s.unselectAll else s.selectAll,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (selectedSongs.isNotEmpty()) {
                        IconButton(onClick = { showAddToPlaylistDialog = true }) {
                            Icon(Icons.AutoMirrored.Filled.PlaylistAdd, contentDescription = s.addToList, tint = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = {
                            viewModel.deleteMultipleDownloadedSongs(selectedSongs.toList())
                            isMultiSelectMode = false
                            selectedSongs.clear()
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = s.delete, tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            } else {
                Text(
                    text = "${uiState.downloadedSongs.size} ${s.songsCountSuffix}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Box {
                    IconButton(onClick = { showTopMenu = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = s.settingsTitle,
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    DropdownMenu(
                        expanded = showTopMenu,
                        onDismissRequest = { showTopMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(s.batchSelectDelete) },
                            leadingIcon = { Icon(Icons.Default.CheckCircleOutline, contentDescription = null) },
                            onClick = {
                                showTopMenu = false
                                isMultiSelectMode = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(s.createPlaylist) },
                            leadingIcon = { Icon(Icons.AutoMirrored.Filled.PlaylistAdd, contentDescription = null) },
                            onClick = {
                                showTopMenu = false
                                showCreatePlaylistDialog = true
                            }
                        )
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        val isTimerActive = uiState.sleepTimerSecondsRemaining != null && uiState.sleepTimerSecondsRemaining > 0
                        val timerLabel = if (isTimerActive) {
                            val rem = uiState.sleepTimerSecondsRemaining ?: 0L
                            val m = rem / 60
                            val sSec = rem % 60
                            "${s.sleepTimerTitle} (%02d:%02d)".format(m, sSec)
                        } else {
                            s.sleepTimerTitle
                        }
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = timerLabel,
                                    color = if (isTimerActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                    fontWeight = if (isTimerActive) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = null,
                                    tint = if (isTimerActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            onClick = {
                                showTopMenu = false
                                showSleepTimerDialog = true
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (uiState.downloadedSongs.isNotEmpty() && !isMultiSelectMode) {
            OwlSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholderText = s.searchInDownloadsPlaceholder
            )

            Spacer(modifier = Modifier.height(14.dp))
        }

        if (uiState.downloadedSongs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 60.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DownloadDone,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = s.downloadsEmptyDescription,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }
            }
        } else {
            val haptic = LocalHapticFeedback.current

            val dragDropState = rememberDragDropState(listState) { from, to ->

            }

            var activeReorderList by remember { mutableStateOf<List<SongItem>?>(null) }
            val displaySongs = activeReorderList ?: filteredSongs

            val isDragEnabled = !isMultiSelectMode && searchQuery.isBlank() && displaySongs.size > 1

            LazyColumn(
                state = listState,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 20.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .then(
                        if (isDragEnabled) {
                            Modifier.pointerInput(dragDropState, filteredSongs) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { offset ->
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        activeReorderList = filteredSongs.toMutableList()
                                        dragDropState.onDragStart(offset)
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        val from = dragDropState.draggingItemIndex
                                        dragDropState.onDrag(dragAmount)
                                        val to = dragDropState.draggingItemIndex
                                        if (from != null && to != null && from != to) {
                                            activeReorderList?.let { list ->
                                                if (from in list.indices && to in list.indices) {
                                                    val mutable = list.toMutableList()
                                                    val item = mutable.removeAt(from)
                                                    mutable.add(to, item)
                                                    activeReorderList = mutable
                                                }
                                            }
                                        }
                                    },
                                    onDragEnd = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        dragDropState.onDragEnd()
                                        activeReorderList?.let { reordered ->
                                            viewModel.persistDownloadedSongsOrder(reordered)
                                        }
                                        activeReorderList = null
                                    },
                                    onDragCancel = {
                                        dragDropState.onDragCancel()
                                        activeReorderList = null
                                    }
                                )
                            }
                        } else Modifier
                    )
            ) {
                itemsIndexed(displaySongs, key = { _, song -> song.id }) { index, song ->
                    val isSelected = selectedSongs.contains(song)
                    val isCurrent = currentSongId == song.id
                    val itemPlaying = isCurrent && isPlaying
                    val itemBuffering = isCurrent && isBuffering
                    val isDragging = dragDropState.draggingItemIndex == index

                    DownloadedSongRowItem(
                        song = song,
                        isCurrentSong = isCurrent,
                        isPlaying = itemPlaying,
                        isBuffering = itemBuffering,
                        isMultiSelectMode = isMultiSelectMode,
                        isSelected = isSelected,
                        isDragging = isDragging,
                        dragOffset = if (isDragging) dragDropState.draggingItemOffset else 0f,
                        index = index,
                        totalCount = displaySongs.size,
                        modifier = Modifier.zIndex(if (isDragging) 10f else 0f),
                        onSongClick = {
                            if (isMultiSelectMode) {
                                if (isSelected) selectedSongs.remove(song) else selectedSongs.add(song)
                            } else {
                                viewModel.playSong(song, displaySongs)
                            }
                        },
                        onMove = { from, to ->
                            val current = displaySongs.toMutableList()
                            if (from in current.indices && to in current.indices) {
                                val item = current.removeAt(from)
                                current.add(to, item)
                                viewModel.persistDownloadedSongsOrder(current)
                            }
                        },
                        onMoveToTop = {
                            if (index > 0 && index in displaySongs.indices) {
                                val current = displaySongs.toMutableList()
                                val item = current.removeAt(index)
                                current.add(0, item)
                                viewModel.persistDownloadedSongsOrder(current)
                            }
                        },
                        onAddToPlaylist = {
                            singleSongForAction = song
                            showAddToPlaylistDialog = true
                        },
                        onDeleteSingle = { viewModel.deleteDownloadedSong(song) },
                        strings = s
                    )
                }
            }
        }
    }
}

@Composable
private fun DownloadedSongRowItem(
    song: SongItem,
    isCurrentSong: Boolean,
    isPlaying: Boolean,
    isBuffering: Boolean = false,
    isMultiSelectMode: Boolean,
    isSelected: Boolean,
    isDragging: Boolean = false,
    dragOffset: Float = 0f,
    index: Int,
    totalCount: Int,
    modifier: Modifier = Modifier,
    onSongClick: () -> Unit,
    onMove: (Int, Int) -> Unit,
    onMoveToTop: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onDeleteSingle: () -> Unit,
    strings: com.elbahram.owlmusic.util.AppStrings = com.elbahram.owlmusic.util.TurkishStrings
) {
    val s = strings
    var showItemMenu by remember { mutableStateOf(false) }

    val elevation by animateDpAsState(
        targetValue = if (isDragging) 12.dp else 0.dp,
        label = "elevation"
    )
    val scale by animateFloatAsState(
        targetValue = if (isDragging) 1.03f else 1.0f,
        label = "scale"
    )

    Surface(
        onClick = onSongClick,
        shape = RoundedCornerShape(14.dp),
        color = when {
            isDragging -> MaterialTheme.colorScheme.surfaceVariant
            isSelected -> MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
            isCurrentSong -> MaterialTheme.colorScheme.surfaceVariant
            else -> MaterialTheme.colorScheme.surface
        },
        border = androidx.compose.foundation.BorderStroke(
            when {
                isDragging -> 2.dp
                isSelected -> 1.5.dp
                isCurrentSong -> 1.dp
                else -> 0.5.dp
            },
            when {
                isDragging -> MaterialTheme.colorScheme.primary
                isSelected -> MaterialTheme.colorScheme.primary
                isCurrentSong -> MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                else -> MaterialTheme.colorScheme.outline
            }
        ),
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                translationY = dragOffset
                scaleX = scale
                scaleY = scale
                shadowElevation = elevation.toPx()
            }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isMultiSelectMode) {
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = { onSongClick() },
                    modifier = Modifier.padding(end = 6.dp)
                )
            }

            SongArtwork(
                thumbnailUrl = song.thumbnailUrl,
                contentDescription = song.title,
                shape = RoundedCornerShape(10.dp),
                iconSize = 24.dp,
                modifier = Modifier.size(50.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = song.title,
                    color = if (isCurrentSong) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    fontWeight = if (isCurrentSong) FontWeight.Bold else FontWeight.SemiBold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = song.artist,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (song.durationText.isNotBlank()) {
                        Text(
                            text = " • ${song.durationText}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            if (!isMultiSelectMode) {

                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            if (isCurrentSong) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .border(
                            0.5.dp,
                            if (isCurrentSong) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                            CircleShape
                        )
                        .clickable { onSongClick() },
                    contentAlignment = Alignment.Center
                ) {
                    if (isBuffering) {
                        CircularProgressIndicator(
                            color = if (isCurrentSong) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary,
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.size(20.dp)
                        )
                    } else {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) s.pause else s.play,
                            tint = if (isCurrentSong) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.DragHandle,
                    contentDescription = s.dragToReorder,
                    tint = if (isDragging) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .padding(horizontal = 6.dp)
                        .size(24.dp)
                )

                Box {
                    IconButton(
                        onClick = { showItemMenu = true },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = s.menu,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showItemMenu,
                        onDismissRequest = { showItemMenu = false }
                    ) {
                        if (index > 0) {
                            DropdownMenuItem(
                                text = { Text(s.moveToTop) },
                                leadingIcon = { Icon(Icons.Default.VerticalAlignTop, contentDescription = null) },
                                onClick = {
                                    showItemMenu = false
                                    onMoveToTop()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(s.moveUp) },
                                leadingIcon = { Icon(Icons.Default.KeyboardArrowUp, contentDescription = null) },
                                onClick = {
                                    showItemMenu = false
                                    onMove(index, index - 1)
                                }
                            )
                        }
                        if (index < totalCount - 1) {
                            DropdownMenuItem(
                                text = { Text(s.moveDown) },
                                leadingIcon = { Icon(Icons.Default.KeyboardArrowDown, contentDescription = null) },
                                onClick = {
                                    showItemMenu = false
                                    onMove(index, index + 1)
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text(s.addToList) },
                            leadingIcon = { Icon(Icons.AutoMirrored.Filled.PlaylistAdd, contentDescription = null) },
                            onClick = {
                                showItemMenu = false
                                onAddToPlaylist()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(s.deleteFromDevice, color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                            onClick = {
                                showItemMenu = false
                                onDeleteSingle()
                            }
                        )
                    }
                }
            }
        }
    }
}

class DragDropState internal constructor(
    val lazyListState: LazyListState,
    private val scope: CoroutineScope,
    private val onMove: (Int, Int) -> Unit
) {
    var draggingItemIndex by mutableStateOf<Int?>(null)
        private set

    var draggingItemOffset by mutableFloatStateOf(0f)
        private set

    private var autoScrollJob: Job? = null
    private var settleJob: Job? = null
    private val autoScrollSpeed = mutableFloatStateOf(0f)

    fun onDragStart(offset: Offset) {

        settleJob?.cancel()
        settleJob = null
        draggingItemOffset = 0f

        val item = lazyListState.layoutInfo.visibleItemsInfo
            .firstOrNull { itemInfo ->
                offset.y.toInt() in itemInfo.offset..(itemInfo.offset + itemInfo.size)
            } ?: return

        draggingItemIndex = item.index
        autoScrollSpeed.value = 0f
        startAutoScroll()
    }

    private fun startAutoScroll() {
        if (autoScrollJob?.isActive == true) return
        autoScrollJob = scope.launch {
            while (isActive && draggingItemIndex != null) {
                val speed = autoScrollSpeed.value
                if (speed != 0f) {
                    lazyListState.scrollBy(speed)
                }
                delay(16)
            }
        }
    }

    fun onDrag(dragAmount: Offset) {
        val currentIndex = draggingItemIndex ?: return
        draggingItemOffset += dragAmount.y

        val layoutInfo = lazyListState.layoutInfo
        val visibleItems = layoutInfo.visibleItemsInfo
        val currentItem = visibleItems.firstOrNull { it.index == currentIndex } ?: return

        val currentCenter = currentItem.offset + draggingItemOffset + (currentItem.size / 2f)

        val targetItem = visibleItems.firstOrNull { other ->
            other.index != currentIndex &&
                currentCenter.toInt() in other.offset..(other.offset + other.size)
        }

        if (targetItem != null) {
            val targetIndex = targetItem.index

            draggingItemOffset += (currentItem.offset - targetItem.offset)
            draggingItemIndex = targetIndex
            onMove(currentIndex, targetIndex)
        }

        val viewportHeight = layoutInfo.viewportSize.height.toFloat()
        val edgeThreshold = 140f
        val currentTop = currentItem.offset + draggingItemOffset

        autoScrollSpeed.value = when {
            currentTop < edgeThreshold ->
                -((edgeThreshold - currentTop) / edgeThreshold).coerceIn(0f, 1f) * 24f
            currentTop + currentItem.size > (viewportHeight - edgeThreshold) -> {
                val overflow = (currentTop + currentItem.size) - (viewportHeight - edgeThreshold)
                ((overflow / edgeThreshold).coerceIn(0f, 1f) * 24f)
            }
            else -> 0f
        }
    }

    fun onDragEnd() {
        stopAutoScroll()
        val currentOffset = draggingItemOffset
        if (currentOffset == 0f) {
            draggingItemIndex = null
            draggingItemOffset = 0f
            return
        }
        settleJob?.cancel()
        settleJob = scope.launch {
            Animatable(currentOffset).animateTo(
                targetValue = 0f,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
            ) {
                draggingItemOffset = value
            }
            draggingItemIndex = null
            draggingItemOffset = 0f
        }
    }

    fun onDragCancel() {
        stopAutoScroll()
        settleJob?.cancel()
        settleJob = null
        draggingItemIndex = null
        draggingItemOffset = 0f
    }

    private fun stopAutoScroll() {
        autoScrollSpeed.value = 0f
        autoScrollJob?.cancel()
        autoScrollJob = null
    }
}

@Composable
fun rememberDragDropState(
    lazyListState: LazyListState,
    onMove: (Int, Int) -> Unit
): DragDropState {
    val scope = rememberCoroutineScope()
    val currentOnMove by rememberUpdatedState(onMove)
    return remember(lazyListState) {
        DragDropState(
            lazyListState = lazyListState,
            scope = scope,
            onMove = { from, to -> currentOnMove(from, to) }
        )
    }
}
