package com.elbahram.owlmusic.data.local

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.elbahram.owlmusic.YtDlpBootstrap
import com.elbahram.owlmusic.data.remote.PreferIpv4Dns
import com.elbahram.owlmusic.domain.model.DownloadProgress
import com.elbahram.owlmusic.domain.model.ResolvedAudio
import com.elbahram.owlmusic.domain.model.SongItem
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.TimeUnit

class MusicDownloadManager(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .dns(PreferIpv4Dns)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
    private val wakeLock = powerManager?.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "OwlMusic:DownloadWakeLock")

    fun acquireWakeLock() {
        try {
            if (wakeLock?.isHeld != true) {
                wakeLock?.acquire(15 * 60 * 1000L)
            }
        } catch (e: Exception) {
            Log.w(TAG, "WakeLock alınamadı: ${e.message}")
        }
    }

    fun releaseWakeLockIfIdle(isIdle: Boolean) {
        try {
            if (isIdle && wakeLock?.isHeld == true) {
                wakeLock.release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "WakeLock bırakılamadı: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "MusicDownloadManager"
        private const val USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"

        private const val MIN_REASONABLE_BYTES = 20_000L

        private val AUDIO_EXTENSIONS = setOf("mp3", "m4a", "webm", "aac", "ogg", "flac", "wav")
    }

    private fun getInternalMusicDirectory(): File {
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "OwlMusic")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun getPublicDownloadDirectory(): File {
        val publicDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "OwlMusic"
        )
        if (!publicDir.exists()) {
            publicDir.mkdirs()
        }
        return publicDir
    }

    fun getCoversDirectory(): File {
        val pubDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "OwlMusic"
        )
        val dir = File(pubDir, "covers")
        if (!dir.exists()) dir.mkdirs()
        val noMedia = File(dir, ".nomedia")
        if (!noMedia.exists()) {
            runCatching { noMedia.createNewFile() }
        }
        return dir
    }

    fun getDataDirectory(): File {
        val pubDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "OwlMusic"
        )
        val dir = File(pubDir, "data")
        if (!dir.exists()) dir.mkdirs()
        val noMedia = File(dir, ".nomedia")
        if (!noMedia.exists()) {
            runCatching { noMedia.createNewFile() }
        }
        return dir
    }

    private fun removeCoverFromMediaStore(filePath: String) {
        try {
            val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val where = "${MediaStore.Images.Media.DATA} = ?"
            val args = arrayOf(filePath)
            context.contentResolver.delete(uri, where, args)
        } catch (_: Exception) {}
    }

    private fun migrateExposedCovers(dir: File) {
        val coversDir = getCoversDirectory()

        val legacyDotCovers = File(dir, ".covers")
        if (legacyDotCovers.exists() && legacyDotCovers.isDirectory) {
            legacyDotCovers.listFiles()?.forEach { file ->
                if (file.isFile && file.extension.equals("jpg", ignoreCase = true)) {
                    try {
                        val cleanName = if (file.name.startsWith(".trashed-")) {
                            file.name.substringAfter("-").substringAfter("-")
                        } else {
                            file.name
                        }
                        val target = File(coversDir, cleanName)
                        if (!target.exists() || target.length() == 0L) {
                            file.copyTo(target, overwrite = true)
                        }
                        runCatching { file.delete() }
                    } catch (_: Exception) {}
                }
            }
            runCatching { legacyDotCovers.delete() }
        }

        val appExternalCovers = context.getExternalFilesDir("covers")
        if (appExternalCovers != null && appExternalCovers.exists() && appExternalCovers.isDirectory) {
            appExternalCovers.listFiles()?.forEach { file ->
                if (file.isFile && file.extension.equals("jpg", ignoreCase = true)) {
                    try {
                        val target = File(coversDir, file.name)
                        if (!target.exists() || target.length() == 0L) {
                            file.copyTo(target, overwrite = true)
                        }
                    } catch (_: Exception) {}
                }
            }
        }

        val appInternalCovers = File(context.filesDir, "covers")
        if (appInternalCovers.exists() && appInternalCovers.isDirectory) {
            appInternalCovers.listFiles()?.forEach { file ->
                if (file.isFile && file.extension.equals("jpg", ignoreCase = true)) {
                    try {
                        val target = File(coversDir, file.name)
                        if (!target.exists() || target.length() == 0L) {
                            file.copyTo(target, overwrite = true)
                        }
                    } catch (_: Exception) {}
                }
            }
        }

        val altFolders = listOf("kapak fotoları", "kapak", "kapaklar", ".covers")
        altFolders.forEach { folderName ->
            val folder = File(dir, folderName)
            if (folder.exists() && folder.isDirectory) {
                folder.listFiles()?.forEach { file ->
                    if (file.isFile && file.extension.lowercase() in listOf("jpg", "jpeg", "png", "webp")) {
                        try {
                            val target = File(coversDir, file.name)
                            if (!target.exists() || target.length() == 0L) {
                                file.copyTo(target, overwrite = true)
                            }
                        } catch (_: Exception) {}
                    }
                }
            }
        }

        dir.listFiles { f -> f.isFile && f.extension.lowercase() in listOf("jpg", "jpeg", "png", "webp") }?.forEach { jpgFile ->
            try {
                val cleanName = if (jpgFile.name.startsWith(".trashed-")) {
                    jpgFile.name.substringAfter("-").substringAfter("-")
                } else {
                    jpgFile.name
                }
                val target = File(coversDir, cleanName)
                if (!target.exists() || target.length() == 0L) {
                    jpgFile.copyTo(target, overwrite = true)
                }
                if (target.exists() && target.length() > 0L) {
                    removeCoverFromMediaStore(jpgFile.absolutePath)
                    runCatching { jpgFile.delete() }
                }
            } catch (_: Exception) {}
        }

        val oldPlayCounts = File(dir, "play_counts.json")
        if (oldPlayCounts.exists()) {
            val targetPlayCounts = File(getDataDirectory(), "play_counts.json")
            if (!targetPlayCounts.exists() || targetPlayCounts.length() == 0L) {
                runCatching { oldPlayCounts.copyTo(targetPlayCounts, overwrite = true) }
            }
            if (targetPlayCounts.exists() && targetPlayCounts.length() > 0L) {
                runCatching { oldPlayCounts.delete() }
            }
        }
    }

    private val deletedPrefs by lazy {
        context.getSharedPreferences("owl_deleted_songs_v3", android.content.Context.MODE_PRIVATE)
    }

    fun markSongDeleted(song: SongItem) {
        val set = deletedPrefs.getStringSet("keys", emptySet())?.toMutableSet() ?: mutableSetOf()
        set.add(song.id)
        if (!song.localFilePath.isNullOrBlank()) {
            set.add(song.localFilePath)
            set.add(File(song.localFilePath).name)
        }
        val key = "${normalizeForDeduplication(song.artist)}_${normalizeForDeduplication(song.title)}"
        if (key.isNotBlank() && key != "_") {
            set.add(key)
        }
        deletedPrefs.edit().putStringSet("keys", set).apply()
    }

    fun unmarkSongDeleted(song: SongItem) {
        unmarkSongDeleted(song.id, song.localFilePath, song.artist, song.title)
    }

    fun unmarkSongDeleted(id: String?, filePath: String?, artist: String?, title: String?) {
        val set = deletedPrefs.getStringSet("keys", emptySet())?.toMutableSet() ?: return
        var changed = false
        if (!id.isNullOrBlank()) {
            changed = set.remove(id) || changed
        }
        if (!filePath.isNullOrBlank()) {
            changed = set.remove(filePath) || changed
            changed = set.remove(File(filePath).name) || changed
        }
        if (!artist.isNullOrBlank() && !title.isNullOrBlank()) {
            val key = "${normalizeForDeduplication(artist)}_${normalizeForDeduplication(title)}"
            changed = set.remove(key) || changed
        }
        if (changed) {
            deletedPrefs.edit().putStringSet("keys", set).apply()
        }
    }

    private fun isSongDeleted(id: String, filePath: String?, artist: String, title: String): Boolean {
        val set = deletedPrefs.getStringSet("keys", emptySet()) ?: return false
        if (set.contains(id)) return true
        if (!filePath.isNullOrBlank()) {
            if (set.contains(filePath)) return true
            if (set.contains(File(filePath).name)) return true
        }
        val key = "${normalizeForDeduplication(artist)}_${normalizeForDeduplication(title)}"
        if (key.isNotBlank() && key != "_" && set.contains(key)) return true
        return false
    }

    private fun cleanTrashFiles(dir: File) {
        dir.listFiles { f ->
            f.isFile && (
                f.name.endsWith(".part", ignoreCase = true) ||
                f.name.endsWith(".ytdl", ignoreCase = true) ||
                f.name.endsWith(".temp", ignoreCase = true) ||
                f.name.endsWith(".tmp", ignoreCase = true) ||
                (f.length() < MIN_REASONABLE_BYTES && !f.name.endsWith(".jpg", ignoreCase = true))
            )
        }?.forEach { runCatching { it.delete() } }
    }

    private fun extensionFor(sourceMimeType: String): String = when {
        sourceMimeType.contains("webm", ignoreCase = true) -> "webm"
        sourceMimeType.startsWith("video", ignoreCase = true) -> "mp4"
        sourceMimeType.contains("mp4", ignoreCase = true) -> "m4a"
        else -> "mp3"
    }

    private fun mimeTypeFor(sourceMimeType: String): String = when {
        sourceMimeType.contains("webm", ignoreCase = true) -> "audio/webm"
        sourceMimeType.startsWith("video", ignoreCase = true) -> "video/mp4"
        sourceMimeType.contains("mp4", ignoreCase = true) -> "audio/mp4"
        else -> "audio/mpeg"
    }

    private fun getAllDownloadDirectories(): List<File> {
        val dirs = mutableListOf<File>()
        try {
            val pubDownloads = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "OwlMusic")
            dirs.add(pubDownloads)
        } catch (_: Exception) {}
        dirs.add(getPublicDownloadDirectory())
        dirs.add(getInternalMusicDirectory())
        try {
            val pubMusic = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "OwlMusic")
            if (pubMusic.exists()) dirs.add(pubMusic)
        } catch (_: Exception) {}
        try {
            val internalDownloads = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "OwlMusic")
            if (internalDownloads.exists()) dirs.add(internalDownloads)
        } catch (_: Exception) {}
        return dirs.filter { it.exists() }.distinctBy { it.absolutePath }
    }

    @Suppress("DEPRECATION")
    suspend fun getLocalSongs(): List<SongItem> = withContext(Dispatchers.IO) {
        val songList = mutableListOf<SongItem>()

        val directories = getAllDownloadDirectories()
        val allAudioFiles = mutableListOf<File>()
        for (dir in directories) {
            cleanTrashFiles(dir)
            migrateExposedCovers(dir)
            dir.listFiles { f -> f.isFile && f.extension.lowercase() in AUDIO_EXTENSIONS && f.length() > MIN_REASONABLE_BYTES }
                ?.let { allAudioFiles.addAll(it) }
        }
        val imageExts = listOf("jpg", "jpeg", "png", "webp")
        val allImages = mutableListOf<File>()
        for (cDir in getAllCoverDirectories()) {
            runCatching {
                cDir.listFiles { f -> f.isFile && f.extension.lowercase() in imageExts && f.length() > 0 }
                    ?.let { allImages.addAll(it) }
            }
        }

        allAudioFiles.sortedByDescending { it.lastModified() }.forEach { file ->
            val item = songFromFileName(file.nameWithoutExtension, file.absolutePath, allImages)
            if (!isSongDeleted(item.id, item.localFilePath, item.artist, item.title)) {
                if (songList.none { it.localFilePath == item.localFilePath }) {
                    songList.add(item)
                }
            }
        }

        try {
            val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DATE_MODIFIED
            )

            val selection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                "(${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR ${MediaStore.MediaColumns.DATA} LIKE ?) AND ${MediaStore.MediaColumns.IS_PENDING} = 0"
            } else {
                "${MediaStore.MediaColumns.DATA} LIKE ?"
            }
            val selectionArgs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                arrayOf("%OwlMusic%", "%OwlMusic%")
            } else {
                arrayOf("%OwlMusic%")
            }

            val sortOrder = "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"

            context.contentResolver.query(collection, projection, selection, selectionArgs, sortOrder)?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val dataColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val rawPath = if (dataColumn >= 0) cursor.getString(dataColumn) else null
                    val contentUri = ContentUris.withAppendedId(collection, id)
                    val effectivePath = rawPath?.takeIf { File(it).exists() } ?: contentUri.toString()

                    if (rawPath != null && songList.any { it.localFilePath == rawPath }) continue
                    if (songList.any { it.localFilePath == effectivePath }) continue

                    val rawTitle = cursor.getString(titleColumn).orEmpty().ifEmpty { "Bilinmeyen Şarkı" }
                    val rawArtist = cursor.getString(artistColumn).orEmpty().ifEmpty { "OwlMusic" }

                    val (parsedArtist, parsedTitle) = if ((rawArtist.contains("unknown", ignoreCase = true) || rawArtist == "OwlMusic") && rawTitle.contains(" - ")) {
                        val parts = rawTitle.split(" - ")
                        parts.first().trim() to parts.drop(1).joinToString(" - ").trim()
                    } else {
                        rawArtist to rawTitle
                    }
                    val finalTitle = parsedTitle.trim().trimEnd('_', ' ', '-').ifEmpty { "Bilinmeyen Şarkı" }
                    val finalArtist = parsedArtist.trim().trimEnd('_', ' ', '-').ifEmpty { "OwlMusic" }

                    val fileExists = rawPath != null && File(rawPath).exists() && File(rawPath).length() > MIN_REASONABLE_BYTES
                    if (fileExists) {
                        unmarkSongDeleted("media_$id", rawPath, finalArtist, finalTitle)
                    } else if (isSongDeleted("media_$id", effectivePath, finalArtist, finalTitle)) {
                        continue
                    }

                    val normTitle = normalizeForDeduplication(finalTitle)
                    val normArtist = normalizeForDeduplication(finalArtist)
                    val isDuplicate = songList.any { existing ->
                        val exNormTitle = normalizeForDeduplication(existing.title)
                        val exNormArtist = normalizeForDeduplication(existing.artist)
                        exNormTitle == normTitle && (exNormArtist == normArtist || exNormArtist.isEmpty() || normArtist.isEmpty())
                    }

                    if (!isDuplicate) {
                        val thumbUrl = if (rawPath != null) resolveThumbnail(File(rawPath), allImages) else ""
                        songList.add(
                            SongItem(
                                id = "media_$id",
                                title = finalTitle,
                                artist = finalArtist,
                                thumbnailUrl = thumbUrl,
                                localFilePath = effectivePath,
                                isDownloaded = true
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "MediaStore sorgusu başarısız: ${e.message}")
        }

        val uniqueSongs = mutableListOf<SongItem>()
        val seenPaths = mutableSetOf<String>()
        val seenKeys = mutableSetOf<String>()
        for (s in songList) {
            val path = s.localFilePath.orEmpty()
            val key = "${normalizeForDeduplication(s.artist)}_${normalizeForDeduplication(s.title)}"
            if ((path.isNotEmpty() && seenPaths.add(path)) || (key.isNotBlank() && seenKeys.add(key))) {
                uniqueSongs.add(s)
            }
        }

        uniqueSongs.sortByDescending { song ->
            val path = song.localFilePath
            if (!path.isNullOrBlank() && !path.startsWith("content://")) {
                val f = File(path)
                if (f.exists()) f.lastModified() else 0L
            } else 0L
        }

        return@withContext uniqueSongs
    }

    private fun normalizeForDeduplication(text: String): String {
        return text.lowercase().replace(Regex("[^a-z0-9ğüşıöç]"), "")
    }

    private val songMetadataCache = java.util.concurrent.ConcurrentHashMap<String, SongItem>()

    fun getAllCoverDirectories(): List<File> {
        val dirs = mutableListOf<File>()
        val pubDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "OwlMusic"
        )
        dirs.add(File(pubDir, "covers"))
        dirs.add(File(pubDir, "kapak fotoları"))
        dirs.add(File(pubDir, "kapak"))
        dirs.add(File(pubDir, "kapaklar"))
        dirs.add(File(pubDir, ".covers"))
        dirs.add(File(pubDir, "data"))
        dirs.add(File(pubDir, "veri"))
        dirs.add(pubDir)

        runCatching {
            pubDir.listFiles { f -> f.isDirectory }?.forEach { sub ->
                if (!dirs.contains(sub)) dirs.add(sub)
            }
        }

        dirs.add(File(context.filesDir, "covers"))
        dirs.add(File(context.filesDir, "kapak"))
        context.getExternalFilesDir("covers")?.let { dirs.add(it) }
        context.getExternalFilesDir("kapak")?.let { dirs.add(it) }
        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.let {
            dirs.add(File(it, "OwlMusic/covers"))
            dirs.add(File(it, "OwlMusic"))
        }
        context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)?.let {
            dirs.add(File(it, "OwlMusic/covers"))
            dirs.add(File(it, "OwlMusic"))
        }
        dirs.add(context.cacheDir)
        return dirs.filter { it.exists() && it.isDirectory }.distinctBy { it.absolutePath }
    }

    private val thumbnailResolutionCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    fun getInternalCoversDirectory(): File {
        val dir = File(context.filesDir, "covers")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun resolveThumbnail(file: File, preloadedImages: List<File>? = null): String {
        val cacheKey = "${file.absolutePath}_${file.lastModified()}"
        val cached = thumbnailResolutionCache[cacheKey]
        if (cached != null && cached.isNotBlank() && File(cached).exists()) return cached

        val baseName = file.nameWithoutExtension
        val internalTarget = File(getInternalCoversDirectory(), "$baseName.jpg")
        if (internalTarget.exists() && internalTarget.length() > 0) {
            thumbnailResolutionCache[cacheKey] = internalTarget.absolutePath
            return internalTarget.absolutePath
        }

        val cacheThumb = File(context.cacheDir, "art_${baseName.hashCode()}.jpg")
        if (cacheThumb.exists() && cacheThumb.length() > 0) {
            thumbnailResolutionCache[cacheKey] = cacheThumb.absolutePath
            return cacheThumb.absolutePath
        }

        fun cacheAndReturn(sourceFile: File): String {
            if (!internalTarget.exists() || internalTarget.length() == 0L) {
                runCatching { sourceFile.copyTo(internalTarget, overwrite = true) }
            }
            val res = if (internalTarget.exists() && internalTarget.length() > 0) internalTarget.absolutePath else sourceFile.absolutePath
            thumbnailResolutionCache[cacheKey] = res
            return res
        }

        val normBase = normalizeForDeduplication(baseName)
        val parts = baseName.split(" - ")
        val fnArtist = if (parts.size >= 2) parts.first().trim() else ""
        val fnTitle = if (parts.size >= 2) parts.drop(1).joinToString(" - ").trim() else baseName
        val normArtist = normalizeForDeduplication(fnArtist)
        val normTitle = normalizeForDeduplication(fnTitle)

        val imageExts = listOf("jpg", "jpeg", "png", "webp")
        val allCoverDirs = getAllCoverDirectories()

        for (dir in allCoverDirs) {
            for (ext in imageExts) {
                val f1 = File(dir, "$baseName.$ext")
                if (f1.exists() && f1.length() > 0) {
                    return cacheAndReturn(f1)
                }

                if (fnArtist.isNotBlank() && fnTitle.isNotBlank()) {
                    val f2 = File(dir, "$fnArtist - $fnTitle.$ext")
                    if (f2.exists() && f2.length() > 0) {
                        return cacheAndReturn(f2)
                    }
                    val f3 = File(dir, "$fnTitle - $fnArtist.$ext")
                    if (f3.exists() && f3.length() > 0) {
                        return cacheAndReturn(f3)
                    }
                    val f4 = File(dir, "$fnTitle.$ext")
                    if (f4.exists() && f4.length() > 0) {
                        return cacheAndReturn(f4)
                    }
                }
            }
        }

        val allImages = preloadedImages ?: run {
            val list = mutableListOf<File>()
            for (dir in allCoverDirs) {
                runCatching {
                    dir.listFiles { f -> f.isFile && f.extension.lowercase() in imageExts && f.length() > 0 }
                        ?.let { list.addAll(it) }
                }
            }
            list
        }

        val exactNorm = allImages.firstOrNull { img ->
            val imgNorm = normalizeForDeduplication(img.nameWithoutExtension)
            imgNorm == normBase ||
            (normArtist.isNotBlank() && normTitle.isNotBlank() && (imgNorm == "${normArtist}${normTitle}" || imgNorm == "${normTitle}${normArtist}")) ||
            (normTitle.isNotBlank() && imgNorm == normTitle)
        }
        if (exactNorm != null && exactNorm.exists() && exactNorm.length() > 0) {
            return cacheAndReturn(exactNorm)
        }

        if (file.exists() && file.isFile && file.length() > MIN_REASONABLE_BYTES) {
            val mmr = android.media.MediaMetadataRetriever()
            try {
                mmr.setDataSource(file.absolutePath)
                val pic = mmr.embeddedPicture
                if (pic != null && pic.isNotEmpty()) {
                    runCatching { internalTarget.writeBytes(pic) }
                    val coversDir = getCoversDirectory()
                    val targetCover = File(coversDir, "$baseName.jpg")
                    runCatching { targetCover.writeBytes(pic) }
                    runCatching { cacheThumb.writeBytes(pic) }
                    val result = if (internalTarget.exists() && internalTarget.length() > 0) {
                        internalTarget.absolutePath
                    } else if (targetCover.exists() && targetCover.length() > 0) {
                        targetCover.absolutePath
                    } else {
                        cacheThumb.absolutePath
                    }
                    thumbnailResolutionCache[cacheKey] = result
                    return result
                }
            } catch (_: Exception) {
            } finally {
                runCatching { mmr.release() }
            }
        }

        thumbnailResolutionCache[cacheKey] = ""
        return ""
    }

    private fun songFromFileName(nameWithoutExtension: String, path: String, preloadedImages: List<File>? = null): SongItem {
        val file = File(path)
        val cacheKey = "${path}_${file.lastModified()}"
        val cached = songMetadataCache[cacheKey]
        if (cached != null && cached.thumbnailUrl.isNotBlank() && File(cached.thumbnailUrl).exists()) {
            return cached
        }

        val parts = nameWithoutExtension.split(" - ")
        val fnArtist = if (parts.size >= 2) parts.first().trim() else "OwlMusic"
        val fnTitle = if (parts.size >= 2) parts.drop(1).joinToString(" - ").trim() else nameWithoutExtension

        val finalTitle = fnTitle.trim().trimEnd('_', ' ', '-').ifEmpty { nameWithoutExtension }
        val finalArtist = fnArtist.trim().trimEnd('_', ' ', '-').ifEmpty { "OwlMusic" }
        val thumbUrl = resolveThumbnail(file, preloadedImages)

        val item = SongItem(
            id = path.hashCode().toString(),
            title = finalTitle,
            artist = finalArtist,
            thumbnailUrl = thumbUrl,
            durationMs = 0L,
            durationText = "",
            localFilePath = path,
            isDownloaded = true
        )
        if (thumbUrl.isNotBlank()) {
            songMetadataCache[cacheKey] = item
        }
        return item
    }

    fun downloadSong(song: SongItem, stream: ResolvedAudio? = null): Flow<DownloadProgress> = kotlinx.coroutines.flow.channelFlow {
        send(DownloadProgress(songId = song.id, progressPercent = 0))
        unmarkSongDeleted(song)

        val sanitizedTitle = song.title.replace(Regex("[\\\\/:*?\"<>|]"), "").trim().trimEnd('_', ' ', '-').ifEmpty { "Unknown" }
        val sanitizedArtist = song.artist.replace(Regex("[\\\\/:*?\"<>|]"), "").trim().trimEnd('_', ' ', '-').ifEmpty { "OwlMusic" }
        val baseFileName = "$sanitizedArtist - $sanitizedTitle"
        val downloadDir = getPublicDownloadDirectory()

        val existingAudioFile = AUDIO_EXTENSIONS.map { ext -> File(downloadDir, "$baseFileName.$ext") }
            .firstOrNull { it.exists() && it.length() > MIN_REASONABLE_BYTES }

        if (existingAudioFile != null) {
            Log.d(TAG, "Şarkı zaten indirilmiş, mevcut dosya kullanılıyor: ${existingAudioFile.absolutePath}")
            unmarkSongDeleted(song.id, existingAudioFile.absolutePath, song.artist, song.title)
            send(
                DownloadProgress(
                    songId = song.id,
                    progressPercent = 100,
                    bytesDownloaded = existingAudioFile.length(),
                    totalBytes = existingAudioFile.length(),
                    isCompleted = true,
                    localFilePath = existingAudioFile.absolutePath
                )
            )
            return@channelFlow
        }

        AUDIO_EXTENSIONS.forEach { ext ->
            val oldF = File(downloadDir, "$baseFileName.$ext")
            if (oldF.exists()) runCatching { oldF.delete() }
        }
        unmarkSongDeleted(song)

        downloadDir.listFiles { f ->
            f.isFile && f.name.startsWith(baseFileName) && !f.name.endsWith(".jpg")
        }?.forEach { runCatching { it.delete() } }

        val candidateThumbs = mutableListOf<String>()
        if (song.thumbnailUrl.isNotBlank() && !song.thumbnailUrl.startsWith("file:")) {
            candidateThumbs.add(song.thumbnailUrl)
        }
        if (song.id.isNotBlank() && song.id.length == 11) {
            candidateThumbs.add("https://i.ytimg.com/vi/${song.id}/hqdefault.jpg")
            candidateThumbs.add("https://i.ytimg.com/vi/${song.id}/mqdefault.jpg")
        }

        val thumbTarget = File(getCoversDirectory(), "$baseFileName.jpg")
        val exposedOldJpg = File(downloadDir, "$baseFileName.jpg")
        if (exposedOldJpg.exists() && (!thumbTarget.exists() || thumbTarget.length() == 0L)) {
            runCatching { exposedOldJpg.copyTo(thumbTarget, overwrite = true) }
        }
        if (exposedOldJpg.exists()) {
            removeCoverFromMediaStore(exposedOldJpg.absolutePath)
            runCatching { exposedOldJpg.delete() }
        }

        try {
            if (!thumbTarget.exists() || thumbTarget.length() == 0L) {
                for (thumbUrl in candidateThumbs.distinct()) {
                    try {
                        val imgReq = Request.Builder()
                            .url(thumbUrl)
                            .header("User-Agent", USER_AGENT)
                            .build()
                        val success = client.newCall(imgReq).execute().use { resp ->
                            if (resp.isSuccessful) {
                                val bytes = resp.body?.bytes()
                                if (bytes != null && bytes.size > 1000) {
                                    thumbTarget.writeBytes(bytes)
                                    val internalTarget = File(context.filesDir, "covers/$baseFileName.jpg")
                                    runCatching { internalTarget.writeBytes(bytes) }
                                    true
                                } else false
                            } else false
                        }
                        if (success) {
                            Log.d(TAG, "Kapak resmi başarıyla indirildi: ${thumbTarget.absolutePath}")
                            break
                        }
                    } catch (_: Exception) {

                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Kapak resmi kaydedilemedi: ${e.message}")
        }

        if (stream != null && stream.url.isNotEmpty()) {
            Log.d(TAG, "Doğrudan yüksek hızlı akış indirme deneniyor (${song.title})...")
            val directSuccess = downloadViaDirectStream(song, stream, baseFileName, downloadDir)
            if (directSuccess) {
                Log.d(TAG, "Doğrudan akış başarıyla indirildi (${song.title})")
                return@channelFlow
            }
            Log.w(TAG, "Doğrudan akış başarısız oldu, YoutubeDL motoruna geçiliyor (${song.title})")
        }

        YtDlpBootstrap.ensureReady()

        var ytDlSuccess = false
        YtDlpBootstrap.withLock {
            val outputTemplate = File(downloadDir, "$baseFileName.%(ext)s").absolutePath
            fun createRequest(): YoutubeDLRequest {
                val req = YoutubeDLRequest("https://www.youtube.com/watch?v=${song.id}")
                req.addOption("-x")
                req.addOption("--audio-format", "mp3")
                req.addOption("--audio-quality", "0")
                req.addOption("-o", outputTemplate)
                req.addOption("--no-mtime")
                req.addOption("--no-playlist")
                req.addOption("--no-update")
                req.addOption("--force-ipv4")
                req.addOption("--no-keep-video")
                req.addOption("--no-part")
                req.addOption("--add-metadata")
                req.addOption("--extractor-args", "youtube:player_client=android,web")
                return req
            }

            try {
                Log.d(TAG, "YoutubeDL başlatılıyor: ${song.id} -> $outputTemplate")
                var lastPercent = 0
                YoutubeDL.getInstance().execute(createRequest(), song.id) { progress, _, _ ->
                    val current = progress.toInt().coerceIn(1, 99)
                    if (current >= lastPercent) {
                        lastPercent = current
                        trySend(
                            DownloadProgress(
                                songId = song.id,
                                progressPercent = current,
                                isCompleted = false
                            )
                        )
                    }
                }

                val targetMp3 = File(downloadDir, "$baseFileName.mp3")
                val finalFile = if (targetMp3.exists()) {
                    targetMp3
                } else {
                    downloadDir.listFiles { f -> f.isFile && f.name.startsWith(baseFileName) }?.firstOrNull()
                }

                if (finalFile != null && finalFile.length() > MIN_REASONABLE_BYTES) {
                    MediaScannerConnection.scanFile(
                        context,
                        arrayOf(finalFile.absolutePath),
                        arrayOf("audio/mpeg"),
                        null
                    )
                    ytDlSuccess = true
                    unmarkSongDeleted(song)
                    downloadDir.listFiles { f ->
                        f.isFile && f.name.startsWith(baseFileName) && !f.name.endsWith(".mp3") && !f.name.endsWith(".jpg")
                    }?.forEach { runCatching { it.delete() } }

                    Log.d(TAG, "YoutubeDL indirmesi tamamlandı: ${finalFile.absolutePath} (${finalFile.length()} bytes)")
                    send(
                        DownloadProgress(
                            songId = song.id,
                            progressPercent = 100,
                            bytesDownloaded = finalFile.length(),
                            totalBytes = finalFile.length(),
                            isCompleted = true,
                            localFilePath = finalFile.absolutePath
                        )
                    )
                }
            } catch (e: Exception) {
                Log.w(TAG, "YoutubeDL ilk deneme başarısız: ${e.message}")
                if (e.message?.contains("403") == true || e.message?.contains("older than 90 days") == true) {
                    try {
                        Log.i(TAG, "yt-dlp güncelleniyor ve tekrar deneniyor...")
                        YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel.STABLE)
                        YoutubeDL.getInstance().execute(createRequest(), song.id) { progress, _, _ ->
                            trySend(
                                DownloadProgress(
                                    songId = song.id,
                                    progressPercent = progress.toInt().coerceIn(1, 99),
                                    isCompleted = false
                                )
                            )
                        }
                        val targetMp3 = File(downloadDir, "$baseFileName.mp3")
                        val finalFile = if (targetMp3.exists()) {
                            targetMp3
                        } else {
                            downloadDir.listFiles { f -> f.isFile && f.name.startsWith(baseFileName) }?.firstOrNull()
                        }
                        if (finalFile != null && finalFile.length() > MIN_REASONABLE_BYTES) {
                            MediaScannerConnection.scanFile(context, arrayOf(finalFile.absolutePath), arrayOf("audio/mpeg"), null)
                            ytDlSuccess = true
                            unmarkSongDeleted(song)
                            downloadDir.listFiles { f ->
                                f.isFile && f.name.startsWith(baseFileName) && !f.name.endsWith(".mp3") && !f.name.endsWith(".jpg")
                            }?.forEach { runCatching { it.delete() } }
                            send(
                                DownloadProgress(
                                    songId = song.id,
                                    progressPercent = 100,
                                    bytesDownloaded = finalFile.length(),
                                    totalBytes = finalFile.length(),
                                    isCompleted = true,
                                    localFilePath = finalFile.absolutePath
                                )
                            )
                        }
                    } catch (retryEx: Exception) {
                        Log.w(TAG, "YoutubeDL güncelleme sonrası da başarısız: ${retryEx.message}", retryEx)
                    }
                }
            }
        }

        if (ytDlSuccess) return@channelFlow

        send(DownloadProgress(songId = song.id, error = "İndirme tamamlanamadı. Lütfen tekrar deneyin."))
    }.flowOn(Dispatchers.IO)

    private suspend fun kotlinx.coroutines.channels.ProducerScope<DownloadProgress>.downloadViaDirectStream(
        song: SongItem,
        stream: ResolvedAudio,
        baseFileName: String,
        downloadDir: File
    ): Boolean {
        val extension = extensionFor(stream.mimeType)
        val outputMimeType = mimeTypeFor(stream.mimeType)
        val fileName = "$baseFileName.$extension"
        val targetFile = File(downloadDir, fileName)
        var outputStream: OutputStream? = null
        var completed = false

        try {
            outputStream = FileOutputStream(targetFile)

            val effectiveUserAgent = when {
                stream.url.contains("c=VISIONOS") -> "Mozilla/5.0 (VisionOS; Mobile; rv:1.3.1) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/21O5181b"
                stream.url.contains("c=ANDROID_VR") -> "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12; GB) gzip"
                stream.url.contains("c=ANDROID") -> "com.google.android.youtube/20.10.38 (Linux; U; Android 14) gzip"
                stream.url.contains("c=IOS") -> "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_1 like Mac OS X)"
                else -> USER_AGENT
            }

            val request = Request.Builder()
                .url(stream.url)
                .header("User-Agent", effectiveUserAgent)
                .header("Range", "bytes=0-")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.code != 200 && response.code != 206) {
                    Log.w(TAG, "Doğrudan akış yanıtı başarısız: HTTP ${response.code}")
                    return false
                }

                val body = response.body ?: return false
                val contentType = body.contentType()?.toString().orEmpty()
                if (contentType.startsWith("text/") || contentType.contains("html", ignoreCase = true)) {
                    return false
                }

                val totalLength = response.header("Content-Range")
                    ?.substringAfter('/', "0")
                    ?.toLongOrNull()
                    ?.takeIf { it > 0 }
                    ?: body.contentLength().takeIf { it > 0 }
                    ?: stream.contentLength

                var downloadedBytes = 0L
                val inputStream: InputStream = body.byteStream()
                val buffer = ByteArray(32 * 1024)
                var bytesRead: Int

                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    outputStream.write(buffer, 0, bytesRead)
                    downloadedBytes += bytesRead

                    val percent = if (totalLength > 0) {
                        ((downloadedBytes * 100) / totalLength).toInt().coerceIn(1, 99)
                    } else {
                        50
                    }

                    trySend(
                        DownloadProgress(
                            songId = song.id,
                            progressPercent = percent,
                            bytesDownloaded = downloadedBytes,
                            totalBytes = totalLength
                        )
                    )
                }
                inputStream.close()

                if (downloadedBytes < MIN_REASONABLE_BYTES) {
                    return false
                }

                outputStream.flush()
                outputStream.close()
                outputStream = null

                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(targetFile.absolutePath),
                    arrayOf(outputMimeType),
                    null
                )

                completed = true
                unmarkSongDeleted(song)

                send(
                    DownloadProgress(
                        songId = song.id,
                        progressPercent = 100,
                        bytesDownloaded = downloadedBytes,
                        totalBytes = totalLength,
                        isCompleted = true,
                        localFilePath = targetFile.absolutePath
                    )
                )
                return true
            }
        } catch (e: Exception) {
            Log.w(TAG, "Doğrudan akış indirme hatası: ${e.message}")
            return false
        } finally {
            outputStream?.let { streamToClose ->
                runCatching { streamToClose.flush() }
                runCatching { streamToClose.close() }
            }
            if (!completed) {
                if (targetFile.exists()) runCatching { targetFile.delete() }
            }
        }
    }

    fun deleteDownloadedSong(song: SongItem): Boolean {
        var anyDeleted = false
        try {
            markSongDeleted(song)
            songMetadataCache.clear()
            val path = song.localFilePath

            val deletedFilePaths = mutableListOf<String>()

            fun removeFile(f: File) {
                try {
                    if (f.exists()) {
                        deletedFilePaths.add(f.absolutePath)
                        runCatching { java.io.FileOutputStream(f).use { } }
                        val ok = f.delete()
                        if (ok || !f.exists()) {
                            anyDeleted = true
                        }
                    }
                } catch (_: Exception) {}

                try {
                    val comp = File(f.parentFile, "${f.nameWithoutExtension}.jpg")
                    if (comp.exists()) {
                        deletedFilePaths.add(comp.absolutePath)
                        removeCoverFromMediaStore(comp.absolutePath)
                        runCatching { comp.delete() }
                    }
                    val coversComp = File(File(f.parentFile, "covers"), "${f.nameWithoutExtension}.jpg")
                    if (coversComp.exists()) {
                        runCatching { coversComp.delete() }
                    }
                    val hiddenComp = File(getCoversDirectory(), "${f.nameWithoutExtension}.jpg")
                    if (hiddenComp.exists()) {
                        hiddenComp.delete()
                    }
                    val internalComp = File(context.filesDir, "covers/${f.nameWithoutExtension}.jpg")
                    if (internalComp.exists()) {
                        internalComp.delete()
                    }
                } catch (_: Exception) {}
            }

            if (!path.isNullOrBlank()) {
                if (path.startsWith("content://")) {
                    try {
                        val contentUri = Uri.parse(path)
                        val proj = arrayOf(MediaStore.Audio.Media.DATA, MediaStore.MediaColumns.DISPLAY_NAME)
                        context.contentResolver.query(contentUri, proj, null, null, null)?.use { cursor ->
                            if (cursor.moveToFirst()) {
                                val dataIdx = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                                if (dataIdx >= 0) {
                                    val filePath = cursor.getString(dataIdx)
                                    if (!filePath.isNullOrBlank()) {
                                        removeFile(File(filePath))
                                    }
                                }
                            }
                        }
                        context.contentResolver.delete(contentUri, null, null)
                        anyDeleted = true
                    } catch (e: Exception) {
                        Log.w(TAG, "ContentResolver delete failed: ${e.message}")
                    }
                } else {
                    removeFile(File(path))
                }
            }

            val targetNorm = normalizeForDeduplication("${song.artist} - ${song.title}")
            val targetTitleNorm = normalizeForDeduplication(song.title)
            val directories = getAllDownloadDirectories()
            for (dir in directories) {
                dir.listFiles()?.forEach { f ->
                    if (f.isFile) {
                        val fileNorm = normalizeForDeduplication(f.nameWithoutExtension)
                        if (fileNorm == targetNorm || fileNorm == targetTitleNorm || (targetNorm.isNotEmpty() && fileNorm.contains(targetNorm))) {
                            removeFile(f)
                        }
                    }
                }
            }

            val collections = mutableListOf(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                MediaStore.Files.getContentUri("external")
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                collections.add(MediaStore.Downloads.EXTERNAL_CONTENT_URI)
            }

            for (col in collections) {
                try {
                    if (!path.isNullOrBlank() && !path.startsWith("content://")) {
                        val fileName = File(path).name
                        context.contentResolver.delete(col, "${MediaStore.MediaColumns.DATA} = ?", arrayOf(path))
                        context.contentResolver.delete(col, "${MediaStore.MediaColumns.DISPLAY_NAME} = ?", arrayOf(fileName))
                    }
                    for (delPath in deletedFilePaths) {
                        val name = File(delPath).name
                        context.contentResolver.delete(col, "${MediaStore.MediaColumns.DATA} = ?", arrayOf(delPath))
                        context.contentResolver.delete(col, "${MediaStore.MediaColumns.DISPLAY_NAME} = ?", arrayOf(name))
                    }
                    if (song.id.startsWith("media_")) {
                        val mediaId = song.id.removePrefix("media_").toLongOrNull()
                        if (mediaId != null) {
                            val uri = ContentUris.withAppendedId(col, mediaId)
                            context.contentResolver.delete(uri, null, null)
                        }
                    }
                    context.contentResolver.delete(
                        col,
                        "${MediaStore.MediaColumns.TITLE} = ? AND ${MediaStore.MediaColumns.ARTIST} = ?",
                        arrayOf(song.title, song.artist)
                    )
                } catch (_: Exception) {}
            }

            if (deletedFilePaths.isNotEmpty()) {
                MediaScannerConnection.scanFile(
                    context,
                    deletedFilePaths.toTypedArray(),
                    null,
                    null
                )
            }

        } catch (e: Exception) {
            Log.e(TAG, "Şarkı silinirken hata oluştu: ${e.message}")
        }
        return anyDeleted
    }
}

