package com.elbahram.owlmusic.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elbahram.owlmusic.R
import com.elbahram.owlmusic.domain.model.CurrentPlayback
import com.elbahram.owlmusic.domain.model.PlaybackStatus
import com.elbahram.owlmusic.domain.model.SongItem
import com.elbahram.owlmusic.ui.components.OwlSearchBar
import com.elbahram.owlmusic.ui.components.SongArtwork
import com.elbahram.owlmusic.ui.theme.*
import com.elbahram.owlmusic.ui.viewmodel.HomeUiState
import com.elbahram.owlmusic.ui.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val playback by viewModel.playbackState.collectAsState()

    var selectedTab by rememberSaveable { mutableIntStateOf(uiState.defaultStartTab) }

    val exploreListState = rememberLazyListState()
    val downloadsListState = rememberLazyListState()
    val topPlayedListState = rememberLazyListState()
    val playlistsListState = rememberLazyListState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                withDismissAction = true,
                duration = SnackbarDuration.Short
            )
            viewModel.clearError()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
            ) {

                AnimatedVisibility(
                    visible = playback.song != null,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                ) {
                    playback.song?.let { _ ->

                        val progressState = viewModel.playerManager.progressState.collectAsState()
                        MiniPlayerBar(
                            playback = playback,
                            progressState = progressState,
                            strings = uiState.strings,
                            onPlayPauseClick = { viewModel.playerManager.togglePlayPause() },
                            onBarClick = { viewModel.setPlayerSheetVisible(true) },
                            onCloseClick = { viewModel.playerManager.stopPlayback() },
                            onSeek = { ratio -> viewModel.playerManager.seekRatio(ratio) },
                            onPrevClick = { viewModel.playPreviousSong() },
                            onNextClick = { viewModel.playNextSong() },
                            onShuffleClick = { viewModel.playerManager.toggleShuffle() },
                            onRepeatClick = { viewModel.playerManager.toggleRepeat() },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface,
                    tonalElevation = 0.dp,
                    modifier = Modifier.border(
                        width = 0.5.dp,
                        color = MaterialTheme.colorScheme.outline
                    )
                ) {
                    val labelStyle = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 10.5.sp,
                        letterSpacing = (-0.3).sp
                    )

                    val s = uiState.strings

                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { if (selectedTab != 0) selectedTab = 0 },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = s.navSearch
                            )
                        },
                        label = {
                            Text(
                                text = s.navSearch,
                                style = labelStyle,
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            indicatorColor = Color.Transparent
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { if (selectedTab != 1) selectedTab = 1 },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.DownloadDone,
                                contentDescription = s.navDownloads
                            )
                        },
                        label = {
                            Text(
                                text = s.navDownloads,
                                style = labelStyle,
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            indicatorColor = Color.Transparent
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { if (selectedTab != 2) selectedTab = 2 },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = s.navTopPlayed
                            )
                        },
                        label = {
                            Text(
                                text = s.navTopPlayed,
                                style = labelStyle,
                                fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            indicatorColor = Color.Transparent
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { if (selectedTab != 3) selectedTab = 3 },
                        icon = {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.QueueMusic,
                                contentDescription = s.navPlaylists
                            )
                        },
                        label = {
                            Text(
                                text = s.navPlaylists,
                                style = labelStyle,
                                fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            indicatorColor = Color.Transparent
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 4,
                        onClick = { if (selectedTab != 4) selectedTab = 4 },
                        icon = { Icon(Icons.Default.Settings, contentDescription = s.navSettings) },
                        label = {
                            Text(
                                text = s.navSettings,
                                style = labelStyle,
                                fontWeight = if (selectedTab == 4) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            indicatorColor = Color.Transparent
                        )
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            val currentPlayingSongId = playback.song?.id
            val isCurrentlyPlaying = playback.status == PlaybackStatus.PLAYING
            val isCurrentlyBuffering = playback.status == PlaybackStatus.BUFFERING

            when (selectedTab) {
                0 -> ExploreSearchContent(
                    viewModel = viewModel,
                    uiState = uiState,
                    currentSongId = currentPlayingSongId,
                    isPlaying = isCurrentlyPlaying,
                    isBuffering = isCurrentlyBuffering,
                    listState = exploreListState
                )
                1 -> DownloadsContent(
                    viewModel = viewModel,
                    uiState = uiState,
                    currentSongId = currentPlayingSongId,
                    isPlaying = isCurrentlyPlaying,
                    isBuffering = isCurrentlyBuffering,
                    listState = downloadsListState
                )
                2 -> TopPlayedContent(
                    viewModel = viewModel,
                    uiState = uiState,
                    currentSongId = currentPlayingSongId,
                    isPlaying = isCurrentlyPlaying,
                    isBuffering = isCurrentlyBuffering,
                    listState = topPlayedListState
                )
                3 -> PlaylistsContent(
                    viewModel = viewModel,
                    playlists = uiState.playlists,
                    downloadedSongs = uiState.downloadedSongs,
                    listState = playlistsListState,
                    strings = uiState.strings
                )
                else -> SettingsContent(viewModel = viewModel, uiState = uiState)
            }

            if (uiState.isPlayerSheetOpen) {
                val sheetProgressState = viewModel.playerManager.progressState.collectAsState()
                PlayerSheet(
                    playback = playback,
                    progressState = sheetProgressState,
                    strings = uiState.strings,
                    onDismiss = { viewModel.setPlayerSheetVisible(false) },
                    onPlayPause = { viewModel.playerManager.togglePlayPause() },
                    onSeek = { ratio -> viewModel.playerManager.seekRatio(ratio) },
                    onToggleShuffle = { viewModel.playerManager.toggleShuffle() },
                    onToggleRepeat = { viewModel.playerManager.toggleRepeat() },
                    onNextClick = { viewModel.playNextSong() },
                    onPrevClick = { viewModel.playPreviousSong() },
                    onDownload = { playback.song?.let { viewModel.downloadSong(it) } }
                )
            }
        }
    }
}

@Composable
fun ExploreSearchContent(
    viewModel: MainViewModel,
    uiState: HomeUiState,
    currentSongId: String?,
    isPlaying: Boolean,
    isBuffering: Boolean,
    listState: LazyListState
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        val s = uiState.strings

        OwlSearchBar(
            query = uiState.searchQuery,
            onQueryChange = { viewModel.onSearchQueryChange(it) },
            placeholderText = s.searchPlaceholder,
            onSearchSubmit = { viewModel.onSearchSubmit(uiState.searchQuery) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (uiState.isSearching) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.primary,
                        strokeWidth = 3.dp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = s.searching,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp
                    )
                }
            }
        } else if (uiState.searchResults.isEmpty() && uiState.searchQuery.isEmpty()) {
            val showHistory = uiState.showRecentSearches && uiState.recentSearches.isNotEmpty()
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = if (showHistory) Arrangement.Top else Arrangement.Center
            ) {
                if (showHistory) {
                    Column(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        uiState.recentSearches.take(10).forEach { recentQuery ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.onSearchQueryChange(recentQuery)
                                        viewModel.onSearchSubmit(recentQuery)
                                    }
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Text(
                                    text = recentQuery,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.weight(1f)
                                )

                                IconButton(
                                    onClick = { viewModel.removeRecentSearch(recentQuery) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = s.delete,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.onSearchQueryChange(recentQuery) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.NorthWest,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                if (!showHistory) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = s.navSearch,
                            modifier = Modifier.size(44.dp),
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = s.searchPlaceholder,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else if (uiState.searchResults.isEmpty()) {

            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = s.searchNoResults,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 15.sp
                )
            }
        } else {

            LazyColumn(
                state = listState,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(uiState.searchResults, key = { it.id }) { song ->
                    val normKey = remember(song.id) { "${song.artist.trim().lowercase()}_${song.title.trim().lowercase()}" }
                    val isDownloadedLocally = song.id in uiState.downloadedKeys || (normKey in uiState.downloadedKeys)
                    val effectiveSong = remember(song, isDownloadedLocally) { song.copy(isDownloaded = isDownloadedLocally) }
                    val downloadProgress = uiState.activeDownloads[song.id]
                    val isCurrent = currentSongId == song.id
                    val itemPlaying = isCurrent && isPlaying
                    val itemBuffering = isCurrent && isBuffering

                    SongRowItem(
                        song = effectiveSong,
                        isCurrentSong = isCurrent,
                        isPlaying = itemPlaying,
                        isBuffering = itemBuffering,
                        downloadProgress = downloadProgress,
                        strings = s,
                        onSongClick = { viewModel.playSong(effectiveSong, uiState.searchResults) },
                        onDownloadClick = { viewModel.downloadSong(effectiveSong) }
                    )
                }
            }
        }
    }
}

@Composable
fun SongRowItem(
    song: SongItem,
    isCurrentSong: Boolean = false,
    isPlaying: Boolean = false,
    isBuffering: Boolean = false,
    downloadProgress: com.elbahram.owlmusic.domain.model.DownloadProgress?,
    strings: com.elbahram.owlmusic.util.AppStrings = com.elbahram.owlmusic.util.TurkishStrings,
    onSongClick: () -> Unit,
    onDownloadClick: () -> Unit
) {
    Surface(
        onClick = onSongClick,
        shape = RoundedCornerShape(14.dp),
        color = if (isCurrentSong) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            if (isCurrentSong) 1.dp else 0.5.dp,
            if (isCurrentSong) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            SongArtwork(
                thumbnailUrl = song.thumbnailUrl,
                contentDescription = song.title,
                shape = RoundedCornerShape(10.dp),
                iconSize = 24.dp,
                modifier = Modifier.size(52.dp)
            )

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = song.title,
                    color = if (isCurrentSong) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    fontWeight = if (isCurrentSong) FontWeight.Bold else FontWeight.SemiBold,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = song.artist,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (song.durationText.isNotEmpty()) {
                        Text(
                            text = " • ${song.durationText}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(
                        if (isCurrentSong) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .border(
                        0.5.dp,
                        if (isCurrentSong) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isBuffering) {
                    CircularProgressIndicator(
                        color = if (isCurrentSong) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary,
                        strokeWidth = 2.5.dp,
                        modifier = Modifier.size(20.dp)
                    )
                } else {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) strings.pause else strings.play,
                        tint = if (isCurrentSong) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            if (downloadProgress != null) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(0.5.dp, MaterialTheme.colorScheme.primary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        progress = { (downloadProgress.progressPercent.coerceIn(0, 100)) / 100f },
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.size(34.dp),
                        strokeWidth = 2.5.dp
                    )
                    Text(
                        text = "${downloadProgress.progressPercent}%",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else if (song.isDownloaded) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), CircleShape)
                        .clickable { onDownloadClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = strings.downloadedToDevice,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(0.5.dp, MaterialTheme.colorScheme.outline, CircleShape)
                        .clickable { onDownloadClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = strings.download,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun MiniPlayerBar(
    playback: CurrentPlayback,
    progressState: State<Pair<Long, Long>>,
    strings: com.elbahram.owlmusic.util.AppStrings = com.elbahram.owlmusic.util.TurkishStrings,
    onPlayPauseClick: () -> Unit,
    onBarClick: () -> Unit,
    onCloseClick: () -> Unit = {},
    onSeek: (Float) -> Unit = {},
    onPrevClick: () -> Unit = {},
    onNextClick: () -> Unit = {},
    onShuffleClick: () -> Unit = {},
    onRepeatClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val song = playback.song ?: return

    val progressRatio by remember {
        derivedStateOf {
            val (progressMs, durationMs) = progressState.value
            if (durationMs > 0L) (progressMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
        }
    }

    Surface(
        onClick = onBarClick,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        shadowElevation = 8.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SongArtwork(
                    thumbnailUrl = song.thumbnailUrl,
                    contentDescription = song.title,
                    shape = RoundedCornerShape(8.dp),
                    iconSize = 20.dp,
                    modifier = Modifier.size(42.dp)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.title,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(1.dp))
                    Text(
                        text = song.artist,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = onBarClick,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowUp,
                        contentDescription = strings.expand,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(22.dp)
                    )
                }

                IconButton(
                    onClick = onCloseClick,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = strings.close,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            var miniSliderPos by remember { mutableFloatStateOf(0f) }
            var isMiniSeeking by remember { mutableStateOf(false) }

            LaunchedEffect(progressRatio) {
                if (!isMiniSeeking) {
                    miniSliderPos = progressRatio
                }
            }

            com.elbahram.owlmusic.ui.components.OwlProgressSlider(
                value = if (isMiniSeeking) miniSliderPos else progressRatio,
                onValueChange = {
                    isMiniSeeking = true
                    miniSliderPos = it
                },
                onValueChangeFinished = {
                    isMiniSeeking = false
                    onSeek(miniSliderPos)
                },
                trackHeight = 5.dp,
                activeTrackHeight = 7.dp,
                thumbHeight = 12.dp,
                thumbWidth = 3.dp,
                activeColor = MaterialTheme.colorScheme.onSurface,
                inactiveColor = MaterialTheme.colorScheme.surface,
                thumbColor = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 2.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val currentDisplayMs = if (isMiniSeeking) {
                    (miniSliderPos * progressState.value.second).toLong()
                } else {
                    progressState.value.first
                }
                Text(
                    text = formatMiniMs(currentDisplayMs),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = formatMiniMs(progressState.value.second),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onShuffleClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shuffle,
                        contentDescription = strings.shuffle,
                        tint = if (playback.isShuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = onPrevClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipPrevious,
                        contentDescription = strings.previous,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(
                        onClick = onPlayPauseClick,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        if (playback.status == PlaybackStatus.BUFFERING) {
                            CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(22.dp)
                            )
                        } else {
                            val isPlaying = playback.status == PlaybackStatus.PLAYING
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) strings.pause else strings.play,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onNextClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = strings.next,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(26.dp)
                    )
                }

                IconButton(
                    onClick = onRepeatClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Repeat,
                        contentDescription = strings.repeat,
                        tint = if (playback.isRepeat) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

private fun formatMiniMs(ms: Long): String {
    val totalSeconds = (ms.coerceAtLeast(0L)) / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}
