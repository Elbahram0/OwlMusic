package com.elbahram.owlmusic

import android.content.Context
import android.util.Log
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

object YtDlpBootstrap {

    private const val TAG = "YtDlpBootstrap"

    private const val STARTUP_DEFER_MS = 3_000L

    private val mutex = Mutex()

    @Volatile
    private var appContext: Context? = null

    @Volatile
    private var ready = false

    fun scheduleStartupInit(context: Context) {
        appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            delay(STARTUP_DEFER_MS)
            ensureReady()
        }
    }

    suspend fun ensureReady() {
        if (ready) return
        mutex.withLock {
            if (ready) return
            val ctx = appContext ?: return
            try {
                YoutubeDL.getInstance().init(ctx)
                FFmpeg.getInstance().init(ctx)
                Log.d(TAG, "yt-dlp + FFmpeg hazır")
            } catch (t: Throwable) {

                Log.e(TAG, "yt-dlp/FFmpeg init başarısız: ${t.message}")
            } finally {
                ready = true
            }
        }
    }

    suspend fun <T> withLock(block: suspend () -> T): T {
        mutex.lock()
        try {
            return block()
        } finally {
            mutex.unlock()
        }
    }

    suspend fun <T> withLockOrNull(waitMs: Long, block: suspend () -> T): T? {

        return withTimeoutOrNull(waitMs) {
            mutex.withLock { block() }
        }
    }
}
