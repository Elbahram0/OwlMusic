package com.elbahram.owlmusic.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun OwlProgressSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    trackHeight: Dp = 7.dp,
    activeTrackHeight: Dp = 9.dp,
    thumbHeight: Dp = 15.dp,
    thumbWidth: Dp = 4.dp,
    activeColor: Color = Color.White,
    inactiveColor: Color = Color(0xFF2C2C2E),
    thumbColor: Color = Color.White
) {
    var isDragging by remember { mutableStateOf(false) }
    var dragProgress by remember(value) { mutableFloatStateOf(value.coerceIn(0f, 1f)) }

    val currentProgress = if (isDragging) dragProgress else value.coerceIn(0f, 1f)

    val animatedTrackHeight by animateDpAsState(
        targetValue = if (isDragging) activeTrackHeight else trackHeight,
        animationSpec = tween(durationMillis = 150),
        label = "trackHeight"
    )

    val animatedThumbHeight by animateDpAsState(
        targetValue = if (isDragging) thumbHeight + 4.dp else thumbHeight,
        animationSpec = tween(durationMillis = 150),
        label = "thumbHeight"
    )

    val animatedThumbWidth by animateDpAsState(
        targetValue = if (isDragging) thumbWidth + 1.dp else thumbWidth,
        animationSpec = tween(durationMillis = 150),
        label = "thumbWidth"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(36.dp)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        isDragging = true
                        val newProgress = (offset.x / size.width).coerceIn(0f, 1f)
                        dragProgress = newProgress
                        onValueChange(newProgress)
                    },
                    onDragEnd = {
                        isDragging = false
                        onValueChangeFinished?.invoke()
                    },
                    onDragCancel = {
                        isDragging = false
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        val newProgress = (change.position.x / size.width).coerceIn(0f, 1f)
                        dragProgress = newProgress
                        onValueChange(newProgress)
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().height(36.dp)) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val trackH = animatedTrackHeight.toPx()
            val thumbH = animatedThumbHeight.toPx()
            val thumbW = animatedThumbWidth.toPx()
            val cornerRadius = CornerRadius(trackH / 2f, trackH / 2f)
            val trackTop = (canvasHeight - trackH) / 2f

            drawRoundRect(
                color = inactiveColor,
                topLeft = Offset(0f, trackTop),
                size = Size(canvasWidth, trackH),
                cornerRadius = cornerRadius
            )

            val progressWidth = (canvasWidth * currentProgress).coerceAtLeast(0f)
            if (progressWidth > 0f) {
                drawRoundRect(
                    color = activeColor,
                    topLeft = Offset(0f, trackTop),
                    size = Size(progressWidth, trackH),
                    cornerRadius = CornerRadius(trackH / 2f, trackH / 2f)
                )
            }

            if (currentProgress > 0.005f) {
                val thumbLeft = (progressWidth - (thumbW / 2f)).coerceIn(0f, canvasWidth - thumbW)
                val thumbTop = (canvasHeight - thumbH) / 2f
                drawRoundRect(
                    color = thumbColor,
                    topLeft = Offset(thumbLeft, thumbTop),
                    size = Size(thumbW, thumbH),
                    cornerRadius = CornerRadius(thumbW / 2f, thumbW / 2f)
                )
            }
        }
    }
}
