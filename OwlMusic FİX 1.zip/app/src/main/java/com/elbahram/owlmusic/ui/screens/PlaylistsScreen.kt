package com.elbahram.owlmusic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.elbahram.owlmusic.domain.model.Playlist
import com.elbahram.owlmusic.domain.model.SongItem
import com.elbahram.owlmusic.ui.components.OwlSearchBar
import com.elbahram.owlmusic.ui.components.SongArtwork
import com.elbahram.owlmusic.ui.viewmodel.MainViewModel

@Composable
fun PlaylistsContent(
    viewModel: MainViewModel,
    playlists: List<Playlist>,
    downloadedSongs: List<SongItem>,
    listState: LazyListState,
    strings: com.elbahram.owlmusic.util.AppStrings = com.elbahram.owlmusic.util.TurkishStrings
) {
    val s = strings
    var selectedPlaylist by remember { mutableStateOf<Playlist?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }

    selectedPlaylist?.let { playlist ->

        val currentPlaylist = playlists.find { it.id == playlist.id } ?: playlist
        PlaylistDetailScreen(
            playlist = currentPlaylist,
            downloadedSongs = downloadedSongs,
            strings = s,
            onBackClick = { selectedPlaylist = null },
            onPlaySong = { song -> viewModel.playSong(song, currentPlaylist.songs) },
            onRemoveSong = { songId -> viewModel.removeSongFromPlaylist(currentPlaylist.id, songId) },
            onReorderSongs = { newOrder -> viewModel.reorderPlaylistSongs(currentPlaylist.id, newOrder) },
            onAddSongs = { songsToAdd -> viewModel.addSongsToPlaylist(currentPlaylist.id, songsToAdd) },
            onDeletePlaylist = {
                viewModel.deletePlaylist(currentPlaylist.id)
                selectedPlaylist = null
            }
        )
        return
    }

    if (showCreateDialog) {
        CreatePlaylistDialog(
            strings = s,
            onDismiss = { showCreateDialog = false },
            onCreate = { name ->
                viewModel.createPlaylist(name)
                showCreateDialog = false
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showCreateDialog = true }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = s.createPlaylist,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.QueueMusic,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (playlists.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 60.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.QueueMusic,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = s.emptyPlaylists,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }
            }
        } else {
            LazyColumn(
                state = listState,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 20.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(playlists, key = { it.id }) { playlist ->
                    PlaylistItemCard(
                        playlist = playlist,
                        strings = s,
                        onClick = { selectedPlaylist = playlist },
                        onDeleteClick = { viewModel.deletePlaylist(playlist.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PlaylistItemCard(
    playlist: Playlist,
    strings: com.elbahram.owlmusic.util.AppStrings,
    onClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            val coverUrl = playlist.songs.firstOrNull()?.thumbnailUrl
            SongArtwork(
                thumbnailUrl = coverUrl,
                contentDescription = playlist.name,
                shape = RoundedCornerShape(10.dp),
                iconSize = 24.dp,
                modifier = Modifier.size(54.dp)
            )

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = playlist.name,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "(${playlist.songs.size})",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = strings.settingsTitle,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(strings.deletePlaylist, color = MaterialTheme.colorScheme.error) },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                        onClick = {
                            showMenu = false
                            onDeleteClick()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PlaylistDetailScreen(
    playlist: Playlist,
    downloadedSongs: List<SongItem>,
    strings: com.elbahram.owlmusic.util.AppStrings,
    onBackClick: () -> Unit,
    onPlaySong: (SongItem) -> Unit,
    onRemoveSong: (String) -> Unit,
    onReorderSongs: (List<SongItem>) -> Unit,
    onAddSongs: (List<SongItem>) -> Unit,
    onDeletePlaylist: () -> Unit
) {
    var showAddSongsDialog by remember { mutableStateOf(false) }

    if (showAddSongsDialog) {
        AddSongsToPlaylistDialog(
            downloadedSongs = downloadedSongs,
            existingSongIds = playlist.songs.map { it.id }.toSet(),
            strings = strings,
            onDismiss = { showAddSongsDialog = false },
            onSongsSelected = { selected ->
                onAddSongs(selected)
                showAddSongsDialog = false
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackClick) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = strings.back,
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = playlist.name,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "(${playlist.songs.size})",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            IconButton(onClick = { showAddSongsDialog = true }) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = strings.addSongsToList,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(26.dp)
                )
            }

            IconButton(onClick = onDeletePlaylist) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = strings.deletePlaylist,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (playlist.songs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = strings.emptyPlaylists,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            }
        } else {
            val listState = rememberLazyListState()
            val haptic = LocalHapticFeedback.current

            val dragDropState = rememberDragDropState(lazyListState = listState) { from, to ->

            }

            var activeReorderList by remember { mutableStateOf<List<SongItem>?>(null) }
            val displaySongs = activeReorderList ?: playlist.songs

            val isDragEnabled = displaySongs.size > 1

            LazyColumn(
                state = listState,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 20.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .then(
                        if (isDragEnabled) {
                            Modifier.pointerInput(dragDropState, playlist.songs) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { offset ->
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        activeReorderList = playlist.songs.toMutableList()
                                        dragDropState.onDragStart(offset)
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        val from = dragDropState.draggingItemIndex
                                        dragDropState.onDrag(dragAmount)
                                        val to = dragDropState.draggingItemIndex
                                        if (from != null && to != null && from != to) {
                                            activeReorderList?.let { list ->
                                                if (from in list.indices && to in list.indices) {
                                                    val mutable = list.toMutableList()
                                                    val item = mutable.removeAt(from)
                                                    mutable.add(to, item)
                                                    activeReorderList = mutable
                                                }
                                            }
                                        }
                                    },
                                    onDragEnd = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        dragDropState.onDragEnd()
                                        activeReorderList?.let { reordered ->
                                            onReorderSongs(reordered)
                                        }
                                        activeReorderList = null
                                    },
                                    onDragCancel = {
                                        dragDropState.onDragCancel()
                                        activeReorderList = null
                                    }
                                )
                            }
                        } else Modifier
                    )
            ) {
                itemsIndexed(displaySongs, key = { _, song -> song.id }) { index, song ->
                    val isDragging = dragDropState.draggingItemIndex == index
                    PlaylistSongRowItem(
                        song = song,
                        isDragging = isDragging,
                        dragOffset = if (isDragging) dragDropState.draggingItemOffset else 0f,
                        index = index,
                        totalCount = displaySongs.size,
                        modifier = Modifier.zIndex(if (isDragging) 10f else 0f),
                        onSongClick = { onPlaySong(song) },
                        onMove = { from, to ->
                            val current = displaySongs.toMutableList()
                            if (from in current.indices && to in current.indices) {
                                val item = current.removeAt(from)
                                current.add(to, item)
                                onReorderSongs(current)
                            }
                        },
                        onMoveToTop = {
                            if (index > 0 && index in displaySongs.indices) {
                                val current = displaySongs.toMutableList()
                                val item = current.removeAt(index)
                                current.add(0, item)
                                onReorderSongs(current)
                            }
                        },
                        onRemove = { onRemoveSong(song.id) },
                        strings = strings
                    )
                }
            }
        }
    }
}

@Composable
private fun PlaylistSongRowItem(
    song: SongItem,
    isDragging: Boolean = false,
    dragOffset: Float = 0f,
    index: Int,
    totalCount: Int,
    modifier: Modifier = Modifier,
    onSongClick: () -> Unit,
    onMove: (Int, Int) -> Unit,
    onMoveToTop: () -> Unit,
    onRemove: () -> Unit,
    strings: com.elbahram.owlmusic.util.AppStrings = com.elbahram.owlmusic.util.TurkishStrings
) {
    var showMenu by remember { mutableStateOf(false) }

    val elevation by androidx.compose.animation.core.animateDpAsState(
        targetValue = if (isDragging) 12.dp else 0.dp,
        label = "elevation"
    )
    val scale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (isDragging) 1.03f else 1.0f,
        label = "scale"
    )

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isDragging) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            if (isDragging) 2.dp else 0.5.dp,
            if (isDragging) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
        ),
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                translationY = dragOffset
                scaleX = scale
                scaleY = scale
                shadowElevation = elevation.toPx()
            }
            .clickable { onSongClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SongArtwork(
                thumbnailUrl = song.thumbnailUrl,
                contentDescription = song.title,
                shape = RoundedCornerShape(10.dp),
                iconSize = 24.dp,
                modifier = Modifier.size(50.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = song.title,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = song.artist,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (song.durationText.isNotBlank()) {
                        Text(
                            text = " • ${song.durationText}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = Icons.Default.DragHandle,
                contentDescription = strings.dragToReorder,
                tint = if (isDragging) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier
                    .padding(horizontal = 6.dp)
                    .size(24.dp)
            )

            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = strings.options,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    if (index > 0) {
                        DropdownMenuItem(
                            text = { Text(strings.moveToTop) },
                            leadingIcon = { Icon(Icons.Default.VerticalAlignTop, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onMoveToTop()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(strings.moveUp) },
                            leadingIcon = { Icon(Icons.Default.KeyboardArrowUp, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onMove(index, index - 1)
                            }
                        )
                    }
                    if (index < totalCount - 1) {
                        DropdownMenuItem(
                            text = { Text(strings.moveDown) },
                            leadingIcon = { Icon(Icons.Default.KeyboardArrowDown, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onMove(index, index + 1)
                            }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(strings.removeFromList, color = MaterialTheme.colorScheme.error) },
                        leadingIcon = { Icon(Icons.Default.Close, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                        onClick = {
                            showMenu = false
                            onRemove()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun CreatePlaylistDialog(
    strings: com.elbahram.owlmusic.util.AppStrings,
    onDismiss: () -> Unit,
    onCreate: (String) -> Unit
) {
    var playlistName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = strings.newPlaylist,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        },
        text = {
            OutlinedTextField(
                value = playlistName,
                onValueChange = { playlistName = it },
                label = { Text(strings.playlistNamePlaceholder) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(
                enabled = playlistName.isNotBlank(),
                onClick = { onCreate(playlistName.trim()) }
            ) {
                Text(strings.create, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
private fun AddSongsToPlaylistDialog(
    downloadedSongs: List<SongItem>,
    existingSongIds: Set<String>,
    strings: com.elbahram.owlmusic.util.AppStrings,
    onDismiss: () -> Unit,
    onSongsSelected: (List<SongItem>) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val availableSongs = remember(downloadedSongs, existingSongIds, searchQuery) {
        val unadded = downloadedSongs.filter { it.id !in existingSongIds }
        if (searchQuery.isBlank()) {
            unadded
        } else {
            unadded.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.artist.contains(searchQuery, ignoreCase = true)
            }
        }
    }
    val selectedSongs = remember { mutableStateListOf<SongItem>() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = strings.addSongsDialogTitle,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (downloadedSongs.any { it.id !in existingSongIds }) {
                    OwlSearchBar(
                        query = searchQuery,
                        onQueryChange = { searchQuery = it },
                        placeholderText = strings.searchPlaceholder
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                if (availableSongs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (searchQuery.isNotBlank()) strings.searchNoResults else strings.noSongsToAdd,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 300.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(availableSongs, key = { it.id }) { song ->
                            val isSelected = selectedSongs.contains(song)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (isSelected) selectedSongs.remove(song) else selectedSongs.add(song)
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { checked ->
                                        if (checked == true) selectedSongs.add(song) else selectedSongs.remove(song)
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = song.title,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = song.artist,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selectedSongs.isNotEmpty(),
                onClick = { onSongsSelected(selectedSongs.toList()) }
            ) {
                Text("${strings.addSongsToList} (${selectedSongs.size})", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(16.dp)
    )
}
