package com.elbahram.owlmusic.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.elbahram.owlmusic.data.local.MusicDownloadManager
import com.elbahram.owlmusic.data.local.PlaylistRepository
import com.elbahram.owlmusic.data.remote.InnerTubeMusicExtractor
import com.elbahram.owlmusic.domain.model.CurrentPlayback
import com.elbahram.owlmusic.domain.model.DownloadProgress
import com.elbahram.owlmusic.domain.model.Playlist
import com.elbahram.owlmusic.domain.model.SongItem
import com.elbahram.owlmusic.player.OwlPlayerManager
import com.elbahram.owlmusic.ui.theme.ThemeMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.elbahram.owlmusic.MainActivity
import com.elbahram.owlmusic.R

data class HomeUiState(
    val searchQuery: String = "",
    val isSearching: Boolean = false,
    val searchResults: List<SongItem> = emptyList(),
    val downloadedSongs: List<SongItem> = emptyList(),
    val downloadedKeys: Set<String> = emptySet(),
    val playlists: List<Playlist> = emptyList(),
    val activeDownloads: Map<String, DownloadProgress> = emptyMap(),
    val playCounts: Map<String, Int> = emptyMap(),
    val currentTheme: ThemeMode = ThemeMode.SYSTEM_DEFAULT,
    val currentLanguage: com.elbahram.owlmusic.util.AppLanguage = com.elbahram.owlmusic.util.AppLanguage.TURKISH,
    val strings: com.elbahram.owlmusic.util.AppStrings = com.elbahram.owlmusic.util.TurkishStrings,
    val isPlayerSheetOpen: Boolean = false,
    val recentSearches: List<String> = emptyList(),
    val showRecentSearches: Boolean = true,
    val sleepTimerSecondsRemaining: Long? = null,
    val errorMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val extractor = InnerTubeMusicExtractor()
    private val downloadManager = MusicDownloadManager(application)
    private val playlistRepo = PlaylistRepository(application)
    val playerManager = OwlPlayerManager(application)

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    val playbackState: StateFlow<CurrentPlayback> = playerManager.playbackState

    private var activePlaylist: List<SongItem> = emptyList()
    private var activeSongIndex: Int = -1

    private var searchJob: Job? = null
    private var loadDownloadsJob: Job? = null
    private var playJob: Job? = null
    private val downloadScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val searchPrefs = application.getSharedPreferences("owl_search_prefs", android.content.Context.MODE_PRIVATE)
    private val playCountPrefs = application.getSharedPreferences("owl_play_counts", android.content.Context.MODE_PRIVATE)
    private val settingsPrefs = application.getSharedPreferences("owl_app_settings", android.content.Context.MODE_PRIVATE)

    init {
        loadLanguagePreferences()
        loadDownloadedSongs()
        loadPlaylists()
        loadSearchPreferences()
        loadPlayCounts()

        playerManager.streamUrlResolver = { videoId ->

            extractor.getAudioStreamUrl(videoId, forceRefresh = true, bypassInnerTube = false)
        }

        playerManager.onSongEndedListener = {
            playbackState.value.song?.let { finishedSong ->
                incrementPlayCount(finishedSong)
            }
            playNextSong()
        }

        playerManager.onNextRequested = {
            playNextSong()
        }
        playerManager.onPreviousRequested = {
            playPreviousSong()
        }
        playerManager.onStopRequested = {
            playerManager.stopPlayback()
        }
        playerManager.onFavoriteRequested = {
            toggleFavoriteCurrentSong()
        }

        com.elbahram.owlmusic.service.OwlPlaybackService.isFavoriteProvider = {
            playbackState.value.song?.let { isSongFavorite(it.id) } ?: false
        }

        viewModelScope.launch {
            playerManager.errorEvents.collect { message ->
                _uiState.value = _uiState.value.copy(errorMessage = message)
            }
        }
    }

    private fun loadSearchPreferences() {
        viewModelScope.launch(Dispatchers.IO) {
            val show = searchPrefs.getBoolean("show_recent_searches", true)
            val savedJson = searchPrefs.getString("recent_searches_list", null)
            val list = if (savedJson != null) {
                try {
                    val arr = org.json.JSONArray(savedJson)
                    (0 until arr.length()).map { arr.getString(it) }
                } catch (e: Exception) {
                    emptyList()
                }
            } else emptyList()

            _uiState.value = _uiState.value.copy(
                showRecentSearches = show,
                recentSearches = list
            )
        }
    }

    fun setShowRecentSearches(enabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            searchPrefs.edit().putBoolean("show_recent_searches", enabled).apply()
        }
        _uiState.value = _uiState.value.copy(showRecentSearches = enabled)
    }

    fun onSearchQueryChange(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
        if (query.trim().length >= 2) {
            searchJob?.cancel()
            searchJob = viewModelScope.launch {
                kotlinx.coroutines.delay(400)
                performSearch(query.trim())
            }
        } else if (query.isEmpty()) {
            _uiState.value = _uiState.value.copy(searchResults = emptyList(), isSearching = false)
        }
    }

    fun onSearchSubmit(query: String) {
        val trimmed = query.trim()
        if (trimmed.isNotEmpty()) {
            addRecentSearch(trimmed)
        }
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            performSearch(trimmed)
        }
    }

    fun addRecentSearch(query: String) {
        if (!_uiState.value.showRecentSearches) return
        val current = _uiState.value.recentSearches.toMutableList()
        current.remove(query)
        current.add(0, query)
        val updated = current.take(15)
        persistRecentSearches(updated)
        _uiState.value = _uiState.value.copy(recentSearches = updated)
    }

    fun removeRecentSearch(query: String) {
        val current = _uiState.value.recentSearches.filter { it != query }
        persistRecentSearches(current)
        _uiState.value = _uiState.value.copy(recentSearches = current)
    }

    fun clearRecentSearches() {
        persistRecentSearches(emptyList())
        _uiState.value = _uiState.value.copy(recentSearches = emptyList())
    }

    private fun persistRecentSearches(list: List<String>) {
        viewModelScope.launch(Dispatchers.IO) {
            val arr = org.json.JSONArray()
            list.forEach { arr.put(it) }
            searchPrefs.edit().putString("recent_searches_list", arr.toString()).apply()
        }
    }

    private suspend fun performSearch(query: String) {
        if (query.isEmpty()) return
        _uiState.value = _uiState.value.copy(isSearching = true)
        val results = extractor.searchSongs(query)
        _uiState.value = _uiState.value.copy(
            searchResults = results,
            isSearching = false
        )
    }

    fun playSong(song: SongItem, playlist: List<SongItem> = emptyList()) {
        val current = playbackState.value

        if (current.song?.id == song.id && playerManager.hasMediaItem()) {
            playerManager.togglePlayPause()
            return
        }

        playerManager.prepareSong(song)

        playJob?.cancel()
        playJob = viewModelScope.launch {
            if (playlist.isNotEmpty()) {
                activePlaylist = playlist
                activeSongIndex = playlist.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
            } else if (activePlaylist.none { it.id == song.id }) {
                activePlaylist = listOf(song)
                activeSongIndex = 0
            } else {
                activeSongIndex = activePlaylist.indexOfFirst { it.id == song.id }
            }

            if (song.isLocal && !song.localFilePath.isNullOrEmpty()) {
                playerManager.playSong(song, song.localFilePath)
            } else {
                val streamUrl = extractor.getAudioStreamUrl(song.id)
                if (streamUrl != null) {
                    playerManager.playSong(song, streamUrl)
                } else {
                    playerManager.stopPlayback()
                    _uiState.value = _uiState.value.copy(errorMessage = _uiState.value.strings.errorStreamNotAvailable)
                }
            }
        }
    }

    fun playNextSong() {
        val list = activePlaylist
        if (list.isEmpty()) return
        val currentIndex = list.indexOfFirst { it.id == playbackState.value.song?.id }.let {
            if (it != -1) it else activeSongIndex.coerceIn(0, list.size - 1)
        }
        val isShuffle = playbackState.value.isShuffle
        val nextIndex = if (isShuffle && list.size > 1) {
            (list.indices - currentIndex).randomOrNull() ?: 0
        } else {
            (currentIndex + 1) % list.size
        }
        val nextSong = list.getOrNull(nextIndex) ?: return
        playSong(nextSong, list)
    }

    fun playPreviousSong() {
        val list = activePlaylist
        if (list.isEmpty()) return
        val currentMs = playbackState.value.currentPositionMs
        if (currentMs > 3000L) {
            playerManager.seekTo(0)
            return
        }
        val currentIndex = list.indexOfFirst { it.id == playbackState.value.song?.id }.let {
            if (it != -1) it else activeSongIndex.coerceIn(0, list.size - 1)
        }
        val prevIndex = if (currentIndex > 0) currentIndex - 1 else list.size - 1
        val prevSong = list.getOrNull(prevIndex) ?: return
        playSong(prevSong, list)
    }

    fun downloadSong(song: SongItem) {
        val normKey = "${song.artist.trim().lowercase()}_${song.title.trim().lowercase()}"
        val isAlreadyDownloaded = song.id in _uiState.value.downloadedKeys ||
            (!song.localFilePath.isNullOrBlank() && song.localFilePath in _uiState.value.downloadedKeys) ||
            (normKey != "_" && normKey in _uiState.value.downloadedKeys)

        if (isAlreadyDownloaded) {
            val msg = _uiState.value.strings.alreadyDownloaded.replace("%s", song.title)
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(
                    getApplication(),
                    msg,
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
            return
        }

        downloadScope.launch { downloadManager.unmarkSongDeleted(song) }

        val currentDownloads = _uiState.value.activeDownloads
        if (currentDownloads.containsKey(song.id)) return

        setDownloadProgress(song.id, DownloadProgress(songId = song.id, progressPercent = 0))

        downloadScope.launch {
            downloadManager.acquireWakeLock()
            try {
                val stream = try {
                    extractor.resolveAudioStream(song.id)
                } catch (e: Exception) {
                    null
                }

                downloadManager.downloadSong(song, stream).collect { progress ->
                    when {
                        progress.isCompleted -> {
                            clearDownload(song.id)
                            loadDownloadedSongs()
                            val msg = _uiState.value.strings.songDownloadedSuccess.replace("%s", song.title)
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                android.widget.Toast.makeText(
                                    getApplication(),
                                    msg,
                                    android.widget.Toast.LENGTH_SHORT
                                ).show()
                            }
                        }

                        progress.error != null -> {
                            clearDownload(song.id)
                            val errMsg = _uiState.value.strings.downloadFailed.replace("%s", progress.error ?: "")
                            _uiState.value = _uiState.value.copy(
                                errorMessage = errMsg
                            )
                        }

                        else -> setDownloadProgress(song.id, progress)
                    }
                }
            } catch (e: Exception) {
                clearDownload(song.id)
                val errMsg = _uiState.value.strings.downloadErrorGeneral.replace("%s", e.message ?: "")
                _uiState.value = _uiState.value.copy(
                    errorMessage = errMsg
                )
            } finally {
                clearDownload(song.id)
                downloadManager.releaseWakeLockIfIdle(_uiState.value.activeDownloads.isEmpty())
            }
        }
    }

    private fun setDownloadProgress(songId: String, progress: DownloadProgress) {

        val existing = _uiState.value.activeDownloads[songId]
        if (existing != null &&
            existing.progressPercent == progress.progressPercent &&
            existing.error == progress.error &&
            !progress.isCompleted
        ) {
            return
        }
        val updated = _uiState.value.activeDownloads.toMutableMap()
        updated[songId] = progress
        _uiState.value = _uiState.value.copy(activeDownloads = updated)
    }

    private fun clearDownload(songId: String) {
        val updated = _uiState.value.activeDownloads.toMutableMap()
        updated.remove(songId)
        _uiState.value = _uiState.value.copy(activeDownloads = updated)
    }

    fun persistDownloadedSongsOrder(songs: List<SongItem>) {
        _uiState.value = _uiState.value.copy(downloadedSongs = songs)
        viewModelScope.launch(Dispatchers.IO) {
            val arr = org.json.JSONArray()
            songs.forEach { arr.put(it.id) }
            val jsonStr = arr.toString()
            songOrderPrefs.edit().putString("custom_order", jsonStr).apply()
            try {
                val backupFile = getSongOrderBackupFile()
                backupFile?.writeText(jsonStr, Charsets.UTF_8)
            } catch (_: Exception) {}
        }
    }

    private val songOrderPrefs = application.getSharedPreferences("owl_song_order", android.content.Context.MODE_PRIVATE)

    private fun getSongOrderBackupFile(): java.io.File? {
        return try {
            val pubDir = java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "OwlMusic")
            if (!pubDir.exists()) pubDir.mkdirs()
            java.io.File(pubDir, ".owl_song_order_backup.json")
        } catch (_: Exception) {
            null
        }
    }

    private fun buildDownloadedKeys(songs: List<SongItem>): Set<String> {
        val set = HashSet<String>(songs.size * 3)
        for (s in songs) {
            set.add(s.id)
            if (!s.localFilePath.isNullOrBlank()) {
                set.add(s.localFilePath)
            }
            val key = "${s.artist.trim().lowercase()}_${s.title.trim().lowercase()}"
            if (key != "_") set.add(key)
        }
        return set
    }

    fun loadDownloadedSongs() {

        loadDownloadsJob?.cancel()
        loadDownloadsJob = viewModelScope.launch(Dispatchers.IO) {
            val local = downloadManager.getLocalSongs()
            var savedOrderJson = songOrderPrefs.getString("custom_order", null)
            if (savedOrderJson.isNullOrBlank()) {
                val backupFile = getSongOrderBackupFile()
                if (backupFile != null && backupFile.exists() && backupFile.length() > 0) {
                    try {
                        savedOrderJson = backupFile.readText(Charsets.UTF_8)
                        if (!savedOrderJson.isNullOrBlank()) {
                            songOrderPrefs.edit().putString("custom_order", savedOrderJson).apply()
                        }
                    } catch (_: Exception) {}
                }
            }

            val orderedList = if (savedOrderJson != null) {
                try {
                    val arr = org.json.JSONArray(savedOrderJson)
                    val idList = (0 until arr.length()).map { arr.getString(it) }
                    val map = local.associateBy { it.id }
                    val sorted = idList.mapNotNull { map[it] }.toMutableList()
                    local.forEach { song ->
                        if (sorted.none { it.id == song.id }) {
                            sorted.add(song)
                        }
                    }
                    sorted
                } catch (e: Exception) {
                    local
                }
            } else {
                local
            }
            val keys = buildDownloadedKeys(orderedList)
            _uiState.value = _uiState.value.copy(
                downloadedSongs = orderedList,
                downloadedKeys = keys
            )
        }
    }

    fun deleteDownloadedSong(song: SongItem) {
        viewModelScope.launch {

            if (playbackState.value.song?.id == song.id) {
                playerManager.stopPlayback()
            }
            withContext(Dispatchers.IO) {
                val current = _uiState.value.downloadedSongs.filter { it.id != song.id && it.localFilePath != song.localFilePath }
                val keys = buildDownloadedKeys(current)
                _uiState.value = _uiState.value.copy(downloadedSongs = current, downloadedKeys = keys)
                persistSongOrder(current)
                downloadManager.deleteDownloadedSong(song)
            }
            loadDownloadedSongs()
        }
    }

    fun deleteMultipleDownloadedSongs(songs: List<SongItem>) {
        viewModelScope.launch {
            val toDeleteIds = songs.map { it.id }.toSet()

            if (playbackState.value.song?.id in toDeleteIds) {
                playerManager.stopPlayback()
            }
            withContext(Dispatchers.IO) {
                val current = _uiState.value.downloadedSongs.filter { it.id !in toDeleteIds }
                val keys = buildDownloadedKeys(current)
                _uiState.value = _uiState.value.copy(downloadedSongs = current, downloadedKeys = keys)
                persistSongOrder(current)
                for (song in songs) {
                    downloadManager.deleteDownloadedSong(song)
                }
            }
            loadDownloadedSongs()
        }
    }

    private fun persistSongOrder(songs: List<SongItem>) {
        viewModelScope.launch(Dispatchers.IO) {
            val arr = org.json.JSONArray()
            songs.forEach { arr.put(it.id) }
            val jsonStr = arr.toString()
            songOrderPrefs.edit().putString("custom_order", jsonStr).apply()
            try {
                val backupFile = getSongOrderBackupFile()
                if (backupFile != null) {
                    backupFile.writeText(jsonStr, Charsets.UTF_8)
                }
            } catch (_: Exception) {}
        }
    }

    fun moveDownloadedSong(fromIndex: Int, toIndex: Int) {
        val current = _uiState.value.downloadedSongs.toMutableList()
        if (fromIndex in current.indices && toIndex in current.indices) {
            val item = current.removeAt(fromIndex)
            current.add(toIndex, item)
            _uiState.value = _uiState.value.copy(downloadedSongs = current)
            persistSongOrder(current)
        }
    }

    fun moveDownloadedSongToTop(index: Int) {
        moveDownloadedSong(index, 0)
    }

    fun moveDownloadedSongToBottom(index: Int) {
        val current = _uiState.value.downloadedSongs
        if (current.isNotEmpty()) {
            moveDownloadedSong(index, current.lastIndex)
        }
    }

    fun loadPlaylists() {
        viewModelScope.launch {
            val lists = playlistRepo.getPlaylists()
            _uiState.value = _uiState.value.copy(playlists = lists)
        }
    }

    fun createPlaylist(name: String, initialSongs: List<SongItem> = emptyList()) {
        viewModelScope.launch {
            playlistRepo.createPlaylist(name, initialSongs)
            loadPlaylists()
        }
    }

    fun deletePlaylist(playlistId: String) {
        viewModelScope.launch {
            playlistRepo.deletePlaylist(playlistId)
            loadPlaylists()
        }
    }

    fun addSongsToPlaylist(playlistId: String, songs: List<SongItem>) {
        viewModelScope.launch {
            playlistRepo.addSongsToPlaylist(playlistId, songs)
            loadPlaylists()
        }
    }

    fun removeSongFromPlaylist(playlistId: String, songId: String) {
        viewModelScope.launch {
            playlistRepo.removeSongFromPlaylist(playlistId, songId)
            loadPlaylists()
        }
    }

    fun reorderPlaylistSongs(playlistId: String, newSongs: List<SongItem>) {
        viewModelScope.launch {
            playlistRepo.updatePlaylistSongs(playlistId, newSongs)
            loadPlaylists()
        }
    }

    fun setTheme(theme: ThemeMode) {
        _uiState.value = _uiState.value.copy(currentTheme = theme)
    }

    private fun loadLanguagePreferences() {
        val savedLangCode = settingsPrefs.getString("app_language", "tr") ?: "tr"
        val lang = com.elbahram.owlmusic.util.AppLanguage.fromCode(savedLangCode)
        _uiState.value = _uiState.value.copy(
            currentLanguage = lang,
            strings = com.elbahram.owlmusic.util.getStringsForLanguage(lang)
        )
    }

    fun setLanguage(language: com.elbahram.owlmusic.util.AppLanguage) {
        _uiState.value = _uiState.value.copy(
            currentLanguage = language,
            strings = com.elbahram.owlmusic.util.getStringsForLanguage(language)
        )
        viewModelScope.launch(Dispatchers.IO) {
            settingsPrefs.edit().putString("app_language", language.code).apply()
        }
    }

    fun setPlayerSheetVisible(visible: Boolean) {
        _uiState.value = _uiState.value.copy(isPlayerSheetOpen = visible)
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    private val favoritePrefs = getApplication<android.app.Application>()
        .getSharedPreferences("owl_favorites", android.content.Context.MODE_PRIVATE)

    fun isSongFavorite(songId: String): Boolean {
        return favoritePrefs.getBoolean(songId, false)
    }

    fun toggleFavoriteCurrentSong() {
        val currentSong = playbackState.value.song ?: return
        val currentFav = isSongFavorite(currentSong.id)
        val newFav = !currentFav

        viewModelScope.launch(Dispatchers.IO) {
            favoritePrefs.edit().putBoolean(currentSong.id, newFav).apply()
        }

        com.elbahram.owlmusic.service.OwlPlaybackService.updateCustomLayout()

        viewModelScope.launch {
            val allLists = playlistRepo.getPlaylists().toMutableList()
            var favPlaylist = allLists.find { it.name.equals("Favoriler", ignoreCase = true) }
            if (favPlaylist == null && newFav) {
                playlistRepo.createPlaylist("Favoriler", listOf(currentSong))
            } else if (favPlaylist != null) {
                if (newFav) {
                    if (favPlaylist.songs.none { it.id == currentSong.id }) {
                        playlistRepo.addSongsToPlaylist(favPlaylist.id, listOf(currentSong))
                    }
                } else {
                    playlistRepo.removeSongFromPlaylist(favPlaylist.id, currentSong.id)
                }
            }
            loadPlaylists()

            android.os.Handler(android.os.Looper.getMainLooper()).post {
                val template = if (newFav) _uiState.value.strings.addedToFavorites else _uiState.value.strings.removedFromFavorites
                val msg = template.replace("%s", currentSong.title)
                android.widget.Toast.makeText(getApplication(), msg, android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun getSongPlayCountKey(song: SongItem): String {
        return if (song.id.isNotBlank()) song.id else "${song.artist.trim().lowercase()}_${song.title.trim().lowercase()}"
    }

    private fun loadPlayCounts() {
        viewModelScope.launch(Dispatchers.IO) {
            val all = playCountPrefs.all
            val counts = mutableMapOf<String, Int>()
            all.forEach { (key, value) ->
                if (value is Int) {
                    counts[key] = value
                } else if (value is Number) {
                    counts[key] = value.toInt()
                }
            }
            _uiState.value = _uiState.value.copy(playCounts = counts)
        }
    }

    fun incrementPlayCount(song: SongItem) {
        val key = getSongPlayCountKey(song)
        val currentCount = _uiState.value.playCounts[key] ?: 0
        val newCount = currentCount + 1
        val updated = _uiState.value.playCounts.toMutableMap()
        updated[key] = newCount
        _uiState.value = _uiState.value.copy(playCounts = updated)
        viewModelScope.launch(Dispatchers.IO) {
            playCountPrefs.edit().putInt(key, newCount).apply()
        }
    }

    private var sleepTimerJob: Job? = null
    private val notificationManager = getApplication<Application>()
        .getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    companion object {
        private const val SLEEP_TIMER_CHANNEL_ID = "owl_sleep_timer_channel"
        private const val SLEEP_TIMER_NOTIFICATION_ID = 2002
        const val ACTION_CANCEL_SLEEP_TIMER = "com.elbahram.owlmusic.ACTION_CANCEL_SLEEP_TIMER"
    }

    init {
        createSleepTimerNotificationChannel()
        com.elbahram.owlmusic.receiver.SleepTimerReceiver.onCancelRequested = {
            viewModelScope.launch(Dispatchers.Main) {
                cancelSleepTimer(showMessage = true)
            }
        }
    }

    private fun createSleepTimerNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                SLEEP_TIMER_CHANNEL_ID,
                "Uyku Zamanlayıcısı",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Müzik duraklatma geri sayım sayacı"
                setShowBadge(false)
                enableVibration(false)
                setSound(null, null)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun startSleepTimer(minutes: Int) {
        if (minutes <= 0) return
        cancelSleepTimer(showMessage = false)

        val totalSeconds = minutes * 60L
        _uiState.value = _uiState.value.copy(sleepTimerSecondsRemaining = totalSeconds)

        android.os.Handler(android.os.Looper.getMainLooper()).post {
            android.widget.Toast.makeText(
                getApplication(),
                "Uyku zamanlayıcısı $minutes dakika olarak ayarlandı.",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }

        sleepTimerJob = viewModelScope.launch(Dispatchers.Main) {
            var remaining = totalSeconds
            while (remaining > 0) {
                updateSleepTimerNotification(remaining)
                delay(1000L)
                remaining--
                _uiState.value = _uiState.value.copy(sleepTimerSecondsRemaining = remaining)
            }

            clearSleepTimerNotification()
            _uiState.value = _uiState.value.copy(sleepTimerSecondsRemaining = null)
            playerManager.pausePlayback()

            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(
                    getApplication(),
                    "Uyku zamanlayıcısı süresi doldu. Müzik duraklatıldı.",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    fun cancelSleepTimer(showMessage: Boolean = true) {
        sleepTimerJob?.cancel()
        sleepTimerJob = null
        clearSleepTimerNotification()
        _uiState.value = _uiState.value.copy(sleepTimerSecondsRemaining = null)

        if (showMessage) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(
                    getApplication(),
                    "Uyku zamanlayıcısı iptal edildi.",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun updateSleepTimerNotification(secondsRemaining: Long) {
        val minutes = secondsRemaining / 60
        val seconds = secondsRemaining % 60
        val timeFormatted = String.format(java.util.Locale.US, "%02d:%02d", minutes, seconds)

        val intent = Intent(getApplication(), MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            getApplication(),
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cancelIntent = Intent(getApplication(), com.elbahram.owlmusic.receiver.SleepTimerReceiver::class.java).apply {
            action = ACTION_CANCEL_SLEEP_TIMER
        }
        val cancelPendingIntent = PendingIntent.getBroadcast(
            getApplication(),
            1,
            cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val largeIconBitmap = try {
            android.graphics.BitmapFactory.decodeResource(getApplication<Application>().resources, R.mipmap.ic_launcher)
        } catch (_: Exception) {
            null
        }

        val notification = NotificationCompat.Builder(getApplication(), SLEEP_TIMER_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .apply {
                if (largeIconBitmap != null) setLargeIcon(largeIconBitmap)
            }
            .setContentTitle("Uyku Zamanlayıcısı")
            .setContentText("Kalan: $timeFormatted")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentPendingIntent)
            .addAction(0, "İptal Et", cancelPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        try {
            notificationManager.notify(SLEEP_TIMER_NOTIFICATION_ID, notification)
        } catch (_: Exception) {}
    }

    private fun clearSleepTimerNotification() {
        try {
            notificationManager.cancel(SLEEP_TIMER_NOTIFICATION_ID)
        } catch (_: Exception) {}
    }

    override fun onCleared() {
        super.onCleared()
        cancelSleepTimer(showMessage = false)
        playerManager.release()
    }
}

