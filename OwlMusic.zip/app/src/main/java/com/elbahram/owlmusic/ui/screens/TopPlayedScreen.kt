package com.elbahram.owlmusic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elbahram.owlmusic.domain.model.SongItem
import com.elbahram.owlmusic.ui.components.SongArtwork
import com.elbahram.owlmusic.ui.viewmodel.HomeUiState
import com.elbahram.owlmusic.ui.viewmodel.MainViewModel

@Composable
fun TopPlayedContent(
    viewModel: MainViewModel,
    uiState: HomeUiState,
    currentSongId: String?,
    isPlaying: Boolean,
    isBuffering: Boolean,
    listState: LazyListState
) {

    val allSongsMap = remember(uiState.downloadedSongs, uiState.playlists, uiState.searchResults) {
        val map = mutableMapOf<String, SongItem>()
        uiState.downloadedSongs.forEach { map[viewModel.getSongPlayCountKey(it)] = it }
        uiState.playlists.forEach { pl ->
            pl.songs.forEach { s ->
                val k = viewModel.getSongPlayCountKey(s)
                if (!map.containsKey(k)) map[k] = s
            }
        }
        uiState.searchResults.forEach { s ->
            val k = viewModel.getSongPlayCountKey(s)
            if (!map.containsKey(k)) map[k] = s
        }
        map
    }

    val topSongsWithCount = remember(allSongsMap, uiState.playCounts) {
        uiState.playCounts
            .filter { it.value > 0 }
            .mapNotNull { (key, count) ->
                allSongsMap[key]?.let { song -> Pair(song, count) }
            }
            .sortedByDescending { it.second }
    }

    val s = uiState.strings

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        if (topSongsWithCount.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 60.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Leaderboard,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = s.noPlaysYet,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }
            }
        } else {
            val topPlayableSongs = remember(topSongsWithCount) { topSongsWithCount.map { it.first } }
            LazyColumn(
                state = listState,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 20.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(topSongsWithCount, key = { _, pair -> pair.first.id }) { index, (song, count) ->
                    val normKey = remember(song.id) { "${song.artist.trim().lowercase()}_${song.title.trim().lowercase()}" }
                    val isDownloadedLocally = song.id in uiState.downloadedKeys || (normKey in uiState.downloadedKeys)
                    val effectiveSong = remember(song, isDownloadedLocally) { song.copy(isDownloaded = isDownloadedLocally) }
                    val isCurrent = currentSongId == song.id

                    TopPlayedSongRow(
                        rank = index + 1,
                        song = effectiveSong,
                        playCount = count,
                        suffix = s.playsCountSuffix,
                        isCurrentSong = isCurrent,
                        onSongClick = { viewModel.playSong(effectiveSong, topPlayableSongs) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TopPlayedSongRow(
    rank: Int,
    song: SongItem,
    playCount: Int,
    suffix: String,
    isCurrentSong: Boolean,
    onSongClick: () -> Unit
) {
    Surface(
        onClick = onSongClick,
        shape = RoundedCornerShape(14.dp),
        color = if (isCurrentSong) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            if (isCurrentSong) 1.dp else 0.5.dp,
            if (isCurrentSong) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Box(
                modifier = Modifier.width(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "$rank",
                    fontWeight = FontWeight.Bold,
                    fontSize = if (rank < 10) 16.sp else 13.sp,
                    color = if (rank <= 3) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            SongArtwork(
                thumbnailUrl = song.thumbnailUrl,
                contentDescription = song.title,
                shape = RoundedCornerShape(10.dp),
                iconSize = 24.dp,
                modifier = Modifier.size(50.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = song.title,
                    color = if (isCurrentSong) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    fontWeight = if (isCurrentSong) FontWeight.Bold else FontWeight.SemiBold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = song.artist,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Text(
                    text = "$playCount $suffix",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}
