package com.elbahram.owlmusic.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.NotificationManager
import com.elbahram.owlmusic.player.OwlPlayerManager

class SleepTimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == "com.elbahram.owlmusic.ACTION_CANCEL_SLEEP_TIMER") {

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            notificationManager?.cancel(2002)

            onCancelRequested?.invoke()
        }
    }

    companion object {
        var onCancelRequested: (() -> Unit)? = null
    }
}
