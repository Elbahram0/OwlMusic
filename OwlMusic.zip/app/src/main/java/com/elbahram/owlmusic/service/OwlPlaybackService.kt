package com.elbahram.owlmusic.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.elbahram.owlmusic.MainActivity
import com.elbahram.owlmusic.R
import com.elbahram.owlmusic.data.remote.PreferIpv4Dns
import com.elbahram.owlmusic.player.OwlOkHttpDataSource
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

@OptIn(UnstableApi::class)
class OwlPlaybackService : MediaSessionService() {

    private var exoPlayer: ExoPlayer? = null
    private var forwardingPlayer: Player? = null
    private var mediaSession: MediaSession? = null

    companion object {
        const val CHANNEL_ID = "owl_music_playback_channel"
        const val NOTIFICATION_ID = 1001
        private const val USER_AGENT =
            "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_1 like Mac OS X)"

        const val ACTION_CLOSE = "com.elbahram.owlmusic.ACTION_CLOSE"
        const val ACTION_FAVORITE = "com.elbahram.owlmusic.ACTION_FAVORITE"

        var onNextTrackRequested: (() -> Unit)? = null
        var onPreviousTrackRequested: (() -> Unit)? = null
        var onStopRequested: (() -> Unit)? = null
        var onFavoriteRequested: (() -> Unit)? = null
        var isFavoriteProvider: (() -> Boolean)? = null

        var currentServiceInstance: OwlPlaybackService? = null

        fun updateCustomLayout() {
            currentServiceInstance?.refreshCustomLayout()
        }
    }

    private fun getCustomLayout(): List<CommandButton> {
        val isFav = isFavoriteProvider?.invoke() ?: false

        val closeCommand = SessionCommand(ACTION_CLOSE, Bundle.EMPTY)
        val closeButton = CommandButton.Builder()
            .setSessionCommand(closeCommand)
            .setIconResId(R.drawable.ic_notification_close)
            .setDisplayName("Kapat")
            .setEnabled(true)
            .build()

        val favoriteCommand = SessionCommand(ACTION_FAVORITE, Bundle.EMPTY)
        val favoriteButton = CommandButton.Builder()
            .setSessionCommand(favoriteCommand)
            .setIconResId(if (isFav) R.drawable.ic_notification_favorite else R.drawable.ic_notification_favorite_border)
            .setDisplayName("Favori")
            .setEnabled(true)
            .build()

        return listOf(closeButton, favoriteButton)
    }

    fun refreshCustomLayout() {
        val session = mediaSession ?: return
        try {
            session.setCustomLayout(getCustomLayout())
        } catch (_: Exception) {}
    }

    private val sessionCallback = object : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val closeCommand = SessionCommand(ACTION_CLOSE, Bundle.EMPTY)
            val favoriteCommand = SessionCommand(ACTION_FAVORITE, Bundle.EMPTY)

            val sessionCommands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(closeCommand)
                .add(favoriteCommand)
                .build()

            val playerCommands = session.player.availableCommands.buildUpon()
                .add(Player.COMMAND_PLAY_PAUSE)
                .add(Player.COMMAND_SEEK_TO_NEXT)
                .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
                .add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
                .add(Player.COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM)
                .add(Player.COMMAND_SEEK_BACK)
                .add(Player.COMMAND_SEEK_FORWARD)
                .add(Player.COMMAND_STOP)
                .build()

            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(sessionCommands)
                .setAvailablePlayerCommands(playerCommands)
                .setCustomLayout(getCustomLayout())
                .build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            when (customCommand.customAction) {
                ACTION_CLOSE -> {
                    onStopRequested?.invoke()
                    exoPlayer?.pause()
                    exoPlayer?.clearMediaItems()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                    } else {
                        @Suppress("DEPRECATION")
                        stopForeground(true)
                    }
                }
                ACTION_FAVORITE -> {
                    onFavoriteRequested?.invoke()
                    refreshCustomLayout()
                }
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }

        override fun onPlayerCommandRequest(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            playerCommand: Int
        ): Int {
            return SessionResult.RESULT_SUCCESS
        }
    }

    @OptIn(UnstableApi::class)
    override fun onCreate() {
        super.onCreate()
        currentServiceInstance = this
        createNotificationChannel()

        val audioAttributes = AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setUsage(C.USAGE_MEDIA)
            .build()

        val mediaHttpClient = OkHttpClient.Builder()
            .dns(PreferIpv4Dns)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .connectionPool(okhttp3.ConnectionPool(5, 5, TimeUnit.MINUTES))
            .followRedirects(true)
            .build()

        val httpDataSourceFactory = OwlOkHttpDataSource.Factory(mediaHttpClient, USER_AGENT)
        val dataSourceFactory = DefaultDataSource.Factory(this, httpDataSourceFactory)

        val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(this)
            .setExtensionRendererMode(androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)

        val loadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                20_000,
                60_000,
                2_500,
                5_000
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        exoPlayer = ExoPlayer.Builder(this, renderersFactory)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        val forwarding = object : ForwardingPlayer(exoPlayer!!) {
            override fun getAvailableCommands(): Player.Commands {
                return super.getAvailableCommands().buildUpon()
                    .add(Player.COMMAND_PLAY_PAUSE)
                    .add(Player.COMMAND_SEEK_TO_NEXT)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                    .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
                    .add(Player.COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM)
                    .add(Player.COMMAND_SEEK_BACK)
                    .add(Player.COMMAND_SEEK_FORWARD)
                    .add(Player.COMMAND_STOP)
                    .build()
            }

            override fun isCommandAvailable(command: Int): Boolean {
                return when (command) {
                    Player.COMMAND_PLAY_PAUSE,
                    Player.COMMAND_SEEK_TO_NEXT,
                    Player.COMMAND_SEEK_TO_PREVIOUS,
                    Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
                    Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM,
                    Player.COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM,
                    Player.COMMAND_SEEK_BACK,
                    Player.COMMAND_SEEK_FORWARD,
                    Player.COMMAND_STOP -> true
                    else -> super.isCommandAvailable(command)
                }
            }

            override fun seekToNext() {
                onNextTrackRequested?.invoke()
            }

            override fun seekToNextMediaItem() {
                onNextTrackRequested?.invoke()
            }

            override fun seekToPrevious() {
                onPreviousTrackRequested?.invoke()
            }

            override fun seekToPreviousMediaItem() {
                onPreviousTrackRequested?.invoke()
            }

            override fun stop() {

                super.stop()
            }
        }
        forwardingPlayer = forwarding

        val sessionActivityPendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, forwardingPlayer!!)
            .setSessionActivity(sessionActivityPendingIntent)
            .setCallback(sessionCallback)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "OwlMusic Audio Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "OwlMusic background player controls"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        if (currentServiceInstance == this) {
            currentServiceInstance = null
        }
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        forwardingPlayer = null
        exoPlayer = null
        super.onDestroy()
    }
}
