package com.elbahram.owlmusic.data.local

import android.content.Context
import android.content.SharedPreferences
import com.elbahram.owlmusic.domain.model.Playlist
import com.elbahram.owlmusic.domain.model.SongItem
import org.json.JSONArray
import org.json.JSONObject

import android.os.Environment
import java.io.File

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class PlaylistRepository(private val context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("owl_playlists", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PLAYLISTS = "saved_playlists"
        private const val BACKUP_FILE_NAME = ".owl_playlists_backup.json"
    }

    @Volatile
    private var cache: List<Playlist>? = null

    private val loadMutex = Mutex()

    @Volatile
    private var lastPersistedJson: String? = null

    private fun getBackupFile(): File? {
        return try {
            val pubDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "OwlMusic")
            if (!pubDir.exists()) pubDir.mkdirs()
            File(pubDir, BACKUP_FILE_NAME)
        } catch (_: Exception) {
            null
        }
    }

    suspend fun getPlaylists(): List<Playlist> = withContext(Dispatchers.IO) {
        val existing = cache
        if (existing != null) {
            existing
        } else {
            loadMutex.withLock {
                val again = cache
                if (again != null) {
                    again
                } else {
                    val loaded = loadFromDisk()
                    cache = loaded
                    loaded
                }
            }
        }
    }

    private fun loadFromDisk(): List<Playlist> {
        var jsonString = prefs.getString(KEY_PLAYLISTS, null)

        if (jsonString.isNullOrBlank()) {
            val backupFile = getBackupFile()
            if (backupFile != null && backupFile.exists() && backupFile.length() > 0) {
                try {
                    jsonString = backupFile.readText(Charsets.UTF_8)
                    if (!jsonString.isNullOrBlank()) {
                        prefs.edit().putString(KEY_PLAYLISTS, jsonString).apply()
                    }
                } catch (_: Exception) {}
            }
        }

        if (jsonString.isNullOrBlank()) return emptyList()
        lastPersistedJson = jsonString

        return try {
            val jsonArray = JSONArray(jsonString)
            val list = mutableListOf<Playlist>()
            for (i in 0 until jsonArray.length()) {
                list.add(parsePlaylist(jsonArray.getJSONObject(i), i))
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun savePlaylists(playlists: List<Playlist>) = withContext(Dispatchers.IO) {
        try {
            val jsonArray = JSONArray()
            for (p in playlists) {
                jsonArray.put(serializePlaylist(p))
            }
            val jsonString = jsonArray.toString()
            prefs.edit().putString(KEY_PLAYLISTS, jsonString).apply()

            cache = playlists

            if (jsonString != lastPersistedJson) {
                lastPersistedJson = jsonString
                try {
                    getBackupFile()?.writeText(jsonString, Charsets.UTF_8)
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun createPlaylist(name: String, initialSongs: List<SongItem> = emptyList()): Playlist = withContext(Dispatchers.IO) {
        val current = getPlaylists().toMutableList()
        val newPlaylist = Playlist(
            name = name,
            songs = initialSongs
        )
        current.add(0, newPlaylist)
        savePlaylists(current)
        newPlaylist
    }

    suspend fun deletePlaylist(playlistId: String) = withContext(Dispatchers.IO) {
        val current = getPlaylists().toMutableList()
        current.removeAll { it.id == playlistId }
        savePlaylists(current)
    }

    suspend fun addSongsToPlaylist(playlistId: String, songsToAdd: List<SongItem>) = withContext(Dispatchers.IO) {
        val current = getPlaylists().toMutableList()
        val index = current.indexOfFirst { it.id == playlistId }
        if (index != -1) {
            val existing = current[index]
            val updatedSongs = existing.songs.toMutableList()
            for (song in songsToAdd) {
                if (updatedSongs.none { it.id == song.id }) {
                    updatedSongs.add(song)
                }
            }
            current[index] = existing.copy(songs = updatedSongs)
            savePlaylists(current)
        }
    }

    suspend fun removeSongFromPlaylist(playlistId: String, songId: String) = withContext(Dispatchers.IO) {
        val current = getPlaylists().toMutableList()
        val index = current.indexOfFirst { it.id == playlistId }
        if (index != -1) {
            val existing = current[index]
            val updatedSongs = existing.songs.filter { it.id != songId }
            current[index] = existing.copy(songs = updatedSongs)
            savePlaylists(current)
        }
    }

    suspend fun updatePlaylistSongs(playlistId: String, songs: List<SongItem>) = withContext(Dispatchers.IO) {
        val current = getPlaylists().toMutableList()
        val index = current.indexOfFirst { it.id == playlistId }
        if (index != -1) {
            val existing = current[index]
            current[index] = existing.copy(songs = songs)
            savePlaylists(current)
        }
    }

    private fun serializePlaylist(playlist: Playlist): JSONObject {
        val obj = JSONObject()
        obj.put("id", playlist.id)
        obj.put("name", playlist.name)
        obj.put("createdAt", playlist.createdAt)

        val songsArray = JSONArray()
        for (song in playlist.songs) {
            val songObj = JSONObject()
            songObj.put("id", song.id)
            songObj.put("title", song.title)
            songObj.put("artist", song.artist)
            songObj.put("durationText", song.durationText)
            songObj.put("durationMs", song.durationMs)
            songObj.put("thumbnailUrl", song.thumbnailUrl)
            songObj.put("streamUrl", song.streamUrl ?: "")
            songObj.put("localFilePath", song.localFilePath ?: "")
            songObj.put("isDownloaded", song.isDownloaded)
            songsArray.put(songObj)
        }
        obj.put("songs", songsArray)
        return obj
    }

    private fun parsePlaylist(obj: JSONObject, index: Int): Playlist {
        val name = obj.optString("name", "Çalma Listesi")
        val createdAt = obj.optLong("createdAt", System.currentTimeMillis())

        val rawId = obj.optString("id", "")
        val id = if (rawId.isNotBlank()) {
            rawId
        } else {
            "pl_${index}_" + Integer.toHexString((name + "@" + createdAt).hashCode())
        }

        val songsList = mutableListOf<SongItem>()
        val songsArray = obj.optJSONArray("songs")
        if (songsArray != null) {
            for (i in 0 until songsArray.length()) {
                val songObj = songsArray.getJSONObject(i)
                val sId = songObj.optString("id", "")
                val title = songObj.optString("title", "Bilinmeyen Şarkı")
                val artist = songObj.optString("artist", "OwlMusic")
                val durationText = songObj.optString("durationText", "")
                val durationMs = songObj.optLong("durationMs", 0L)
                val thumbnailUrl = songObj.optString("thumbnailUrl", "")
                val streamUrl = songObj.optString("streamUrl", "").ifEmpty { null }
                val localFilePath = songObj.optString("localFilePath", "").ifEmpty { null }
                val isDownloaded = songObj.optBoolean("isDownloaded", false)

                songsList.add(
                    SongItem(
                        id = sId,
                        title = title,
                        artist = artist,
                        durationText = durationText,
                        durationMs = durationMs,
                        thumbnailUrl = thumbnailUrl,
                        streamUrl = streamUrl,
                        localFilePath = localFilePath,
                        isDownloaded = isDownloaded
                    )
                )
            }
        }
        return Playlist(id = id, name = name, songs = songsList, createdAt = createdAt)
    }
}
