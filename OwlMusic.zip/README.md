# 🦉 OwlMusic

OwlMusic, Android için geliştirilmiş, modern, reklamsız, ücretsiz ve açık kaynaklı bir müzik dinleme ve indirme uygulamasıdır.

---

## ✨ Özellikler

- 🎵 **Sınırsız Arama & Dinleme:** YouTube ve YouTube Music altyapısıyla milyonlarca şarkıya erişim.
- 📥 **Çevrimdışı İndirme:** Şarkıları kapak fotoğraflarıyla birlikte yüksek kalitede cihaza indirme.
- ⚡ **Hızlı ve Akıcı:** Jetpack Compose ile modern ve minimalist kullanıcı arayüzü.
- 🎛️ **Gelişmiş Oynatıcı:** Arka planda çalma, bildirim kontrolleri, kilit ekranı desteği ve uyku zamanlayıcısı.
- 📋 **Çalma Listeleri & Sıralama:** İndirilen şarkıları sürükle-bırak ile yeniden sıralama ve özel çalma listeleri oluşturma.
- 🌐 **Çoklu Dil Desteği:** Türkçe, İngilizce, Rusça ve Çince.
- 🌓 **Tema Desteği:** AMOLED Siyah, Açık Tema ve Sistem Teması.

---

## 🛠️ Teknolojiler & Kütüphaneler

- **Dil:** Kotlin
- **Arayüz:** Jetpack Compose (Material Design 3)
- **Medya Oynatıcı:** AndroidX Media3 (ExoPlayer & MediaSession)
- **Ağ:** OkHttp3
- **Resim Yükleme:** Coil
- **Müzik Motoru:** InnerTube API & NewPipeExtractor

---

## 🚀 Projeyi Derleme

Projeyi yerel ortamınızda derlemek için:

```bash
git clone https://github.com/elbahram0/OwlMusic.git
cd OwlMusic
./gradlew assembleDebug
```

Çıktı APK dosyası `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşturulacaktır.

---

## 👤 Geliştirici & İletişim

Bu proje **Oruç Demiroş (@El_bahram)** tarafından açık kaynak ve ücretsiz olarak geliştirilmiştir.

- ✈️ **Telegram:** [@El_bahram](https://t.me/El_bahram)
- 📺 **YouTube:** [@orucdemiros](https://www.youtube.com/@orucdemiros)
- 🐙 **GitHub:** [@elbahram0](https://github.com/elbahram0)

---

## 📄 Lisans

Bu proje açık kaynaklıdır ve eğitim/geliştirme amaçlı paylaşılmıştır.
